package tesma.ovanes.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import tesma.ovanes.services.UmlModelGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalUmlModelParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'GradingCriteria'", "'weight'", "'points'", "'description'", "'['", "','", "']'", "'with'", "'step'", "'{'", "'}'", "':'", "'-'", "'GradingCategory'", "'contains'", "'gradingCriteriaa'", "'Test'", "'covers'", "'rationale'", "'grading'", "'categories'", "'correctors'", "'result'", "'Institution'", "'partOf'", "'name'", "'region'", "'address'", "'programs'", "'currentSituatuon'", "'gastronomie'", "'contact'", "'Program'", "'in'", "'isced'", "'program director'", "'prerequisites'", "'requisites'", "'costs'", "'language'", "'email'", "'weblink'", "'courses'", "'Course'", "'belongs'", "'reference'", "'corecourse'", "'academicyear'", "'/'", "'term'", "'module'", "'hoursPerWeek'", "'totalHours'", "'credits'", "'languages'", "'coursemoderator'", "'groups'", "'boards'", "'promotions'", "'students'", "'tasks'", "'organization'", "'typeof'", "'called'", "'instructor'", "'hours'", "'Period'", "'('", "')'", "'start'", "'end'", "'from'", "'to'", "'tests'", "'Artefact'", "'Grades'", "'gradingCategory'", "'grades'", "'gradingCriteria'", "'Board'", "'instructors'", "'h'", "'(moderator)'", "'Group'", "'Instructor'", "'board'", "'Promotion'", "'Student'", "'FieldCoverage'", "'Standard'", "'Field'", "'Term'", "'referenced'", "'Module'", "'hide'", "'required'", "'elective'", "'lecture'", "'directed_work'", "'written_exam'", "'mid-term_exam'", "'oral_exam'", "'seminar_paper'", "'project'", "'presentation'", "'exercises'", "'other'", "'no_assessment'", "'practical'", "'tutorial'", "'output'", "'input'", "'student'", "'.'"
    };
    public static final int T__50=50;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int RULE_INT=5;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__102=102;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int T__90=90;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__99=99;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int T__122=122;
    public static final int T__70=70;
    public static final int T__121=121;
    public static final int T__71=71;
    public static final int T__124=124;
    public static final int T__72=72;
    public static final int T__123=123;
    public static final int T__120=120;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__77=77;
    public static final int T__119=119;
    public static final int T__78=78;
    public static final int T__118=118;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int T__115=115;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__114=114;
    public static final int T__75=75;
    public static final int T__117=117;
    public static final int T__76=76;
    public static final int T__116=116;
    public static final int T__80=80;
    public static final int T__111=111;
    public static final int T__81=81;
    public static final int T__110=110;
    public static final int T__82=82;
    public static final int T__113=113;
    public static final int T__83=83;
    public static final int T__112=112;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__88=88;
    public static final int T__108=108;
    public static final int T__89=89;
    public static final int T__107=107;
    public static final int T__109=109;
    public static final int T__84=84;
    public static final int T__104=104;
    public static final int T__85=85;
    public static final int T__103=103;
    public static final int T__86=86;
    public static final int T__106=106;
    public static final int T__87=87;
    public static final int T__105=105;

    // delegates
    // delegators


        public InternalUmlModelParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalUmlModelParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalUmlModelParser.tokenNames; }
    public String getGrammarFileName() { return "InternalUmlModel.g"; }



     	private UmlModelGrammarAccess grammarAccess;

        public InternalUmlModelParser(TokenStream input, UmlModelGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected UmlModelGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalUmlModel.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalUmlModel.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalUmlModel.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalUmlModel.g:71:1: ruleModel returns [EObject current=null] : ( ( (lv_elements_0_1= rulectInstitution | lv_elements_0_2= rulectProgram | lv_elements_0_3= rulectCourse | lv_elements_0_4= rulectStandard | lv_elements_0_5= rulectActor | lv_elements_0_6= rulectTest | lv_elements_0_7= rulectCategory | lv_elements_0_8= rulectCriteria ) ) )* ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_elements_0_1 = null;

        EObject lv_elements_0_2 = null;

        EObject lv_elements_0_3 = null;

        EObject lv_elements_0_4 = null;

        EObject lv_elements_0_5 = null;

        EObject lv_elements_0_6 = null;

        EObject lv_elements_0_7 = null;

        EObject lv_elements_0_8 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:77:2: ( ( ( (lv_elements_0_1= rulectInstitution | lv_elements_0_2= rulectProgram | lv_elements_0_3= rulectCourse | lv_elements_0_4= rulectStandard | lv_elements_0_5= rulectActor | lv_elements_0_6= rulectTest | lv_elements_0_7= rulectCategory | lv_elements_0_8= rulectCriteria ) ) )* )
            // InternalUmlModel.g:78:2: ( ( (lv_elements_0_1= rulectInstitution | lv_elements_0_2= rulectProgram | lv_elements_0_3= rulectCourse | lv_elements_0_4= rulectStandard | lv_elements_0_5= rulectActor | lv_elements_0_6= rulectTest | lv_elements_0_7= rulectCategory | lv_elements_0_8= rulectCriteria ) ) )*
            {
            // InternalUmlModel.g:78:2: ( ( (lv_elements_0_1= rulectInstitution | lv_elements_0_2= rulectProgram | lv_elements_0_3= rulectCourse | lv_elements_0_4= rulectStandard | lv_elements_0_5= rulectActor | lv_elements_0_6= rulectTest | lv_elements_0_7= rulectCategory | lv_elements_0_8= rulectCriteria ) ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==11||LA2_0==24||LA2_0==27||LA2_0==34||LA2_0==43||LA2_0==54||LA2_0==90||(LA2_0>=94 && LA2_0<=95)||(LA2_0>=97 && LA2_0<=98)||LA2_0==100||LA2_0==105) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalUmlModel.g:79:3: ( (lv_elements_0_1= rulectInstitution | lv_elements_0_2= rulectProgram | lv_elements_0_3= rulectCourse | lv_elements_0_4= rulectStandard | lv_elements_0_5= rulectActor | lv_elements_0_6= rulectTest | lv_elements_0_7= rulectCategory | lv_elements_0_8= rulectCriteria ) )
            	    {
            	    // InternalUmlModel.g:79:3: ( (lv_elements_0_1= rulectInstitution | lv_elements_0_2= rulectProgram | lv_elements_0_3= rulectCourse | lv_elements_0_4= rulectStandard | lv_elements_0_5= rulectActor | lv_elements_0_6= rulectTest | lv_elements_0_7= rulectCategory | lv_elements_0_8= rulectCriteria ) )
            	    // InternalUmlModel.g:80:4: (lv_elements_0_1= rulectInstitution | lv_elements_0_2= rulectProgram | lv_elements_0_3= rulectCourse | lv_elements_0_4= rulectStandard | lv_elements_0_5= rulectActor | lv_elements_0_6= rulectTest | lv_elements_0_7= rulectCategory | lv_elements_0_8= rulectCriteria )
            	    {
            	    // InternalUmlModel.g:80:4: (lv_elements_0_1= rulectInstitution | lv_elements_0_2= rulectProgram | lv_elements_0_3= rulectCourse | lv_elements_0_4= rulectStandard | lv_elements_0_5= rulectActor | lv_elements_0_6= rulectTest | lv_elements_0_7= rulectCategory | lv_elements_0_8= rulectCriteria )
            	    int alt1=8;
            	    switch ( input.LA(1) ) {
            	    case 34:
            	        {
            	        alt1=1;
            	        }
            	        break;
            	    case 43:
            	        {
            	        alt1=2;
            	        }
            	        break;
            	    case 54:
            	    case 105:
            	        {
            	        alt1=3;
            	        }
            	        break;
            	    case 100:
            	        {
            	        alt1=4;
            	        }
            	        break;
            	    case 90:
            	    case 94:
            	    case 95:
            	    case 97:
            	    case 98:
            	        {
            	        alt1=5;
            	        }
            	        break;
            	    case 27:
            	        {
            	        alt1=6;
            	        }
            	        break;
            	    case 24:
            	        {
            	        alt1=7;
            	        }
            	        break;
            	    case 11:
            	        {
            	        alt1=8;
            	        }
            	        break;
            	    default:
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 1, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt1) {
            	        case 1 :
            	            // InternalUmlModel.g:81:5: lv_elements_0_1= rulectInstitution
            	            {

            	            					newCompositeNode(grammarAccess.getModelAccess().getElementsCtInstitutionParserRuleCall_0_0());
            	            				
            	            pushFollow(FOLLOW_3);
            	            lv_elements_0_1=rulectInstitution();

            	            state._fsp--;


            	            					if (current==null) {
            	            						current = createModelElementForParent(grammarAccess.getModelRule());
            	            					}
            	            					add(
            	            						current,
            	            						"elements",
            	            						lv_elements_0_1,
            	            						"tesma.ovanes.UmlModel.ctInstitution");
            	            					afterParserOrEnumRuleCall();
            	            				

            	            }
            	            break;
            	        case 2 :
            	            // InternalUmlModel.g:97:5: lv_elements_0_2= rulectProgram
            	            {

            	            					newCompositeNode(grammarAccess.getModelAccess().getElementsCtProgramParserRuleCall_0_1());
            	            				
            	            pushFollow(FOLLOW_3);
            	            lv_elements_0_2=rulectProgram();

            	            state._fsp--;


            	            					if (current==null) {
            	            						current = createModelElementForParent(grammarAccess.getModelRule());
            	            					}
            	            					add(
            	            						current,
            	            						"elements",
            	            						lv_elements_0_2,
            	            						"tesma.ovanes.UmlModel.ctProgram");
            	            					afterParserOrEnumRuleCall();
            	            				

            	            }
            	            break;
            	        case 3 :
            	            // InternalUmlModel.g:113:5: lv_elements_0_3= rulectCourse
            	            {

            	            					newCompositeNode(grammarAccess.getModelAccess().getElementsCtCourseParserRuleCall_0_2());
            	            				
            	            pushFollow(FOLLOW_3);
            	            lv_elements_0_3=rulectCourse();

            	            state._fsp--;


            	            					if (current==null) {
            	            						current = createModelElementForParent(grammarAccess.getModelRule());
            	            					}
            	            					add(
            	            						current,
            	            						"elements",
            	            						lv_elements_0_3,
            	            						"tesma.ovanes.UmlModel.ctCourse");
            	            					afterParserOrEnumRuleCall();
            	            				

            	            }
            	            break;
            	        case 4 :
            	            // InternalUmlModel.g:129:5: lv_elements_0_4= rulectStandard
            	            {

            	            					newCompositeNode(grammarAccess.getModelAccess().getElementsCtStandardParserRuleCall_0_3());
            	            				
            	            pushFollow(FOLLOW_3);
            	            lv_elements_0_4=rulectStandard();

            	            state._fsp--;


            	            					if (current==null) {
            	            						current = createModelElementForParent(grammarAccess.getModelRule());
            	            					}
            	            					add(
            	            						current,
            	            						"elements",
            	            						lv_elements_0_4,
            	            						"tesma.ovanes.UmlModel.ctStandard");
            	            					afterParserOrEnumRuleCall();
            	            				

            	            }
            	            break;
            	        case 5 :
            	            // InternalUmlModel.g:145:5: lv_elements_0_5= rulectActor
            	            {

            	            					newCompositeNode(grammarAccess.getModelAccess().getElementsCtActorParserRuleCall_0_4());
            	            				
            	            pushFollow(FOLLOW_3);
            	            lv_elements_0_5=rulectActor();

            	            state._fsp--;


            	            					if (current==null) {
            	            						current = createModelElementForParent(grammarAccess.getModelRule());
            	            					}
            	            					add(
            	            						current,
            	            						"elements",
            	            						lv_elements_0_5,
            	            						"tesma.ovanes.UmlModel.ctActor");
            	            					afterParserOrEnumRuleCall();
            	            				

            	            }
            	            break;
            	        case 6 :
            	            // InternalUmlModel.g:161:5: lv_elements_0_6= rulectTest
            	            {

            	            					newCompositeNode(grammarAccess.getModelAccess().getElementsCtTestParserRuleCall_0_5());
            	            				
            	            pushFollow(FOLLOW_3);
            	            lv_elements_0_6=rulectTest();

            	            state._fsp--;


            	            					if (current==null) {
            	            						current = createModelElementForParent(grammarAccess.getModelRule());
            	            					}
            	            					add(
            	            						current,
            	            						"elements",
            	            						lv_elements_0_6,
            	            						"tesma.ovanes.UmlModel.ctTest");
            	            					afterParserOrEnumRuleCall();
            	            				

            	            }
            	            break;
            	        case 7 :
            	            // InternalUmlModel.g:177:5: lv_elements_0_7= rulectCategory
            	            {

            	            					newCompositeNode(grammarAccess.getModelAccess().getElementsCtCategoryParserRuleCall_0_6());
            	            				
            	            pushFollow(FOLLOW_3);
            	            lv_elements_0_7=rulectCategory();

            	            state._fsp--;


            	            					if (current==null) {
            	            						current = createModelElementForParent(grammarAccess.getModelRule());
            	            					}
            	            					add(
            	            						current,
            	            						"elements",
            	            						lv_elements_0_7,
            	            						"tesma.ovanes.UmlModel.ctCategory");
            	            					afterParserOrEnumRuleCall();
            	            				

            	            }
            	            break;
            	        case 8 :
            	            // InternalUmlModel.g:193:5: lv_elements_0_8= rulectCriteria
            	            {

            	            					newCompositeNode(grammarAccess.getModelAccess().getElementsCtCriteriaParserRuleCall_0_7());
            	            				
            	            pushFollow(FOLLOW_3);
            	            lv_elements_0_8=rulectCriteria();

            	            state._fsp--;


            	            					if (current==null) {
            	            						current = createModelElementForParent(grammarAccess.getModelRule());
            	            					}
            	            					add(
            	            						current,
            	            						"elements",
            	            						lv_elements_0_8,
            	            						"tesma.ovanes.UmlModel.ctCriteria");
            	            					afterParserOrEnumRuleCall();
            	            				

            	            }
            	            break;

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRulectCriteria"
    // InternalUmlModel.g:214:1: entryRulectCriteria returns [EObject current=null] : iv_rulectCriteria= rulectCriteria EOF ;
    public final EObject entryRulectCriteria() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectCriteria = null;


        try {
            // InternalUmlModel.g:214:51: (iv_rulectCriteria= rulectCriteria EOF )
            // InternalUmlModel.g:215:2: iv_rulectCriteria= rulectCriteria EOF
            {
             newCompositeNode(grammarAccess.getCtCriteriaRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectCriteria=rulectCriteria();

            state._fsp--;

             current =iv_rulectCriteria; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectCriteria"


    // $ANTLR start "rulectCriteria"
    // InternalUmlModel.g:221:1: rulectCriteria returns [EObject current=null] : (otherlv_0= 'GradingCriteria' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_weight_3_0= RULE_INT ) ) (otherlv_4= 'points' ( (lv_evaluation_5_0= rulectMeasuredVariable ) ) )? otherlv_6= 'description' ( (lv_decription_7_0= RULE_STRING ) ) ) ;
    public final EObject rulectCriteria() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_weight_3_0=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token lv_decription_7_0=null;
        EObject lv_evaluation_5_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:227:2: ( (otherlv_0= 'GradingCriteria' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_weight_3_0= RULE_INT ) ) (otherlv_4= 'points' ( (lv_evaluation_5_0= rulectMeasuredVariable ) ) )? otherlv_6= 'description' ( (lv_decription_7_0= RULE_STRING ) ) ) )
            // InternalUmlModel.g:228:2: (otherlv_0= 'GradingCriteria' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_weight_3_0= RULE_INT ) ) (otherlv_4= 'points' ( (lv_evaluation_5_0= rulectMeasuredVariable ) ) )? otherlv_6= 'description' ( (lv_decription_7_0= RULE_STRING ) ) )
            {
            // InternalUmlModel.g:228:2: (otherlv_0= 'GradingCriteria' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_weight_3_0= RULE_INT ) ) (otherlv_4= 'points' ( (lv_evaluation_5_0= rulectMeasuredVariable ) ) )? otherlv_6= 'description' ( (lv_decription_7_0= RULE_STRING ) ) )
            // InternalUmlModel.g:229:3: otherlv_0= 'GradingCriteria' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_weight_3_0= RULE_INT ) ) (otherlv_4= 'points' ( (lv_evaluation_5_0= rulectMeasuredVariable ) ) )? otherlv_6= 'description' ( (lv_decription_7_0= RULE_STRING ) )
            {
            otherlv_0=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtCriteriaAccess().getGradingCriteriaKeyword_0());
            		
            // InternalUmlModel.g:233:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:234:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:234:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:235:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtCriteriaAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtCriteriaRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getCtCriteriaAccess().getWeightKeyword_2());
            		
            // InternalUmlModel.g:255:3: ( (lv_weight_3_0= RULE_INT ) )
            // InternalUmlModel.g:256:4: (lv_weight_3_0= RULE_INT )
            {
            // InternalUmlModel.g:256:4: (lv_weight_3_0= RULE_INT )
            // InternalUmlModel.g:257:5: lv_weight_3_0= RULE_INT
            {
            lv_weight_3_0=(Token)match(input,RULE_INT,FOLLOW_7); 

            					newLeafNode(lv_weight_3_0, grammarAccess.getCtCriteriaAccess().getWeightINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtCriteriaRule());
            					}
            					setWithLastConsumed(
            						current,
            						"weight",
            						lv_weight_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalUmlModel.g:273:3: (otherlv_4= 'points' ( (lv_evaluation_5_0= rulectMeasuredVariable ) ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==13) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalUmlModel.g:274:4: otherlv_4= 'points' ( (lv_evaluation_5_0= rulectMeasuredVariable ) )
                    {
                    otherlv_4=(Token)match(input,13,FOLLOW_8); 

                    				newLeafNode(otherlv_4, grammarAccess.getCtCriteriaAccess().getPointsKeyword_4_0());
                    			
                    // InternalUmlModel.g:278:4: ( (lv_evaluation_5_0= rulectMeasuredVariable ) )
                    // InternalUmlModel.g:279:5: (lv_evaluation_5_0= rulectMeasuredVariable )
                    {
                    // InternalUmlModel.g:279:5: (lv_evaluation_5_0= rulectMeasuredVariable )
                    // InternalUmlModel.g:280:6: lv_evaluation_5_0= rulectMeasuredVariable
                    {

                    						newCompositeNode(grammarAccess.getCtCriteriaAccess().getEvaluationCtMeasuredVariableParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_evaluation_5_0=rulectMeasuredVariable();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCtCriteriaRule());
                    						}
                    						set(
                    							current,
                    							"evaluation",
                    							lv_evaluation_5_0,
                    							"tesma.ovanes.UmlModel.ctMeasuredVariable");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,14,FOLLOW_10); 

            			newLeafNode(otherlv_6, grammarAccess.getCtCriteriaAccess().getDescriptionKeyword_5());
            		
            // InternalUmlModel.g:302:3: ( (lv_decription_7_0= RULE_STRING ) )
            // InternalUmlModel.g:303:4: (lv_decription_7_0= RULE_STRING )
            {
            // InternalUmlModel.g:303:4: (lv_decription_7_0= RULE_STRING )
            // InternalUmlModel.g:304:5: lv_decription_7_0= RULE_STRING
            {
            lv_decription_7_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            					newLeafNode(lv_decription_7_0, grammarAccess.getCtCriteriaAccess().getDecriptionSTRINGTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtCriteriaRule());
            					}
            					setWithLastConsumed(
            						current,
            						"decription",
            						lv_decription_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectCriteria"


    // $ANTLR start "entryRulectMeasuredVariable"
    // InternalUmlModel.g:324:1: entryRulectMeasuredVariable returns [EObject current=null] : iv_rulectMeasuredVariable= rulectMeasuredVariable EOF ;
    public final EObject entryRulectMeasuredVariable() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectMeasuredVariable = null;


        try {
            // InternalUmlModel.g:324:59: (iv_rulectMeasuredVariable= rulectMeasuredVariable EOF )
            // InternalUmlModel.g:325:2: iv_rulectMeasuredVariable= rulectMeasuredVariable EOF
            {
             newCompositeNode(grammarAccess.getCtMeasuredVariableRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectMeasuredVariable=rulectMeasuredVariable();

            state._fsp--;

             current =iv_rulectMeasuredVariable; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectMeasuredVariable"


    // $ANTLR start "rulectMeasuredVariable"
    // InternalUmlModel.g:331:1: rulectMeasuredVariable returns [EObject current=null] : ( ( (lv_result_0_1= rulectNumericalVariable | lv_result_0_2= rulectNumericalEnum | lv_result_0_3= rulectNominalOrdinalVariable | lv_result_0_4= rulectOrdinalVariable ) ) ) ;
    public final EObject rulectMeasuredVariable() throws RecognitionException {
        EObject current = null;

        EObject lv_result_0_1 = null;

        EObject lv_result_0_2 = null;

        EObject lv_result_0_3 = null;

        EObject lv_result_0_4 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:337:2: ( ( ( (lv_result_0_1= rulectNumericalVariable | lv_result_0_2= rulectNumericalEnum | lv_result_0_3= rulectNominalOrdinalVariable | lv_result_0_4= rulectOrdinalVariable ) ) ) )
            // InternalUmlModel.g:338:2: ( ( (lv_result_0_1= rulectNumericalVariable | lv_result_0_2= rulectNumericalEnum | lv_result_0_3= rulectNominalOrdinalVariable | lv_result_0_4= rulectOrdinalVariable ) ) )
            {
            // InternalUmlModel.g:338:2: ( ( (lv_result_0_1= rulectNumericalVariable | lv_result_0_2= rulectNumericalEnum | lv_result_0_3= rulectNominalOrdinalVariable | lv_result_0_4= rulectOrdinalVariable ) ) )
            // InternalUmlModel.g:339:3: ( (lv_result_0_1= rulectNumericalVariable | lv_result_0_2= rulectNumericalEnum | lv_result_0_3= rulectNominalOrdinalVariable | lv_result_0_4= rulectOrdinalVariable ) )
            {
            // InternalUmlModel.g:339:3: ( (lv_result_0_1= rulectNumericalVariable | lv_result_0_2= rulectNumericalEnum | lv_result_0_3= rulectNominalOrdinalVariable | lv_result_0_4= rulectOrdinalVariable ) )
            // InternalUmlModel.g:340:4: (lv_result_0_1= rulectNumericalVariable | lv_result_0_2= rulectNumericalEnum | lv_result_0_3= rulectNominalOrdinalVariable | lv_result_0_4= rulectOrdinalVariable )
            {
            // InternalUmlModel.g:340:4: (lv_result_0_1= rulectNumericalVariable | lv_result_0_2= rulectNumericalEnum | lv_result_0_3= rulectNominalOrdinalVariable | lv_result_0_4= rulectOrdinalVariable )
            int alt4=4;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==15) ) {
                int LA4_1 = input.LA(2);

                if ( (LA4_1==RULE_STRING||LA4_1==17) ) {
                    alt4=4;
                }
                else if ( (LA4_1==RULE_INT) ) {
                    alt4=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA4_0==20) ) {
                int LA4_2 = input.LA(2);

                if ( (LA4_2==RULE_STRING) ) {
                    alt4=3;
                }
                else if ( (LA4_2==RULE_INT) ) {
                    alt4=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalUmlModel.g:341:5: lv_result_0_1= rulectNumericalVariable
                    {

                    					newCompositeNode(grammarAccess.getCtMeasuredVariableAccess().getResultCtNumericalVariableParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_result_0_1=rulectNumericalVariable();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtMeasuredVariableRule());
                    					}
                    					set(
                    						current,
                    						"result",
                    						lv_result_0_1,
                    						"tesma.ovanes.UmlModel.ctNumericalVariable");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 2 :
                    // InternalUmlModel.g:357:5: lv_result_0_2= rulectNumericalEnum
                    {

                    					newCompositeNode(grammarAccess.getCtMeasuredVariableAccess().getResultCtNumericalEnumParserRuleCall_0_1());
                    				
                    pushFollow(FOLLOW_2);
                    lv_result_0_2=rulectNumericalEnum();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtMeasuredVariableRule());
                    					}
                    					set(
                    						current,
                    						"result",
                    						lv_result_0_2,
                    						"tesma.ovanes.UmlModel.ctNumericalEnum");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 3 :
                    // InternalUmlModel.g:373:5: lv_result_0_3= rulectNominalOrdinalVariable
                    {

                    					newCompositeNode(grammarAccess.getCtMeasuredVariableAccess().getResultCtNominalOrdinalVariableParserRuleCall_0_2());
                    				
                    pushFollow(FOLLOW_2);
                    lv_result_0_3=rulectNominalOrdinalVariable();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtMeasuredVariableRule());
                    					}
                    					set(
                    						current,
                    						"result",
                    						lv_result_0_3,
                    						"tesma.ovanes.UmlModel.ctNominalOrdinalVariable");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 4 :
                    // InternalUmlModel.g:389:5: lv_result_0_4= rulectOrdinalVariable
                    {

                    					newCompositeNode(grammarAccess.getCtMeasuredVariableAccess().getResultCtOrdinalVariableParserRuleCall_0_3());
                    				
                    pushFollow(FOLLOW_2);
                    lv_result_0_4=rulectOrdinalVariable();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtMeasuredVariableRule());
                    					}
                    					set(
                    						current,
                    						"result",
                    						lv_result_0_4,
                    						"tesma.ovanes.UmlModel.ctOrdinalVariable");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectMeasuredVariable"


    // $ANTLR start "entryRulectNumericalVariable"
    // InternalUmlModel.g:410:1: entryRulectNumericalVariable returns [EObject current=null] : iv_rulectNumericalVariable= rulectNumericalVariable EOF ;
    public final EObject entryRulectNumericalVariable() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectNumericalVariable = null;


        try {
            // InternalUmlModel.g:410:60: (iv_rulectNumericalVariable= rulectNumericalVariable EOF )
            // InternalUmlModel.g:411:2: iv_rulectNumericalVariable= rulectNumericalVariable EOF
            {
             newCompositeNode(grammarAccess.getCtNumericalVariableRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectNumericalVariable=rulectNumericalVariable();

            state._fsp--;

             current =iv_rulectNumericalVariable; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectNumericalVariable"


    // $ANTLR start "rulectNumericalVariable"
    // InternalUmlModel.g:417:1: rulectNumericalVariable returns [EObject current=null] : (otherlv_0= '[' ( (lv_lowerbound_1_0= RULE_INT ) ) otherlv_2= ',' ( (lv_upperbound_3_0= RULE_INT ) ) otherlv_4= ']' otherlv_5= 'with' otherlv_6= 'step' ( (lv_step_7_0= RULE_INT ) ) ) ;
    public final EObject rulectNumericalVariable() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_lowerbound_1_0=null;
        Token otherlv_2=null;
        Token lv_upperbound_3_0=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token lv_step_7_0=null;


        	enterRule();

        try {
            // InternalUmlModel.g:423:2: ( (otherlv_0= '[' ( (lv_lowerbound_1_0= RULE_INT ) ) otherlv_2= ',' ( (lv_upperbound_3_0= RULE_INT ) ) otherlv_4= ']' otherlv_5= 'with' otherlv_6= 'step' ( (lv_step_7_0= RULE_INT ) ) ) )
            // InternalUmlModel.g:424:2: (otherlv_0= '[' ( (lv_lowerbound_1_0= RULE_INT ) ) otherlv_2= ',' ( (lv_upperbound_3_0= RULE_INT ) ) otherlv_4= ']' otherlv_5= 'with' otherlv_6= 'step' ( (lv_step_7_0= RULE_INT ) ) )
            {
            // InternalUmlModel.g:424:2: (otherlv_0= '[' ( (lv_lowerbound_1_0= RULE_INT ) ) otherlv_2= ',' ( (lv_upperbound_3_0= RULE_INT ) ) otherlv_4= ']' otherlv_5= 'with' otherlv_6= 'step' ( (lv_step_7_0= RULE_INT ) ) )
            // InternalUmlModel.g:425:3: otherlv_0= '[' ( (lv_lowerbound_1_0= RULE_INT ) ) otherlv_2= ',' ( (lv_upperbound_3_0= RULE_INT ) ) otherlv_4= ']' otherlv_5= 'with' otherlv_6= 'step' ( (lv_step_7_0= RULE_INT ) )
            {
            otherlv_0=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getCtNumericalVariableAccess().getLeftSquareBracketKeyword_0());
            		
            // InternalUmlModel.g:429:3: ( (lv_lowerbound_1_0= RULE_INT ) )
            // InternalUmlModel.g:430:4: (lv_lowerbound_1_0= RULE_INT )
            {
            // InternalUmlModel.g:430:4: (lv_lowerbound_1_0= RULE_INT )
            // InternalUmlModel.g:431:5: lv_lowerbound_1_0= RULE_INT
            {
            lv_lowerbound_1_0=(Token)match(input,RULE_INT,FOLLOW_11); 

            					newLeafNode(lv_lowerbound_1_0, grammarAccess.getCtNumericalVariableAccess().getLowerboundINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtNumericalVariableRule());
            					}
            					setWithLastConsumed(
            						current,
            						"lowerbound",
            						lv_lowerbound_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_2=(Token)match(input,16,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getCtNumericalVariableAccess().getCommaKeyword_2());
            		
            // InternalUmlModel.g:451:3: ( (lv_upperbound_3_0= RULE_INT ) )
            // InternalUmlModel.g:452:4: (lv_upperbound_3_0= RULE_INT )
            {
            // InternalUmlModel.g:452:4: (lv_upperbound_3_0= RULE_INT )
            // InternalUmlModel.g:453:5: lv_upperbound_3_0= RULE_INT
            {
            lv_upperbound_3_0=(Token)match(input,RULE_INT,FOLLOW_12); 

            					newLeafNode(lv_upperbound_3_0, grammarAccess.getCtNumericalVariableAccess().getUpperboundINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtNumericalVariableRule());
            					}
            					setWithLastConsumed(
            						current,
            						"upperbound",
            						lv_upperbound_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_4=(Token)match(input,17,FOLLOW_13); 

            			newLeafNode(otherlv_4, grammarAccess.getCtNumericalVariableAccess().getRightSquareBracketKeyword_4());
            		
            otherlv_5=(Token)match(input,18,FOLLOW_14); 

            			newLeafNode(otherlv_5, grammarAccess.getCtNumericalVariableAccess().getWithKeyword_5());
            		
            otherlv_6=(Token)match(input,19,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getCtNumericalVariableAccess().getStepKeyword_6());
            		
            // InternalUmlModel.g:481:3: ( (lv_step_7_0= RULE_INT ) )
            // InternalUmlModel.g:482:4: (lv_step_7_0= RULE_INT )
            {
            // InternalUmlModel.g:482:4: (lv_step_7_0= RULE_INT )
            // InternalUmlModel.g:483:5: lv_step_7_0= RULE_INT
            {
            lv_step_7_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            					newLeafNode(lv_step_7_0, grammarAccess.getCtNumericalVariableAccess().getStepINTTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtNumericalVariableRule());
            					}
            					setWithLastConsumed(
            						current,
            						"step",
            						lv_step_7_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectNumericalVariable"


    // $ANTLR start "entryRulectNumericalEnum"
    // InternalUmlModel.g:503:1: entryRulectNumericalEnum returns [EObject current=null] : iv_rulectNumericalEnum= rulectNumericalEnum EOF ;
    public final EObject entryRulectNumericalEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectNumericalEnum = null;


        try {
            // InternalUmlModel.g:503:56: (iv_rulectNumericalEnum= rulectNumericalEnum EOF )
            // InternalUmlModel.g:504:2: iv_rulectNumericalEnum= rulectNumericalEnum EOF
            {
             newCompositeNode(grammarAccess.getCtNumericalEnumRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectNumericalEnum=rulectNumericalEnum();

            state._fsp--;

             current =iv_rulectNumericalEnum; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectNumericalEnum"


    // $ANTLR start "rulectNumericalEnum"
    // InternalUmlModel.g:510:1: rulectNumericalEnum returns [EObject current=null] : (otherlv_0= '{' ( (lv_numericalenum_1_0= RULE_INT ) ) (otherlv_2= ',' ( (lv_numericalenum_3_0= RULE_INT ) ) )* otherlv_4= '}' ) ;
    public final EObject rulectNumericalEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_numericalenum_1_0=null;
        Token otherlv_2=null;
        Token lv_numericalenum_3_0=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalUmlModel.g:516:2: ( (otherlv_0= '{' ( (lv_numericalenum_1_0= RULE_INT ) ) (otherlv_2= ',' ( (lv_numericalenum_3_0= RULE_INT ) ) )* otherlv_4= '}' ) )
            // InternalUmlModel.g:517:2: (otherlv_0= '{' ( (lv_numericalenum_1_0= RULE_INT ) ) (otherlv_2= ',' ( (lv_numericalenum_3_0= RULE_INT ) ) )* otherlv_4= '}' )
            {
            // InternalUmlModel.g:517:2: (otherlv_0= '{' ( (lv_numericalenum_1_0= RULE_INT ) ) (otherlv_2= ',' ( (lv_numericalenum_3_0= RULE_INT ) ) )* otherlv_4= '}' )
            // InternalUmlModel.g:518:3: otherlv_0= '{' ( (lv_numericalenum_1_0= RULE_INT ) ) (otherlv_2= ',' ( (lv_numericalenum_3_0= RULE_INT ) ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,20,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getCtNumericalEnumAccess().getLeftCurlyBracketKeyword_0());
            		
            // InternalUmlModel.g:522:3: ( (lv_numericalenum_1_0= RULE_INT ) )
            // InternalUmlModel.g:523:4: (lv_numericalenum_1_0= RULE_INT )
            {
            // InternalUmlModel.g:523:4: (lv_numericalenum_1_0= RULE_INT )
            // InternalUmlModel.g:524:5: lv_numericalenum_1_0= RULE_INT
            {
            lv_numericalenum_1_0=(Token)match(input,RULE_INT,FOLLOW_15); 

            					newLeafNode(lv_numericalenum_1_0, grammarAccess.getCtNumericalEnumAccess().getNumericalenumINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtNumericalEnumRule());
            					}
            					addWithLastConsumed(
            						current,
            						"numericalenum",
            						lv_numericalenum_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalUmlModel.g:540:3: (otherlv_2= ',' ( (lv_numericalenum_3_0= RULE_INT ) ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==16) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalUmlModel.g:541:4: otherlv_2= ',' ( (lv_numericalenum_3_0= RULE_INT ) )
            	    {
            	    otherlv_2=(Token)match(input,16,FOLLOW_6); 

            	    				newLeafNode(otherlv_2, grammarAccess.getCtNumericalEnumAccess().getCommaKeyword_2_0());
            	    			
            	    // InternalUmlModel.g:545:4: ( (lv_numericalenum_3_0= RULE_INT ) )
            	    // InternalUmlModel.g:546:5: (lv_numericalenum_3_0= RULE_INT )
            	    {
            	    // InternalUmlModel.g:546:5: (lv_numericalenum_3_0= RULE_INT )
            	    // InternalUmlModel.g:547:6: lv_numericalenum_3_0= RULE_INT
            	    {
            	    lv_numericalenum_3_0=(Token)match(input,RULE_INT,FOLLOW_15); 

            	    						newLeafNode(lv_numericalenum_3_0, grammarAccess.getCtNumericalEnumAccess().getNumericalenumINTTerminalRuleCall_2_1_0());
            	    					

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getCtNumericalEnumRule());
            	    						}
            	    						addWithLastConsumed(
            	    							current,
            	    							"numericalenum",
            	    							lv_numericalenum_3_0,
            	    							"org.eclipse.xtext.common.Terminals.INT");
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            otherlv_4=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getCtNumericalEnumAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectNumericalEnum"


    // $ANTLR start "entryRulectNominalOrdinalVariable"
    // InternalUmlModel.g:572:1: entryRulectNominalOrdinalVariable returns [EObject current=null] : iv_rulectNominalOrdinalVariable= rulectNominalOrdinalVariable EOF ;
    public final EObject entryRulectNominalOrdinalVariable() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectNominalOrdinalVariable = null;


        try {
            // InternalUmlModel.g:572:65: (iv_rulectNominalOrdinalVariable= rulectNominalOrdinalVariable EOF )
            // InternalUmlModel.g:573:2: iv_rulectNominalOrdinalVariable= rulectNominalOrdinalVariable EOF
            {
             newCompositeNode(grammarAccess.getCtNominalOrdinalVariableRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectNominalOrdinalVariable=rulectNominalOrdinalVariable();

            state._fsp--;

             current =iv_rulectNominalOrdinalVariable; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectNominalOrdinalVariable"


    // $ANTLR start "rulectNominalOrdinalVariable"
    // InternalUmlModel.g:579:1: rulectNominalOrdinalVariable returns [EObject current=null] : (otherlv_0= '{' ( (lv_nominalvariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_decription_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_nominalvariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) )* otherlv_8= '}' ) ;
    public final EObject rulectNominalOrdinalVariable() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nominalvariable_1_0=null;
        Token otherlv_2=null;
        Token lv_decription_3_0=null;
        Token otherlv_4=null;
        Token lv_nominalvariable_5_0=null;
        Token otherlv_6=null;
        Token lv_description_7_0=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalUmlModel.g:585:2: ( (otherlv_0= '{' ( (lv_nominalvariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_decription_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_nominalvariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) )* otherlv_8= '}' ) )
            // InternalUmlModel.g:586:2: (otherlv_0= '{' ( (lv_nominalvariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_decription_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_nominalvariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) )* otherlv_8= '}' )
            {
            // InternalUmlModel.g:586:2: (otherlv_0= '{' ( (lv_nominalvariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_decription_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_nominalvariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) )* otherlv_8= '}' )
            // InternalUmlModel.g:587:3: otherlv_0= '{' ( (lv_nominalvariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_decription_3_0= RULE_STRING ) ) (otherlv_4= ',' ( (lv_nominalvariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) )* otherlv_8= '}'
            {
            otherlv_0=(Token)match(input,20,FOLLOW_10); 

            			newLeafNode(otherlv_0, grammarAccess.getCtNominalOrdinalVariableAccess().getLeftCurlyBracketKeyword_0());
            		
            // InternalUmlModel.g:591:3: ( (lv_nominalvariable_1_0= RULE_STRING ) )
            // InternalUmlModel.g:592:4: (lv_nominalvariable_1_0= RULE_STRING )
            {
            // InternalUmlModel.g:592:4: (lv_nominalvariable_1_0= RULE_STRING )
            // InternalUmlModel.g:593:5: lv_nominalvariable_1_0= RULE_STRING
            {
            lv_nominalvariable_1_0=(Token)match(input,RULE_STRING,FOLLOW_16); 

            					newLeafNode(lv_nominalvariable_1_0, grammarAccess.getCtNominalOrdinalVariableAccess().getNominalvariableSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtNominalOrdinalVariableRule());
            					}
            					addWithLastConsumed(
            						current,
            						"nominalvariable",
            						lv_nominalvariable_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_2=(Token)match(input,22,FOLLOW_10); 

            			newLeafNode(otherlv_2, grammarAccess.getCtNominalOrdinalVariableAccess().getColonKeyword_2());
            		
            // InternalUmlModel.g:613:3: ( (lv_decription_3_0= RULE_STRING ) )
            // InternalUmlModel.g:614:4: (lv_decription_3_0= RULE_STRING )
            {
            // InternalUmlModel.g:614:4: (lv_decription_3_0= RULE_STRING )
            // InternalUmlModel.g:615:5: lv_decription_3_0= RULE_STRING
            {
            lv_decription_3_0=(Token)match(input,RULE_STRING,FOLLOW_15); 

            					newLeafNode(lv_decription_3_0, grammarAccess.getCtNominalOrdinalVariableAccess().getDecriptionSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtNominalOrdinalVariableRule());
            					}
            					addWithLastConsumed(
            						current,
            						"decription",
            						lv_decription_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalUmlModel.g:631:3: (otherlv_4= ',' ( (lv_nominalvariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==16) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalUmlModel.g:632:4: otherlv_4= ',' ( (lv_nominalvariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) )
            	    {
            	    otherlv_4=(Token)match(input,16,FOLLOW_10); 

            	    				newLeafNode(otherlv_4, grammarAccess.getCtNominalOrdinalVariableAccess().getCommaKeyword_4_0());
            	    			
            	    // InternalUmlModel.g:636:4: ( (lv_nominalvariable_5_0= RULE_STRING ) )
            	    // InternalUmlModel.g:637:5: (lv_nominalvariable_5_0= RULE_STRING )
            	    {
            	    // InternalUmlModel.g:637:5: (lv_nominalvariable_5_0= RULE_STRING )
            	    // InternalUmlModel.g:638:6: lv_nominalvariable_5_0= RULE_STRING
            	    {
            	    lv_nominalvariable_5_0=(Token)match(input,RULE_STRING,FOLLOW_16); 

            	    						newLeafNode(lv_nominalvariable_5_0, grammarAccess.getCtNominalOrdinalVariableAccess().getNominalvariableSTRINGTerminalRuleCall_4_1_0());
            	    					

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getCtNominalOrdinalVariableRule());
            	    						}
            	    						addWithLastConsumed(
            	    							current,
            	    							"nominalvariable",
            	    							lv_nominalvariable_5_0,
            	    							"org.eclipse.xtext.common.Terminals.STRING");
            	    					

            	    }


            	    }

            	    otherlv_6=(Token)match(input,22,FOLLOW_10); 

            	    				newLeafNode(otherlv_6, grammarAccess.getCtNominalOrdinalVariableAccess().getColonKeyword_4_2());
            	    			
            	    // InternalUmlModel.g:658:4: ( (lv_description_7_0= RULE_STRING ) )
            	    // InternalUmlModel.g:659:5: (lv_description_7_0= RULE_STRING )
            	    {
            	    // InternalUmlModel.g:659:5: (lv_description_7_0= RULE_STRING )
            	    // InternalUmlModel.g:660:6: lv_description_7_0= RULE_STRING
            	    {
            	    lv_description_7_0=(Token)match(input,RULE_STRING,FOLLOW_15); 

            	    						newLeafNode(lv_description_7_0, grammarAccess.getCtNominalOrdinalVariableAccess().getDescriptionSTRINGTerminalRuleCall_4_3_0());
            	    					

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getCtNominalOrdinalVariableRule());
            	    						}
            	    						addWithLastConsumed(
            	    							current,
            	    							"description",
            	    							lv_description_7_0,
            	    							"org.eclipse.xtext.common.Terminals.STRING");
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            otherlv_8=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getCtNominalOrdinalVariableAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectNominalOrdinalVariable"


    // $ANTLR start "entryRulectOrdinalVariable"
    // InternalUmlModel.g:685:1: entryRulectOrdinalVariable returns [EObject current=null] : iv_rulectOrdinalVariable= rulectOrdinalVariable EOF ;
    public final EObject entryRulectOrdinalVariable() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectOrdinalVariable = null;


        try {
            // InternalUmlModel.g:685:58: (iv_rulectOrdinalVariable= rulectOrdinalVariable EOF )
            // InternalUmlModel.g:686:2: iv_rulectOrdinalVariable= rulectOrdinalVariable EOF
            {
             newCompositeNode(grammarAccess.getCtOrdinalVariableRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectOrdinalVariable=rulectOrdinalVariable();

            state._fsp--;

             current =iv_rulectOrdinalVariable; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectOrdinalVariable"


    // $ANTLR start "rulectOrdinalVariable"
    // InternalUmlModel.g:692:1: rulectOrdinalVariable returns [EObject current=null] : (otherlv_0= '[' ( ( (lv_ordinalVariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_description_3_0= RULE_STRING ) ) (otherlv_4= '-' ( (lv_ordinalVariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) ) )* otherlv_8= ']' ) ;
    public final EObject rulectOrdinalVariable() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_ordinalVariable_1_0=null;
        Token otherlv_2=null;
        Token lv_description_3_0=null;
        Token otherlv_4=null;
        Token lv_ordinalVariable_5_0=null;
        Token otherlv_6=null;
        Token lv_description_7_0=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalUmlModel.g:698:2: ( (otherlv_0= '[' ( ( (lv_ordinalVariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_description_3_0= RULE_STRING ) ) (otherlv_4= '-' ( (lv_ordinalVariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) ) )* otherlv_8= ']' ) )
            // InternalUmlModel.g:699:2: (otherlv_0= '[' ( ( (lv_ordinalVariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_description_3_0= RULE_STRING ) ) (otherlv_4= '-' ( (lv_ordinalVariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) ) )* otherlv_8= ']' )
            {
            // InternalUmlModel.g:699:2: (otherlv_0= '[' ( ( (lv_ordinalVariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_description_3_0= RULE_STRING ) ) (otherlv_4= '-' ( (lv_ordinalVariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) ) )* otherlv_8= ']' )
            // InternalUmlModel.g:700:3: otherlv_0= '[' ( ( (lv_ordinalVariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_description_3_0= RULE_STRING ) ) (otherlv_4= '-' ( (lv_ordinalVariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) ) )* otherlv_8= ']'
            {
            otherlv_0=(Token)match(input,15,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getCtOrdinalVariableAccess().getLeftSquareBracketKeyword_0());
            		
            // InternalUmlModel.g:704:3: ( ( (lv_ordinalVariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_description_3_0= RULE_STRING ) ) (otherlv_4= '-' ( (lv_ordinalVariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==RULE_STRING) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalUmlModel.g:705:4: ( (lv_ordinalVariable_1_0= RULE_STRING ) ) otherlv_2= ':' ( (lv_description_3_0= RULE_STRING ) ) (otherlv_4= '-' ( (lv_ordinalVariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) )
            	    {
            	    // InternalUmlModel.g:705:4: ( (lv_ordinalVariable_1_0= RULE_STRING ) )
            	    // InternalUmlModel.g:706:5: (lv_ordinalVariable_1_0= RULE_STRING )
            	    {
            	    // InternalUmlModel.g:706:5: (lv_ordinalVariable_1_0= RULE_STRING )
            	    // InternalUmlModel.g:707:6: lv_ordinalVariable_1_0= RULE_STRING
            	    {
            	    lv_ordinalVariable_1_0=(Token)match(input,RULE_STRING,FOLLOW_16); 

            	    						newLeafNode(lv_ordinalVariable_1_0, grammarAccess.getCtOrdinalVariableAccess().getOrdinalVariableSTRINGTerminalRuleCall_1_0_0());
            	    					

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getCtOrdinalVariableRule());
            	    						}
            	    						addWithLastConsumed(
            	    							current,
            	    							"ordinalVariable",
            	    							lv_ordinalVariable_1_0,
            	    							"org.eclipse.xtext.common.Terminals.STRING");
            	    					

            	    }


            	    }

            	    otherlv_2=(Token)match(input,22,FOLLOW_10); 

            	    				newLeafNode(otherlv_2, grammarAccess.getCtOrdinalVariableAccess().getColonKeyword_1_1());
            	    			
            	    // InternalUmlModel.g:727:4: ( (lv_description_3_0= RULE_STRING ) )
            	    // InternalUmlModel.g:728:5: (lv_description_3_0= RULE_STRING )
            	    {
            	    // InternalUmlModel.g:728:5: (lv_description_3_0= RULE_STRING )
            	    // InternalUmlModel.g:729:6: lv_description_3_0= RULE_STRING
            	    {
            	    lv_description_3_0=(Token)match(input,RULE_STRING,FOLLOW_18); 

            	    						newLeafNode(lv_description_3_0, grammarAccess.getCtOrdinalVariableAccess().getDescriptionSTRINGTerminalRuleCall_1_2_0());
            	    					

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getCtOrdinalVariableRule());
            	    						}
            	    						addWithLastConsumed(
            	    							current,
            	    							"description",
            	    							lv_description_3_0,
            	    							"org.eclipse.xtext.common.Terminals.STRING");
            	    					

            	    }


            	    }

            	    // InternalUmlModel.g:745:4: (otherlv_4= '-' ( (lv_ordinalVariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) ) )
            	    // InternalUmlModel.g:746:5: otherlv_4= '-' ( (lv_ordinalVariable_5_0= RULE_STRING ) ) otherlv_6= ':' ( (lv_description_7_0= RULE_STRING ) )
            	    {
            	    otherlv_4=(Token)match(input,23,FOLLOW_10); 

            	    					newLeafNode(otherlv_4, grammarAccess.getCtOrdinalVariableAccess().getHyphenMinusKeyword_1_3_0());
            	    				
            	    // InternalUmlModel.g:750:5: ( (lv_ordinalVariable_5_0= RULE_STRING ) )
            	    // InternalUmlModel.g:751:6: (lv_ordinalVariable_5_0= RULE_STRING )
            	    {
            	    // InternalUmlModel.g:751:6: (lv_ordinalVariable_5_0= RULE_STRING )
            	    // InternalUmlModel.g:752:7: lv_ordinalVariable_5_0= RULE_STRING
            	    {
            	    lv_ordinalVariable_5_0=(Token)match(input,RULE_STRING,FOLLOW_16); 

            	    							newLeafNode(lv_ordinalVariable_5_0, grammarAccess.getCtOrdinalVariableAccess().getOrdinalVariableSTRINGTerminalRuleCall_1_3_1_0());
            	    						

            	    							if (current==null) {
            	    								current = createModelElement(grammarAccess.getCtOrdinalVariableRule());
            	    							}
            	    							addWithLastConsumed(
            	    								current,
            	    								"ordinalVariable",
            	    								lv_ordinalVariable_5_0,
            	    								"org.eclipse.xtext.common.Terminals.STRING");
            	    						

            	    }


            	    }

            	    otherlv_6=(Token)match(input,22,FOLLOW_10); 

            	    					newLeafNode(otherlv_6, grammarAccess.getCtOrdinalVariableAccess().getColonKeyword_1_3_2());
            	    				
            	    // InternalUmlModel.g:772:5: ( (lv_description_7_0= RULE_STRING ) )
            	    // InternalUmlModel.g:773:6: (lv_description_7_0= RULE_STRING )
            	    {
            	    // InternalUmlModel.g:773:6: (lv_description_7_0= RULE_STRING )
            	    // InternalUmlModel.g:774:7: lv_description_7_0= RULE_STRING
            	    {
            	    lv_description_7_0=(Token)match(input,RULE_STRING,FOLLOW_17); 

            	    							newLeafNode(lv_description_7_0, grammarAccess.getCtOrdinalVariableAccess().getDescriptionSTRINGTerminalRuleCall_1_3_3_0());
            	    						

            	    							if (current==null) {
            	    								current = createModelElement(grammarAccess.getCtOrdinalVariableRule());
            	    							}
            	    							addWithLastConsumed(
            	    								current,
            	    								"description",
            	    								lv_description_7_0,
            	    								"org.eclipse.xtext.common.Terminals.STRING");
            	    						

            	    }


            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            otherlv_8=(Token)match(input,17,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getCtOrdinalVariableAccess().getRightSquareBracketKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectOrdinalVariable"


    // $ANTLR start "entryRulectCategory"
    // InternalUmlModel.g:800:1: entryRulectCategory returns [EObject current=null] : iv_rulectCategory= rulectCategory EOF ;
    public final EObject entryRulectCategory() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectCategory = null;


        try {
            // InternalUmlModel.g:800:51: (iv_rulectCategory= rulectCategory EOF )
            // InternalUmlModel.g:801:2: iv_rulectCategory= rulectCategory EOF
            {
             newCompositeNode(grammarAccess.getCtCategoryRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectCategory=rulectCategory();

            state._fsp--;

             current =iv_rulectCategory; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectCategory"


    // $ANTLR start "rulectCategory"
    // InternalUmlModel.g:807:1: rulectCategory returns [EObject current=null] : (otherlv_0= 'GradingCategory' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_weight_3_0= RULE_INT ) ) (otherlv_4= 'contains' otherlv_5= 'gradingCriteriaa' ( ( ruleFQN ) ) (otherlv_7= ',' ( ( ruleFQN ) ) )* )? (otherlv_9= 'points' ( (lv_evaluation_10_0= rulectMeasuredVariable ) ) )? (otherlv_11= 'description' ( (lv_description_12_0= RULE_STRING ) ) )? ) ;
    public final EObject rulectCategory() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_weight_3_0=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token lv_description_12_0=null;
        EObject lv_evaluation_10_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:813:2: ( (otherlv_0= 'GradingCategory' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_weight_3_0= RULE_INT ) ) (otherlv_4= 'contains' otherlv_5= 'gradingCriteriaa' ( ( ruleFQN ) ) (otherlv_7= ',' ( ( ruleFQN ) ) )* )? (otherlv_9= 'points' ( (lv_evaluation_10_0= rulectMeasuredVariable ) ) )? (otherlv_11= 'description' ( (lv_description_12_0= RULE_STRING ) ) )? ) )
            // InternalUmlModel.g:814:2: (otherlv_0= 'GradingCategory' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_weight_3_0= RULE_INT ) ) (otherlv_4= 'contains' otherlv_5= 'gradingCriteriaa' ( ( ruleFQN ) ) (otherlv_7= ',' ( ( ruleFQN ) ) )* )? (otherlv_9= 'points' ( (lv_evaluation_10_0= rulectMeasuredVariable ) ) )? (otherlv_11= 'description' ( (lv_description_12_0= RULE_STRING ) ) )? )
            {
            // InternalUmlModel.g:814:2: (otherlv_0= 'GradingCategory' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_weight_3_0= RULE_INT ) ) (otherlv_4= 'contains' otherlv_5= 'gradingCriteriaa' ( ( ruleFQN ) ) (otherlv_7= ',' ( ( ruleFQN ) ) )* )? (otherlv_9= 'points' ( (lv_evaluation_10_0= rulectMeasuredVariable ) ) )? (otherlv_11= 'description' ( (lv_description_12_0= RULE_STRING ) ) )? )
            // InternalUmlModel.g:815:3: otherlv_0= 'GradingCategory' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_weight_3_0= RULE_INT ) ) (otherlv_4= 'contains' otherlv_5= 'gradingCriteriaa' ( ( ruleFQN ) ) (otherlv_7= ',' ( ( ruleFQN ) ) )* )? (otherlv_9= 'points' ( (lv_evaluation_10_0= rulectMeasuredVariable ) ) )? (otherlv_11= 'description' ( (lv_description_12_0= RULE_STRING ) ) )?
            {
            otherlv_0=(Token)match(input,24,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtCategoryAccess().getGradingCategoryKeyword_0());
            		
            // InternalUmlModel.g:819:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:820:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:820:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:821:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtCategoryAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtCategoryRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getCtCategoryAccess().getWeightKeyword_2());
            		
            // InternalUmlModel.g:841:3: ( (lv_weight_3_0= RULE_INT ) )
            // InternalUmlModel.g:842:4: (lv_weight_3_0= RULE_INT )
            {
            // InternalUmlModel.g:842:4: (lv_weight_3_0= RULE_INT )
            // InternalUmlModel.g:843:5: lv_weight_3_0= RULE_INT
            {
            lv_weight_3_0=(Token)match(input,RULE_INT,FOLLOW_19); 

            					newLeafNode(lv_weight_3_0, grammarAccess.getCtCategoryAccess().getWeightINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtCategoryRule());
            					}
            					setWithLastConsumed(
            						current,
            						"weight",
            						lv_weight_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalUmlModel.g:859:3: (otherlv_4= 'contains' otherlv_5= 'gradingCriteriaa' ( ( ruleFQN ) ) (otherlv_7= ',' ( ( ruleFQN ) ) )* )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==25) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalUmlModel.g:860:4: otherlv_4= 'contains' otherlv_5= 'gradingCriteriaa' ( ( ruleFQN ) ) (otherlv_7= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_4=(Token)match(input,25,FOLLOW_20); 

                    				newLeafNode(otherlv_4, grammarAccess.getCtCategoryAccess().getContainsKeyword_4_0());
                    			
                    otherlv_5=(Token)match(input,26,FOLLOW_4); 

                    				newLeafNode(otherlv_5, grammarAccess.getCtCategoryAccess().getGradingCriteriaaKeyword_4_1());
                    			
                    // InternalUmlModel.g:868:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:869:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:869:5: ( ruleFQN )
                    // InternalUmlModel.g:870:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCategoryRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtCategoryAccess().getRnctCriteriaCtCriteriaCrossReference_4_2_0());
                    					
                    pushFollow(FOLLOW_21);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:884:4: (otherlv_7= ',' ( ( ruleFQN ) ) )*
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( (LA8_0==16) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // InternalUmlModel.g:885:5: otherlv_7= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_7=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_7, grammarAccess.getCtCategoryAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalUmlModel.g:889:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:890:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:890:6: ( ruleFQN )
                    	    // InternalUmlModel.g:891:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtCategoryRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtCategoryAccess().getRnctCriteriaCtCriteriaCrossReference_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_21);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop8;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:907:3: (otherlv_9= 'points' ( (lv_evaluation_10_0= rulectMeasuredVariable ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==13) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalUmlModel.g:908:4: otherlv_9= 'points' ( (lv_evaluation_10_0= rulectMeasuredVariable ) )
                    {
                    otherlv_9=(Token)match(input,13,FOLLOW_8); 

                    				newLeafNode(otherlv_9, grammarAccess.getCtCategoryAccess().getPointsKeyword_5_0());
                    			
                    // InternalUmlModel.g:912:4: ( (lv_evaluation_10_0= rulectMeasuredVariable ) )
                    // InternalUmlModel.g:913:5: (lv_evaluation_10_0= rulectMeasuredVariable )
                    {
                    // InternalUmlModel.g:913:5: (lv_evaluation_10_0= rulectMeasuredVariable )
                    // InternalUmlModel.g:914:6: lv_evaluation_10_0= rulectMeasuredVariable
                    {

                    						newCompositeNode(grammarAccess.getCtCategoryAccess().getEvaluationCtMeasuredVariableParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_22);
                    lv_evaluation_10_0=rulectMeasuredVariable();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCtCategoryRule());
                    						}
                    						set(
                    							current,
                    							"evaluation",
                    							lv_evaluation_10_0,
                    							"tesma.ovanes.UmlModel.ctMeasuredVariable");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:932:3: (otherlv_11= 'description' ( (lv_description_12_0= RULE_STRING ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==14) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalUmlModel.g:933:4: otherlv_11= 'description' ( (lv_description_12_0= RULE_STRING ) )
                    {
                    otherlv_11=(Token)match(input,14,FOLLOW_10); 

                    				newLeafNode(otherlv_11, grammarAccess.getCtCategoryAccess().getDescriptionKeyword_6_0());
                    			
                    // InternalUmlModel.g:937:4: ( (lv_description_12_0= RULE_STRING ) )
                    // InternalUmlModel.g:938:5: (lv_description_12_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:938:5: (lv_description_12_0= RULE_STRING )
                    // InternalUmlModel.g:939:6: lv_description_12_0= RULE_STRING
                    {
                    lv_description_12_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    						newLeafNode(lv_description_12_0, grammarAccess.getCtCategoryAccess().getDescriptionSTRINGTerminalRuleCall_6_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCategoryRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"description",
                    							lv_description_12_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectCategory"


    // $ANTLR start "entryRulectTest"
    // InternalUmlModel.g:960:1: entryRulectTest returns [EObject current=null] : iv_rulectTest= rulectTest EOF ;
    public final EObject entryRulectTest() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectTest = null;


        try {
            // InternalUmlModel.g:960:47: (iv_rulectTest= rulectTest EOF )
            // InternalUmlModel.g:961:2: iv_rulectTest= rulectTest EOF
            {
             newCompositeNode(grammarAccess.getCtTestRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectTest=rulectTest();

            state._fsp--;

             current =iv_rulectTest; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectTest"


    // $ANTLR start "rulectTest"
    // InternalUmlModel.g:967:1: rulectTest returns [EObject current=null] : (otherlv_0= 'Test' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_value_3_0= RULE_INT ) ) (otherlv_4= 'covers' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? otherlv_8= '{' (otherlv_9= 'description' ( (lv_description_10_0= RULE_STRING ) ) )? (otherlv_11= 'rationale' ( (lv_ratonale_12_0= RULE_STRING ) ) )? (otherlv_13= 'grading' otherlv_14= 'categories' ( ( ruleFQN ) ) (otherlv_16= ',' ( ( ruleFQN ) ) )* )? (otherlv_18= 'correctors' ( ( ruleFQN ) ) (otherlv_20= ':' ( (lv_weight_21_0= RULE_INT ) ) )? (otherlv_22= ',' ( ( ruleFQN ) ) )* )? (otherlv_24= 'result' ( (lv_result_25_0= rulectMeasuredVariable ) ) )? ( (lv_rnLowerTest_26_0= rulectTest ) )* otherlv_27= '}' ) ;
    public final EObject rulectTest() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_value_3_0=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token lv_description_10_0=null;
        Token otherlv_11=null;
        Token lv_ratonale_12_0=null;
        Token otherlv_13=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_18=null;
        Token otherlv_20=null;
        Token lv_weight_21_0=null;
        Token otherlv_22=null;
        Token otherlv_24=null;
        Token otherlv_27=null;
        EObject lv_result_25_0 = null;

        EObject lv_rnLowerTest_26_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:973:2: ( (otherlv_0= 'Test' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_value_3_0= RULE_INT ) ) (otherlv_4= 'covers' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? otherlv_8= '{' (otherlv_9= 'description' ( (lv_description_10_0= RULE_STRING ) ) )? (otherlv_11= 'rationale' ( (lv_ratonale_12_0= RULE_STRING ) ) )? (otherlv_13= 'grading' otherlv_14= 'categories' ( ( ruleFQN ) ) (otherlv_16= ',' ( ( ruleFQN ) ) )* )? (otherlv_18= 'correctors' ( ( ruleFQN ) ) (otherlv_20= ':' ( (lv_weight_21_0= RULE_INT ) ) )? (otherlv_22= ',' ( ( ruleFQN ) ) )* )? (otherlv_24= 'result' ( (lv_result_25_0= rulectMeasuredVariable ) ) )? ( (lv_rnLowerTest_26_0= rulectTest ) )* otherlv_27= '}' ) )
            // InternalUmlModel.g:974:2: (otherlv_0= 'Test' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_value_3_0= RULE_INT ) ) (otherlv_4= 'covers' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? otherlv_8= '{' (otherlv_9= 'description' ( (lv_description_10_0= RULE_STRING ) ) )? (otherlv_11= 'rationale' ( (lv_ratonale_12_0= RULE_STRING ) ) )? (otherlv_13= 'grading' otherlv_14= 'categories' ( ( ruleFQN ) ) (otherlv_16= ',' ( ( ruleFQN ) ) )* )? (otherlv_18= 'correctors' ( ( ruleFQN ) ) (otherlv_20= ':' ( (lv_weight_21_0= RULE_INT ) ) )? (otherlv_22= ',' ( ( ruleFQN ) ) )* )? (otherlv_24= 'result' ( (lv_result_25_0= rulectMeasuredVariable ) ) )? ( (lv_rnLowerTest_26_0= rulectTest ) )* otherlv_27= '}' )
            {
            // InternalUmlModel.g:974:2: (otherlv_0= 'Test' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_value_3_0= RULE_INT ) ) (otherlv_4= 'covers' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? otherlv_8= '{' (otherlv_9= 'description' ( (lv_description_10_0= RULE_STRING ) ) )? (otherlv_11= 'rationale' ( (lv_ratonale_12_0= RULE_STRING ) ) )? (otherlv_13= 'grading' otherlv_14= 'categories' ( ( ruleFQN ) ) (otherlv_16= ',' ( ( ruleFQN ) ) )* )? (otherlv_18= 'correctors' ( ( ruleFQN ) ) (otherlv_20= ':' ( (lv_weight_21_0= RULE_INT ) ) )? (otherlv_22= ',' ( ( ruleFQN ) ) )* )? (otherlv_24= 'result' ( (lv_result_25_0= rulectMeasuredVariable ) ) )? ( (lv_rnLowerTest_26_0= rulectTest ) )* otherlv_27= '}' )
            // InternalUmlModel.g:975:3: otherlv_0= 'Test' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'weight' ( (lv_value_3_0= RULE_INT ) ) (otherlv_4= 'covers' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? otherlv_8= '{' (otherlv_9= 'description' ( (lv_description_10_0= RULE_STRING ) ) )? (otherlv_11= 'rationale' ( (lv_ratonale_12_0= RULE_STRING ) ) )? (otherlv_13= 'grading' otherlv_14= 'categories' ( ( ruleFQN ) ) (otherlv_16= ',' ( ( ruleFQN ) ) )* )? (otherlv_18= 'correctors' ( ( ruleFQN ) ) (otherlv_20= ':' ( (lv_weight_21_0= RULE_INT ) ) )? (otherlv_22= ',' ( ( ruleFQN ) ) )* )? (otherlv_24= 'result' ( (lv_result_25_0= rulectMeasuredVariable ) ) )? ( (lv_rnLowerTest_26_0= rulectTest ) )* otherlv_27= '}'
            {
            otherlv_0=(Token)match(input,27,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtTestAccess().getTestKeyword_0());
            		
            // InternalUmlModel.g:979:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:980:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:980:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:981:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtTestAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtTestRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getCtTestAccess().getWeightKeyword_2());
            		
            // InternalUmlModel.g:1001:3: ( (lv_value_3_0= RULE_INT ) )
            // InternalUmlModel.g:1002:4: (lv_value_3_0= RULE_INT )
            {
            // InternalUmlModel.g:1002:4: (lv_value_3_0= RULE_INT )
            // InternalUmlModel.g:1003:5: lv_value_3_0= RULE_INT
            {
            lv_value_3_0=(Token)match(input,RULE_INT,FOLLOW_23); 

            					newLeafNode(lv_value_3_0, grammarAccess.getCtTestAccess().getValueINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtTestRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalUmlModel.g:1019:3: (otherlv_4= 'covers' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==28) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalUmlModel.g:1020:4: otherlv_4= 'covers' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_4=(Token)match(input,28,FOLLOW_4); 

                    				newLeafNode(otherlv_4, grammarAccess.getCtTestAccess().getCoversKeyword_4_0());
                    			
                    // InternalUmlModel.g:1024:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:1025:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:1025:5: ( ruleFQN )
                    // InternalUmlModel.g:1026:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtTestRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtTestAccess().getRnstTaskCtTaskCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_24);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:1040:4: (otherlv_6= ',' ( ( ruleFQN ) ) )*
                    loop12:
                    do {
                        int alt12=2;
                        int LA12_0 = input.LA(1);

                        if ( (LA12_0==16) ) {
                            alt12=1;
                        }


                        switch (alt12) {
                    	case 1 :
                    	    // InternalUmlModel.g:1041:5: otherlv_6= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_6=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getCtTestAccess().getCommaKeyword_4_2_0());
                    	    				
                    	    // InternalUmlModel.g:1045:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:1046:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:1046:6: ( ruleFQN )
                    	    // InternalUmlModel.g:1047:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtTestRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtTestAccess().getRnctTaskCtTaskCrossReference_4_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_24);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop12;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_8=(Token)match(input,20,FOLLOW_25); 

            			newLeafNode(otherlv_8, grammarAccess.getCtTestAccess().getLeftCurlyBracketKeyword_5());
            		
            // InternalUmlModel.g:1067:3: (otherlv_9= 'description' ( (lv_description_10_0= RULE_STRING ) ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==14) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalUmlModel.g:1068:4: otherlv_9= 'description' ( (lv_description_10_0= RULE_STRING ) )
                    {
                    otherlv_9=(Token)match(input,14,FOLLOW_10); 

                    				newLeafNode(otherlv_9, grammarAccess.getCtTestAccess().getDescriptionKeyword_6_0());
                    			
                    // InternalUmlModel.g:1072:4: ( (lv_description_10_0= RULE_STRING ) )
                    // InternalUmlModel.g:1073:5: (lv_description_10_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:1073:5: (lv_description_10_0= RULE_STRING )
                    // InternalUmlModel.g:1074:6: lv_description_10_0= RULE_STRING
                    {
                    lv_description_10_0=(Token)match(input,RULE_STRING,FOLLOW_26); 

                    						newLeafNode(lv_description_10_0, grammarAccess.getCtTestAccess().getDescriptionSTRINGTerminalRuleCall_6_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtTestRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"description",
                    							lv_description_10_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1091:3: (otherlv_11= 'rationale' ( (lv_ratonale_12_0= RULE_STRING ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==29) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalUmlModel.g:1092:4: otherlv_11= 'rationale' ( (lv_ratonale_12_0= RULE_STRING ) )
                    {
                    otherlv_11=(Token)match(input,29,FOLLOW_10); 

                    				newLeafNode(otherlv_11, grammarAccess.getCtTestAccess().getRationaleKeyword_7_0());
                    			
                    // InternalUmlModel.g:1096:4: ( (lv_ratonale_12_0= RULE_STRING ) )
                    // InternalUmlModel.g:1097:5: (lv_ratonale_12_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:1097:5: (lv_ratonale_12_0= RULE_STRING )
                    // InternalUmlModel.g:1098:6: lv_ratonale_12_0= RULE_STRING
                    {
                    lv_ratonale_12_0=(Token)match(input,RULE_STRING,FOLLOW_27); 

                    						newLeafNode(lv_ratonale_12_0, grammarAccess.getCtTestAccess().getRatonaleSTRINGTerminalRuleCall_7_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtTestRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"ratonale",
                    							lv_ratonale_12_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1115:3: (otherlv_13= 'grading' otherlv_14= 'categories' ( ( ruleFQN ) ) (otherlv_16= ',' ( ( ruleFQN ) ) )* )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==30) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalUmlModel.g:1116:4: otherlv_13= 'grading' otherlv_14= 'categories' ( ( ruleFQN ) ) (otherlv_16= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_13=(Token)match(input,30,FOLLOW_28); 

                    				newLeafNode(otherlv_13, grammarAccess.getCtTestAccess().getGradingKeyword_8_0());
                    			
                    otherlv_14=(Token)match(input,31,FOLLOW_4); 

                    				newLeafNode(otherlv_14, grammarAccess.getCtTestAccess().getCategoriesKeyword_8_1());
                    			
                    // InternalUmlModel.g:1124:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:1125:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:1125:5: ( ruleFQN )
                    // InternalUmlModel.g:1126:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtTestRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtTestAccess().getRnctCategoryCtCategoryCrossReference_8_2_0());
                    					
                    pushFollow(FOLLOW_29);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:1140:4: (otherlv_16= ',' ( ( ruleFQN ) ) )*
                    loop16:
                    do {
                        int alt16=2;
                        int LA16_0 = input.LA(1);

                        if ( (LA16_0==16) ) {
                            alt16=1;
                        }


                        switch (alt16) {
                    	case 1 :
                    	    // InternalUmlModel.g:1141:5: otherlv_16= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_16=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_16, grammarAccess.getCtTestAccess().getCommaKeyword_8_3_0());
                    	    				
                    	    // InternalUmlModel.g:1145:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:1146:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:1146:6: ( ruleFQN )
                    	    // InternalUmlModel.g:1147:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtTestRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtTestAccess().getRnctCategoryCtCategoryCrossReference_8_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_29);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop16;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:1163:3: (otherlv_18= 'correctors' ( ( ruleFQN ) ) (otherlv_20= ':' ( (lv_weight_21_0= RULE_INT ) ) )? (otherlv_22= ',' ( ( ruleFQN ) ) )* )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==32) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalUmlModel.g:1164:4: otherlv_18= 'correctors' ( ( ruleFQN ) ) (otherlv_20= ':' ( (lv_weight_21_0= RULE_INT ) ) )? (otherlv_22= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_18=(Token)match(input,32,FOLLOW_4); 

                    				newLeafNode(otherlv_18, grammarAccess.getCtTestAccess().getCorrectorsKeyword_9_0());
                    			
                    // InternalUmlModel.g:1168:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:1169:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:1169:5: ( ruleFQN )
                    // InternalUmlModel.g:1170:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtTestRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtTestAccess().getRnctInstructorsCtInstructorCrossReference_9_1_0());
                    					
                    pushFollow(FOLLOW_30);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:1184:4: (otherlv_20= ':' ( (lv_weight_21_0= RULE_INT ) ) )?
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0==22) ) {
                        alt18=1;
                    }
                    switch (alt18) {
                        case 1 :
                            // InternalUmlModel.g:1185:5: otherlv_20= ':' ( (lv_weight_21_0= RULE_INT ) )
                            {
                            otherlv_20=(Token)match(input,22,FOLLOW_6); 

                            					newLeafNode(otherlv_20, grammarAccess.getCtTestAccess().getColonKeyword_9_2_0());
                            				
                            // InternalUmlModel.g:1189:5: ( (lv_weight_21_0= RULE_INT ) )
                            // InternalUmlModel.g:1190:6: (lv_weight_21_0= RULE_INT )
                            {
                            // InternalUmlModel.g:1190:6: (lv_weight_21_0= RULE_INT )
                            // InternalUmlModel.g:1191:7: lv_weight_21_0= RULE_INT
                            {
                            lv_weight_21_0=(Token)match(input,RULE_INT,FOLLOW_31); 

                            							newLeafNode(lv_weight_21_0, grammarAccess.getCtTestAccess().getWeightINTTerminalRuleCall_9_2_1_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getCtTestRule());
                            							}
                            							addWithLastConsumed(
                            								current,
                            								"weight",
                            								lv_weight_21_0,
                            								"org.eclipse.xtext.common.Terminals.INT");
                            						

                            }


                            }


                            }
                            break;

                    }

                    // InternalUmlModel.g:1208:4: (otherlv_22= ',' ( ( ruleFQN ) ) )*
                    loop19:
                    do {
                        int alt19=2;
                        int LA19_0 = input.LA(1);

                        if ( (LA19_0==16) ) {
                            alt19=1;
                        }


                        switch (alt19) {
                    	case 1 :
                    	    // InternalUmlModel.g:1209:5: otherlv_22= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_22=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_22, grammarAccess.getCtTestAccess().getCommaKeyword_9_3_0());
                    	    				
                    	    // InternalUmlModel.g:1213:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:1214:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:1214:6: ( ruleFQN )
                    	    // InternalUmlModel.g:1215:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtTestRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtTestAccess().getRnctInstructorsCtInstructorCrossReference_9_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_31);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop19;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:1231:3: (otherlv_24= 'result' ( (lv_result_25_0= rulectMeasuredVariable ) ) )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==33) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalUmlModel.g:1232:4: otherlv_24= 'result' ( (lv_result_25_0= rulectMeasuredVariable ) )
                    {
                    otherlv_24=(Token)match(input,33,FOLLOW_8); 

                    				newLeafNode(otherlv_24, grammarAccess.getCtTestAccess().getResultKeyword_10_0());
                    			
                    // InternalUmlModel.g:1236:4: ( (lv_result_25_0= rulectMeasuredVariable ) )
                    // InternalUmlModel.g:1237:5: (lv_result_25_0= rulectMeasuredVariable )
                    {
                    // InternalUmlModel.g:1237:5: (lv_result_25_0= rulectMeasuredVariable )
                    // InternalUmlModel.g:1238:6: lv_result_25_0= rulectMeasuredVariable
                    {

                    						newCompositeNode(grammarAccess.getCtTestAccess().getResultCtMeasuredVariableParserRuleCall_10_1_0());
                    					
                    pushFollow(FOLLOW_32);
                    lv_result_25_0=rulectMeasuredVariable();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCtTestRule());
                    						}
                    						set(
                    							current,
                    							"result",
                    							lv_result_25_0,
                    							"tesma.ovanes.UmlModel.ctMeasuredVariable");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1256:3: ( (lv_rnLowerTest_26_0= rulectTest ) )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==27) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalUmlModel.g:1257:4: (lv_rnLowerTest_26_0= rulectTest )
            	    {
            	    // InternalUmlModel.g:1257:4: (lv_rnLowerTest_26_0= rulectTest )
            	    // InternalUmlModel.g:1258:5: lv_rnLowerTest_26_0= rulectTest
            	    {

            	    					newCompositeNode(grammarAccess.getCtTestAccess().getRnLowerTestCtTestParserRuleCall_11_0());
            	    				
            	    pushFollow(FOLLOW_32);
            	    lv_rnLowerTest_26_0=rulectTest();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCtTestRule());
            	    					}
            	    					add(
            	    						current,
            	    						"rnLowerTest",
            	    						lv_rnLowerTest_26_0,
            	    						"tesma.ovanes.UmlModel.ctTest");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

            otherlv_27=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_27, grammarAccess.getCtTestAccess().getRightCurlyBracketKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectTest"


    // $ANTLR start "entryRulectInstitution"
    // InternalUmlModel.g:1283:1: entryRulectInstitution returns [EObject current=null] : iv_rulectInstitution= rulectInstitution EOF ;
    public final EObject entryRulectInstitution() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectInstitution = null;


        try {
            // InternalUmlModel.g:1283:54: (iv_rulectInstitution= rulectInstitution EOF )
            // InternalUmlModel.g:1284:2: iv_rulectInstitution= rulectInstitution EOF
            {
             newCompositeNode(grammarAccess.getCtInstitutionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectInstitution=rulectInstitution();

            state._fsp--;

             current =iv_rulectInstitution; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectInstitution"


    // $ANTLR start "rulectInstitution"
    // InternalUmlModel.g:1290:1: rulectInstitution returns [EObject current=null] : (otherlv_0= 'Institution' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'partOf' ( ( ruleFQN ) ) )? (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? otherlv_8= '{' (otherlv_9= 'name' ( (lv_label_10_0= RULE_STRING ) ) ) (otherlv_11= 'region' ( (lv_sepRegion_12_0= RULE_INT ) ) ) (otherlv_13= 'address' ( (lv_address_14_0= RULE_STRING ) ) ) (otherlv_15= 'programs' ( (otherlv_16= RULE_ID ) ) (otherlv_17= ',' ( ( ruleFQN ) ) )* )? (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) )? (otherlv_21= 'currentSituatuon' ( (lv_currentSituation_22_0= RULE_STRING ) ) )? (otherlv_23= 'gastronomie' ( (lv_gastronomie_24_0= RULE_STRING ) ) )? (otherlv_25= 'contact' ( (lv_contact_26_0= RULE_STRING ) ) )? otherlv_27= '}' ) ;
    public final EObject rulectInstitution() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token lv_label_10_0=null;
        Token otherlv_11=null;
        Token lv_sepRegion_12_0=null;
        Token otherlv_13=null;
        Token lv_address_14_0=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token lv_description_20_0=null;
        Token otherlv_21=null;
        Token lv_currentSituation_22_0=null;
        Token otherlv_23=null;
        Token lv_gastronomie_24_0=null;
        Token otherlv_25=null;
        Token lv_contact_26_0=null;
        Token otherlv_27=null;


        	enterRule();

        try {
            // InternalUmlModel.g:1296:2: ( (otherlv_0= 'Institution' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'partOf' ( ( ruleFQN ) ) )? (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? otherlv_8= '{' (otherlv_9= 'name' ( (lv_label_10_0= RULE_STRING ) ) ) (otherlv_11= 'region' ( (lv_sepRegion_12_0= RULE_INT ) ) ) (otherlv_13= 'address' ( (lv_address_14_0= RULE_STRING ) ) ) (otherlv_15= 'programs' ( (otherlv_16= RULE_ID ) ) (otherlv_17= ',' ( ( ruleFQN ) ) )* )? (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) )? (otherlv_21= 'currentSituatuon' ( (lv_currentSituation_22_0= RULE_STRING ) ) )? (otherlv_23= 'gastronomie' ( (lv_gastronomie_24_0= RULE_STRING ) ) )? (otherlv_25= 'contact' ( (lv_contact_26_0= RULE_STRING ) ) )? otherlv_27= '}' ) )
            // InternalUmlModel.g:1297:2: (otherlv_0= 'Institution' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'partOf' ( ( ruleFQN ) ) )? (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? otherlv_8= '{' (otherlv_9= 'name' ( (lv_label_10_0= RULE_STRING ) ) ) (otherlv_11= 'region' ( (lv_sepRegion_12_0= RULE_INT ) ) ) (otherlv_13= 'address' ( (lv_address_14_0= RULE_STRING ) ) ) (otherlv_15= 'programs' ( (otherlv_16= RULE_ID ) ) (otherlv_17= ',' ( ( ruleFQN ) ) )* )? (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) )? (otherlv_21= 'currentSituatuon' ( (lv_currentSituation_22_0= RULE_STRING ) ) )? (otherlv_23= 'gastronomie' ( (lv_gastronomie_24_0= RULE_STRING ) ) )? (otherlv_25= 'contact' ( (lv_contact_26_0= RULE_STRING ) ) )? otherlv_27= '}' )
            {
            // InternalUmlModel.g:1297:2: (otherlv_0= 'Institution' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'partOf' ( ( ruleFQN ) ) )? (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? otherlv_8= '{' (otherlv_9= 'name' ( (lv_label_10_0= RULE_STRING ) ) ) (otherlv_11= 'region' ( (lv_sepRegion_12_0= RULE_INT ) ) ) (otherlv_13= 'address' ( (lv_address_14_0= RULE_STRING ) ) ) (otherlv_15= 'programs' ( (otherlv_16= RULE_ID ) ) (otherlv_17= ',' ( ( ruleFQN ) ) )* )? (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) )? (otherlv_21= 'currentSituatuon' ( (lv_currentSituation_22_0= RULE_STRING ) ) )? (otherlv_23= 'gastronomie' ( (lv_gastronomie_24_0= RULE_STRING ) ) )? (otherlv_25= 'contact' ( (lv_contact_26_0= RULE_STRING ) ) )? otherlv_27= '}' )
            // InternalUmlModel.g:1298:3: otherlv_0= 'Institution' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'partOf' ( ( ruleFQN ) ) )? (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? otherlv_8= '{' (otherlv_9= 'name' ( (lv_label_10_0= RULE_STRING ) ) ) (otherlv_11= 'region' ( (lv_sepRegion_12_0= RULE_INT ) ) ) (otherlv_13= 'address' ( (lv_address_14_0= RULE_STRING ) ) ) (otherlv_15= 'programs' ( (otherlv_16= RULE_ID ) ) (otherlv_17= ',' ( ( ruleFQN ) ) )* )? (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) )? (otherlv_21= 'currentSituatuon' ( (lv_currentSituation_22_0= RULE_STRING ) ) )? (otherlv_23= 'gastronomie' ( (lv_gastronomie_24_0= RULE_STRING ) ) )? (otherlv_25= 'contact' ( (lv_contact_26_0= RULE_STRING ) ) )? otherlv_27= '}'
            {
            otherlv_0=(Token)match(input,34,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtInstitutionAccess().getInstitutionKeyword_0());
            		
            // InternalUmlModel.g:1302:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:1303:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:1303:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:1304:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_33); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtInstitutionAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtInstitutionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalUmlModel.g:1320:3: (otherlv_2= 'partOf' ( ( ruleFQN ) ) )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==35) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalUmlModel.g:1321:4: otherlv_2= 'partOf' ( ( ruleFQN ) )
                    {
                    otherlv_2=(Token)match(input,35,FOLLOW_4); 

                    				newLeafNode(otherlv_2, grammarAccess.getCtInstitutionAccess().getPartOfKeyword_2_0());
                    			
                    // InternalUmlModel.g:1325:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:1326:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:1326:5: ( ruleFQN )
                    // InternalUmlModel.g:1327:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtInstitutionRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtInstitutionAccess().getRnctMotherInstitutionCtInstitutionCrossReference_2_1_0());
                    					
                    pushFollow(FOLLOW_34);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1342:3: (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==25) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalUmlModel.g:1343:4: otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_4=(Token)match(input,25,FOLLOW_4); 

                    				newLeafNode(otherlv_4, grammarAccess.getCtInstitutionAccess().getContainsKeyword_3_0());
                    			
                    // InternalUmlModel.g:1347:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:1348:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:1348:5: ( ruleFQN )
                    // InternalUmlModel.g:1349:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtInstitutionRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtInstitutionAccess().getRnctSubInstitutionCtInstitutionCrossReference_3_1_0());
                    					
                    pushFollow(FOLLOW_24);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:1363:4: (otherlv_6= ',' ( ( ruleFQN ) ) )*
                    loop24:
                    do {
                        int alt24=2;
                        int LA24_0 = input.LA(1);

                        if ( (LA24_0==16) ) {
                            alt24=1;
                        }


                        switch (alt24) {
                    	case 1 :
                    	    // InternalUmlModel.g:1364:5: otherlv_6= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_6=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getCtInstitutionAccess().getCommaKeyword_3_2_0());
                    	    				
                    	    // InternalUmlModel.g:1368:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:1369:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:1369:6: ( ruleFQN )
                    	    // InternalUmlModel.g:1370:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtInstitutionRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtInstitutionAccess().getRnctSubInstituitonsCtInstitutionCrossReference_3_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_24);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop24;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_8=(Token)match(input,20,FOLLOW_35); 

            			newLeafNode(otherlv_8, grammarAccess.getCtInstitutionAccess().getLeftCurlyBracketKeyword_4());
            		
            // InternalUmlModel.g:1390:3: (otherlv_9= 'name' ( (lv_label_10_0= RULE_STRING ) ) )
            // InternalUmlModel.g:1391:4: otherlv_9= 'name' ( (lv_label_10_0= RULE_STRING ) )
            {
            otherlv_9=(Token)match(input,36,FOLLOW_10); 

            				newLeafNode(otherlv_9, grammarAccess.getCtInstitutionAccess().getNameKeyword_5_0());
            			
            // InternalUmlModel.g:1395:4: ( (lv_label_10_0= RULE_STRING ) )
            // InternalUmlModel.g:1396:5: (lv_label_10_0= RULE_STRING )
            {
            // InternalUmlModel.g:1396:5: (lv_label_10_0= RULE_STRING )
            // InternalUmlModel.g:1397:6: lv_label_10_0= RULE_STRING
            {
            lv_label_10_0=(Token)match(input,RULE_STRING,FOLLOW_36); 

            						newLeafNode(lv_label_10_0, grammarAccess.getCtInstitutionAccess().getLabelSTRINGTerminalRuleCall_5_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtInstitutionRule());
            						}
            						setWithLastConsumed(
            							current,
            							"label",
            							lv_label_10_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalUmlModel.g:1414:3: (otherlv_11= 'region' ( (lv_sepRegion_12_0= RULE_INT ) ) )
            // InternalUmlModel.g:1415:4: otherlv_11= 'region' ( (lv_sepRegion_12_0= RULE_INT ) )
            {
            otherlv_11=(Token)match(input,37,FOLLOW_6); 

            				newLeafNode(otherlv_11, grammarAccess.getCtInstitutionAccess().getRegionKeyword_6_0());
            			
            // InternalUmlModel.g:1419:4: ( (lv_sepRegion_12_0= RULE_INT ) )
            // InternalUmlModel.g:1420:5: (lv_sepRegion_12_0= RULE_INT )
            {
            // InternalUmlModel.g:1420:5: (lv_sepRegion_12_0= RULE_INT )
            // InternalUmlModel.g:1421:6: lv_sepRegion_12_0= RULE_INT
            {
            lv_sepRegion_12_0=(Token)match(input,RULE_INT,FOLLOW_37); 

            						newLeafNode(lv_sepRegion_12_0, grammarAccess.getCtInstitutionAccess().getSepRegionINTTerminalRuleCall_6_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtInstitutionRule());
            						}
            						setWithLastConsumed(
            							current,
            							"sepRegion",
            							lv_sepRegion_12_0,
            							"org.eclipse.xtext.common.Terminals.INT");
            					

            }


            }


            }

            // InternalUmlModel.g:1438:3: (otherlv_13= 'address' ( (lv_address_14_0= RULE_STRING ) ) )
            // InternalUmlModel.g:1439:4: otherlv_13= 'address' ( (lv_address_14_0= RULE_STRING ) )
            {
            otherlv_13=(Token)match(input,38,FOLLOW_10); 

            				newLeafNode(otherlv_13, grammarAccess.getCtInstitutionAccess().getAddressKeyword_7_0());
            			
            // InternalUmlModel.g:1443:4: ( (lv_address_14_0= RULE_STRING ) )
            // InternalUmlModel.g:1444:5: (lv_address_14_0= RULE_STRING )
            {
            // InternalUmlModel.g:1444:5: (lv_address_14_0= RULE_STRING )
            // InternalUmlModel.g:1445:6: lv_address_14_0= RULE_STRING
            {
            lv_address_14_0=(Token)match(input,RULE_STRING,FOLLOW_38); 

            						newLeafNode(lv_address_14_0, grammarAccess.getCtInstitutionAccess().getAddressSTRINGTerminalRuleCall_7_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtInstitutionRule());
            						}
            						setWithLastConsumed(
            							current,
            							"address",
            							lv_address_14_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalUmlModel.g:1462:3: (otherlv_15= 'programs' ( (otherlv_16= RULE_ID ) ) (otherlv_17= ',' ( ( ruleFQN ) ) )* )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==39) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalUmlModel.g:1463:4: otherlv_15= 'programs' ( (otherlv_16= RULE_ID ) ) (otherlv_17= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_15=(Token)match(input,39,FOLLOW_4); 

                    				newLeafNode(otherlv_15, grammarAccess.getCtInstitutionAccess().getProgramsKeyword_8_0());
                    			
                    // InternalUmlModel.g:1467:4: ( (otherlv_16= RULE_ID ) )
                    // InternalUmlModel.g:1468:5: (otherlv_16= RULE_ID )
                    {
                    // InternalUmlModel.g:1468:5: (otherlv_16= RULE_ID )
                    // InternalUmlModel.g:1469:6: otherlv_16= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtInstitutionRule());
                    						}
                    					
                    otherlv_16=(Token)match(input,RULE_ID,FOLLOW_39); 

                    						newLeafNode(otherlv_16, grammarAccess.getCtInstitutionAccess().getProgramsCtProgramCrossReference_8_1_0());
                    					

                    }


                    }

                    // InternalUmlModel.g:1480:4: (otherlv_17= ',' ( ( ruleFQN ) ) )*
                    loop26:
                    do {
                        int alt26=2;
                        int LA26_0 = input.LA(1);

                        if ( (LA26_0==16) ) {
                            alt26=1;
                        }


                        switch (alt26) {
                    	case 1 :
                    	    // InternalUmlModel.g:1481:5: otherlv_17= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_17=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_17, grammarAccess.getCtInstitutionAccess().getCommaKeyword_8_2_0());
                    	    				
                    	    // InternalUmlModel.g:1485:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:1486:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:1486:6: ( ruleFQN )
                    	    // InternalUmlModel.g:1487:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtInstitutionRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtInstitutionAccess().getProgramsCtProgramCrossReference_8_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_39);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop26;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:1503:3: (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==14) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalUmlModel.g:1504:4: otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) )
                    {
                    otherlv_19=(Token)match(input,14,FOLLOW_10); 

                    				newLeafNode(otherlv_19, grammarAccess.getCtInstitutionAccess().getDescriptionKeyword_9_0());
                    			
                    // InternalUmlModel.g:1508:4: ( (lv_description_20_0= RULE_STRING ) )
                    // InternalUmlModel.g:1509:5: (lv_description_20_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:1509:5: (lv_description_20_0= RULE_STRING )
                    // InternalUmlModel.g:1510:6: lv_description_20_0= RULE_STRING
                    {
                    lv_description_20_0=(Token)match(input,RULE_STRING,FOLLOW_40); 

                    						newLeafNode(lv_description_20_0, grammarAccess.getCtInstitutionAccess().getDescriptionSTRINGTerminalRuleCall_9_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtInstitutionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"description",
                    							lv_description_20_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1527:3: (otherlv_21= 'currentSituatuon' ( (lv_currentSituation_22_0= RULE_STRING ) ) )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==40) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalUmlModel.g:1528:4: otherlv_21= 'currentSituatuon' ( (lv_currentSituation_22_0= RULE_STRING ) )
                    {
                    otherlv_21=(Token)match(input,40,FOLLOW_10); 

                    				newLeafNode(otherlv_21, grammarAccess.getCtInstitutionAccess().getCurrentSituatuonKeyword_10_0());
                    			
                    // InternalUmlModel.g:1532:4: ( (lv_currentSituation_22_0= RULE_STRING ) )
                    // InternalUmlModel.g:1533:5: (lv_currentSituation_22_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:1533:5: (lv_currentSituation_22_0= RULE_STRING )
                    // InternalUmlModel.g:1534:6: lv_currentSituation_22_0= RULE_STRING
                    {
                    lv_currentSituation_22_0=(Token)match(input,RULE_STRING,FOLLOW_41); 

                    						newLeafNode(lv_currentSituation_22_0, grammarAccess.getCtInstitutionAccess().getCurrentSituationSTRINGTerminalRuleCall_10_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtInstitutionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"currentSituation",
                    							lv_currentSituation_22_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1551:3: (otherlv_23= 'gastronomie' ( (lv_gastronomie_24_0= RULE_STRING ) ) )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==41) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalUmlModel.g:1552:4: otherlv_23= 'gastronomie' ( (lv_gastronomie_24_0= RULE_STRING ) )
                    {
                    otherlv_23=(Token)match(input,41,FOLLOW_10); 

                    				newLeafNode(otherlv_23, grammarAccess.getCtInstitutionAccess().getGastronomieKeyword_11_0());
                    			
                    // InternalUmlModel.g:1556:4: ( (lv_gastronomie_24_0= RULE_STRING ) )
                    // InternalUmlModel.g:1557:5: (lv_gastronomie_24_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:1557:5: (lv_gastronomie_24_0= RULE_STRING )
                    // InternalUmlModel.g:1558:6: lv_gastronomie_24_0= RULE_STRING
                    {
                    lv_gastronomie_24_0=(Token)match(input,RULE_STRING,FOLLOW_42); 

                    						newLeafNode(lv_gastronomie_24_0, grammarAccess.getCtInstitutionAccess().getGastronomieSTRINGTerminalRuleCall_11_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtInstitutionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"gastronomie",
                    							lv_gastronomie_24_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1575:3: (otherlv_25= 'contact' ( (lv_contact_26_0= RULE_STRING ) ) )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==42) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalUmlModel.g:1576:4: otherlv_25= 'contact' ( (lv_contact_26_0= RULE_STRING ) )
                    {
                    otherlv_25=(Token)match(input,42,FOLLOW_10); 

                    				newLeafNode(otherlv_25, grammarAccess.getCtInstitutionAccess().getContactKeyword_12_0());
                    			
                    // InternalUmlModel.g:1580:4: ( (lv_contact_26_0= RULE_STRING ) )
                    // InternalUmlModel.g:1581:5: (lv_contact_26_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:1581:5: (lv_contact_26_0= RULE_STRING )
                    // InternalUmlModel.g:1582:6: lv_contact_26_0= RULE_STRING
                    {
                    lv_contact_26_0=(Token)match(input,RULE_STRING,FOLLOW_43); 

                    						newLeafNode(lv_contact_26_0, grammarAccess.getCtInstitutionAccess().getContactSTRINGTerminalRuleCall_12_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtInstitutionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"contact",
                    							lv_contact_26_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_27=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_27, grammarAccess.getCtInstitutionAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectInstitution"


    // $ANTLR start "entryRulectProgram"
    // InternalUmlModel.g:1607:1: entryRulectProgram returns [EObject current=null] : iv_rulectProgram= rulectProgram EOF ;
    public final EObject entryRulectProgram() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectProgram = null;


        try {
            // InternalUmlModel.g:1607:50: (iv_rulectProgram= rulectProgram EOF )
            // InternalUmlModel.g:1608:2: iv_rulectProgram= rulectProgram EOF
            {
             newCompositeNode(grammarAccess.getCtProgramRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectProgram=rulectProgram();

            state._fsp--;

             current =iv_rulectProgram; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectProgram"


    // $ANTLR start "rulectProgram"
    // InternalUmlModel.g:1614:1: rulectProgram returns [EObject current=null] : (otherlv_0= 'Program' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'partOf' ( ( ruleFQN ) ) )? (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? (otherlv_8= 'in' ( ( ruleFQN ) ) )? otherlv_10= '{' (otherlv_11= 'name' ( (lv_label_12_0= RULE_STRING ) ) ) (otherlv_13= 'isced' ( (lv_iscedLevel_14_0= RULE_INT ) ) (otherlv_15= ',' ( (lv_iscedCategory_16_0= RULE_INT ) ) (otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) ) )? )? ) (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) ) (otherlv_21= 'program director' ( ( ruleFQN ) ) ) (otherlv_23= 'prerequisites' ( (lv_prerequisites_24_0= RULE_STRING ) ) )? (otherlv_25= 'requisites' ( (lv_requisites_26_0= RULE_STRING ) ) )? (otherlv_27= 'costs' ( (lv_cost_28_0= RULE_STRING ) ) )? (otherlv_29= 'language' ( (lv_language_30_0= ruleLANGUAGE ) ) (otherlv_31= ',' ( (lv_language_32_0= ruleLANGUAGE ) ) )* ) (otherlv_33= 'email' ( (lv_email_34_0= RULE_STRING ) ) ) (otherlv_35= 'weblink' ( (lv_weblink_36_0= RULE_STRING ) ) ) (otherlv_37= 'courses' ( ( ruleFQN ) ) (otherlv_39= ',' ( ( ruleFQN ) ) )* )? ( (lv_terms_41_0= rulectTerm ) )* ( (lv_modules_42_0= rulectModule ) )* otherlv_43= '}' ) ;
    public final EObject rulectProgram() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token lv_label_12_0=null;
        Token otherlv_13=null;
        Token lv_iscedLevel_14_0=null;
        Token otherlv_15=null;
        Token lv_iscedCategory_16_0=null;
        Token otherlv_17=null;
        Token lv_iscedSubCategory_18_0=null;
        Token otherlv_19=null;
        Token lv_description_20_0=null;
        Token otherlv_21=null;
        Token otherlv_23=null;
        Token lv_prerequisites_24_0=null;
        Token otherlv_25=null;
        Token lv_requisites_26_0=null;
        Token otherlv_27=null;
        Token lv_cost_28_0=null;
        Token otherlv_29=null;
        Token otherlv_31=null;
        Token otherlv_33=null;
        Token lv_email_34_0=null;
        Token otherlv_35=null;
        Token lv_weblink_36_0=null;
        Token otherlv_37=null;
        Token otherlv_39=null;
        Token otherlv_43=null;
        AntlrDatatypeRuleToken lv_language_30_0 = null;

        AntlrDatatypeRuleToken lv_language_32_0 = null;

        EObject lv_terms_41_0 = null;

        EObject lv_modules_42_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:1620:2: ( (otherlv_0= 'Program' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'partOf' ( ( ruleFQN ) ) )? (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? (otherlv_8= 'in' ( ( ruleFQN ) ) )? otherlv_10= '{' (otherlv_11= 'name' ( (lv_label_12_0= RULE_STRING ) ) ) (otherlv_13= 'isced' ( (lv_iscedLevel_14_0= RULE_INT ) ) (otherlv_15= ',' ( (lv_iscedCategory_16_0= RULE_INT ) ) (otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) ) )? )? ) (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) ) (otherlv_21= 'program director' ( ( ruleFQN ) ) ) (otherlv_23= 'prerequisites' ( (lv_prerequisites_24_0= RULE_STRING ) ) )? (otherlv_25= 'requisites' ( (lv_requisites_26_0= RULE_STRING ) ) )? (otherlv_27= 'costs' ( (lv_cost_28_0= RULE_STRING ) ) )? (otherlv_29= 'language' ( (lv_language_30_0= ruleLANGUAGE ) ) (otherlv_31= ',' ( (lv_language_32_0= ruleLANGUAGE ) ) )* ) (otherlv_33= 'email' ( (lv_email_34_0= RULE_STRING ) ) ) (otherlv_35= 'weblink' ( (lv_weblink_36_0= RULE_STRING ) ) ) (otherlv_37= 'courses' ( ( ruleFQN ) ) (otherlv_39= ',' ( ( ruleFQN ) ) )* )? ( (lv_terms_41_0= rulectTerm ) )* ( (lv_modules_42_0= rulectModule ) )* otherlv_43= '}' ) )
            // InternalUmlModel.g:1621:2: (otherlv_0= 'Program' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'partOf' ( ( ruleFQN ) ) )? (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? (otherlv_8= 'in' ( ( ruleFQN ) ) )? otherlv_10= '{' (otherlv_11= 'name' ( (lv_label_12_0= RULE_STRING ) ) ) (otherlv_13= 'isced' ( (lv_iscedLevel_14_0= RULE_INT ) ) (otherlv_15= ',' ( (lv_iscedCategory_16_0= RULE_INT ) ) (otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) ) )? )? ) (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) ) (otherlv_21= 'program director' ( ( ruleFQN ) ) ) (otherlv_23= 'prerequisites' ( (lv_prerequisites_24_0= RULE_STRING ) ) )? (otherlv_25= 'requisites' ( (lv_requisites_26_0= RULE_STRING ) ) )? (otherlv_27= 'costs' ( (lv_cost_28_0= RULE_STRING ) ) )? (otherlv_29= 'language' ( (lv_language_30_0= ruleLANGUAGE ) ) (otherlv_31= ',' ( (lv_language_32_0= ruleLANGUAGE ) ) )* ) (otherlv_33= 'email' ( (lv_email_34_0= RULE_STRING ) ) ) (otherlv_35= 'weblink' ( (lv_weblink_36_0= RULE_STRING ) ) ) (otherlv_37= 'courses' ( ( ruleFQN ) ) (otherlv_39= ',' ( ( ruleFQN ) ) )* )? ( (lv_terms_41_0= rulectTerm ) )* ( (lv_modules_42_0= rulectModule ) )* otherlv_43= '}' )
            {
            // InternalUmlModel.g:1621:2: (otherlv_0= 'Program' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'partOf' ( ( ruleFQN ) ) )? (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? (otherlv_8= 'in' ( ( ruleFQN ) ) )? otherlv_10= '{' (otherlv_11= 'name' ( (lv_label_12_0= RULE_STRING ) ) ) (otherlv_13= 'isced' ( (lv_iscedLevel_14_0= RULE_INT ) ) (otherlv_15= ',' ( (lv_iscedCategory_16_0= RULE_INT ) ) (otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) ) )? )? ) (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) ) (otherlv_21= 'program director' ( ( ruleFQN ) ) ) (otherlv_23= 'prerequisites' ( (lv_prerequisites_24_0= RULE_STRING ) ) )? (otherlv_25= 'requisites' ( (lv_requisites_26_0= RULE_STRING ) ) )? (otherlv_27= 'costs' ( (lv_cost_28_0= RULE_STRING ) ) )? (otherlv_29= 'language' ( (lv_language_30_0= ruleLANGUAGE ) ) (otherlv_31= ',' ( (lv_language_32_0= ruleLANGUAGE ) ) )* ) (otherlv_33= 'email' ( (lv_email_34_0= RULE_STRING ) ) ) (otherlv_35= 'weblink' ( (lv_weblink_36_0= RULE_STRING ) ) ) (otherlv_37= 'courses' ( ( ruleFQN ) ) (otherlv_39= ',' ( ( ruleFQN ) ) )* )? ( (lv_terms_41_0= rulectTerm ) )* ( (lv_modules_42_0= rulectModule ) )* otherlv_43= '}' )
            // InternalUmlModel.g:1622:3: otherlv_0= 'Program' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'partOf' ( ( ruleFQN ) ) )? (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? (otherlv_8= 'in' ( ( ruleFQN ) ) )? otherlv_10= '{' (otherlv_11= 'name' ( (lv_label_12_0= RULE_STRING ) ) ) (otherlv_13= 'isced' ( (lv_iscedLevel_14_0= RULE_INT ) ) (otherlv_15= ',' ( (lv_iscedCategory_16_0= RULE_INT ) ) (otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) ) )? )? ) (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) ) (otherlv_21= 'program director' ( ( ruleFQN ) ) ) (otherlv_23= 'prerequisites' ( (lv_prerequisites_24_0= RULE_STRING ) ) )? (otherlv_25= 'requisites' ( (lv_requisites_26_0= RULE_STRING ) ) )? (otherlv_27= 'costs' ( (lv_cost_28_0= RULE_STRING ) ) )? (otherlv_29= 'language' ( (lv_language_30_0= ruleLANGUAGE ) ) (otherlv_31= ',' ( (lv_language_32_0= ruleLANGUAGE ) ) )* ) (otherlv_33= 'email' ( (lv_email_34_0= RULE_STRING ) ) ) (otherlv_35= 'weblink' ( (lv_weblink_36_0= RULE_STRING ) ) ) (otherlv_37= 'courses' ( ( ruleFQN ) ) (otherlv_39= ',' ( ( ruleFQN ) ) )* )? ( (lv_terms_41_0= rulectTerm ) )* ( (lv_modules_42_0= rulectModule ) )* otherlv_43= '}'
            {
            otherlv_0=(Token)match(input,43,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtProgramAccess().getProgramKeyword_0());
            		
            // InternalUmlModel.g:1626:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:1627:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:1627:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:1628:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_44); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtProgramAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtProgramRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalUmlModel.g:1644:3: (otherlv_2= 'partOf' ( ( ruleFQN ) ) )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==35) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalUmlModel.g:1645:4: otherlv_2= 'partOf' ( ( ruleFQN ) )
                    {
                    otherlv_2=(Token)match(input,35,FOLLOW_4); 

                    				newLeafNode(otherlv_2, grammarAccess.getCtProgramAccess().getPartOfKeyword_2_0());
                    			
                    // InternalUmlModel.g:1649:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:1650:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:1650:5: ( ruleFQN )
                    // InternalUmlModel.g:1651:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtProgramRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtProgramAccess().getRnctMotherProgramCtProgramCrossReference_2_1_0());
                    					
                    pushFollow(FOLLOW_45);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1666:3: (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==25) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalUmlModel.g:1667:4: otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_4=(Token)match(input,25,FOLLOW_4); 

                    				newLeafNode(otherlv_4, grammarAccess.getCtProgramAccess().getContainsKeyword_3_0());
                    			
                    // InternalUmlModel.g:1671:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:1672:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:1672:5: ( ruleFQN )
                    // InternalUmlModel.g:1673:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtProgramRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtProgramAccess().getRnctSubProgramsCtProgramCrossReference_3_1_0());
                    					
                    pushFollow(FOLLOW_46);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:1687:4: (otherlv_6= ',' ( ( ruleFQN ) ) )*
                    loop33:
                    do {
                        int alt33=2;
                        int LA33_0 = input.LA(1);

                        if ( (LA33_0==16) ) {
                            alt33=1;
                        }


                        switch (alt33) {
                    	case 1 :
                    	    // InternalUmlModel.g:1688:5: otherlv_6= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_6=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getCtProgramAccess().getCommaKeyword_3_2_0());
                    	    				
                    	    // InternalUmlModel.g:1692:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:1693:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:1693:6: ( ruleFQN )
                    	    // InternalUmlModel.g:1694:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtProgramRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtProgramAccess().getRnctSubProgramsCtProgramCrossReference_3_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_46);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop33;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:1710:3: (otherlv_8= 'in' ( ( ruleFQN ) ) )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==44) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalUmlModel.g:1711:4: otherlv_8= 'in' ( ( ruleFQN ) )
                    {
                    otherlv_8=(Token)match(input,44,FOLLOW_4); 

                    				newLeafNode(otherlv_8, grammarAccess.getCtProgramAccess().getInKeyword_4_0());
                    			
                    // InternalUmlModel.g:1715:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:1716:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:1716:5: ( ruleFQN )
                    // InternalUmlModel.g:1717:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtProgramRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtProgramAccess().getInstitutionCtInstitutionCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_47);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_10=(Token)match(input,20,FOLLOW_35); 

            			newLeafNode(otherlv_10, grammarAccess.getCtProgramAccess().getLeftCurlyBracketKeyword_5());
            		
            // InternalUmlModel.g:1736:3: (otherlv_11= 'name' ( (lv_label_12_0= RULE_STRING ) ) )
            // InternalUmlModel.g:1737:4: otherlv_11= 'name' ( (lv_label_12_0= RULE_STRING ) )
            {
            otherlv_11=(Token)match(input,36,FOLLOW_10); 

            				newLeafNode(otherlv_11, grammarAccess.getCtProgramAccess().getNameKeyword_6_0());
            			
            // InternalUmlModel.g:1741:4: ( (lv_label_12_0= RULE_STRING ) )
            // InternalUmlModel.g:1742:5: (lv_label_12_0= RULE_STRING )
            {
            // InternalUmlModel.g:1742:5: (lv_label_12_0= RULE_STRING )
            // InternalUmlModel.g:1743:6: lv_label_12_0= RULE_STRING
            {
            lv_label_12_0=(Token)match(input,RULE_STRING,FOLLOW_48); 

            						newLeafNode(lv_label_12_0, grammarAccess.getCtProgramAccess().getLabelSTRINGTerminalRuleCall_6_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtProgramRule());
            						}
            						setWithLastConsumed(
            							current,
            							"label",
            							lv_label_12_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalUmlModel.g:1760:3: (otherlv_13= 'isced' ( (lv_iscedLevel_14_0= RULE_INT ) ) (otherlv_15= ',' ( (lv_iscedCategory_16_0= RULE_INT ) ) (otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) ) )? )? )
            // InternalUmlModel.g:1761:4: otherlv_13= 'isced' ( (lv_iscedLevel_14_0= RULE_INT ) ) (otherlv_15= ',' ( (lv_iscedCategory_16_0= RULE_INT ) ) (otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) ) )? )?
            {
            otherlv_13=(Token)match(input,45,FOLLOW_6); 

            				newLeafNode(otherlv_13, grammarAccess.getCtProgramAccess().getIscedKeyword_7_0());
            			
            // InternalUmlModel.g:1765:4: ( (lv_iscedLevel_14_0= RULE_INT ) )
            // InternalUmlModel.g:1766:5: (lv_iscedLevel_14_0= RULE_INT )
            {
            // InternalUmlModel.g:1766:5: (lv_iscedLevel_14_0= RULE_INT )
            // InternalUmlModel.g:1767:6: lv_iscedLevel_14_0= RULE_INT
            {
            lv_iscedLevel_14_0=(Token)match(input,RULE_INT,FOLLOW_49); 

            						newLeafNode(lv_iscedLevel_14_0, grammarAccess.getCtProgramAccess().getIscedLevelINTTerminalRuleCall_7_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtProgramRule());
            						}
            						setWithLastConsumed(
            							current,
            							"iscedLevel",
            							lv_iscedLevel_14_0,
            							"org.eclipse.xtext.common.Terminals.INT");
            					

            }


            }

            // InternalUmlModel.g:1783:4: (otherlv_15= ',' ( (lv_iscedCategory_16_0= RULE_INT ) ) (otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) ) )? )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==16) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalUmlModel.g:1784:5: otherlv_15= ',' ( (lv_iscedCategory_16_0= RULE_INT ) ) (otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) ) )?
                    {
                    otherlv_15=(Token)match(input,16,FOLLOW_6); 

                    					newLeafNode(otherlv_15, grammarAccess.getCtProgramAccess().getCommaKeyword_7_2_0());
                    				
                    // InternalUmlModel.g:1788:5: ( (lv_iscedCategory_16_0= RULE_INT ) )
                    // InternalUmlModel.g:1789:6: (lv_iscedCategory_16_0= RULE_INT )
                    {
                    // InternalUmlModel.g:1789:6: (lv_iscedCategory_16_0= RULE_INT )
                    // InternalUmlModel.g:1790:7: lv_iscedCategory_16_0= RULE_INT
                    {
                    lv_iscedCategory_16_0=(Token)match(input,RULE_INT,FOLLOW_49); 

                    							newLeafNode(lv_iscedCategory_16_0, grammarAccess.getCtProgramAccess().getIscedCategoryINTTerminalRuleCall_7_2_1_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getCtProgramRule());
                    							}
                    							setWithLastConsumed(
                    								current,
                    								"iscedCategory",
                    								lv_iscedCategory_16_0,
                    								"org.eclipse.xtext.common.Terminals.INT");
                    						

                    }


                    }

                    // InternalUmlModel.g:1806:5: (otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) ) )?
                    int alt36=2;
                    int LA36_0 = input.LA(1);

                    if ( (LA36_0==16) ) {
                        alt36=1;
                    }
                    switch (alt36) {
                        case 1 :
                            // InternalUmlModel.g:1807:6: otherlv_17= ',' ( (lv_iscedSubCategory_18_0= RULE_INT ) )
                            {
                            otherlv_17=(Token)match(input,16,FOLLOW_6); 

                            						newLeafNode(otherlv_17, grammarAccess.getCtProgramAccess().getCommaKeyword_7_2_2_0());
                            					
                            // InternalUmlModel.g:1811:6: ( (lv_iscedSubCategory_18_0= RULE_INT ) )
                            // InternalUmlModel.g:1812:7: (lv_iscedSubCategory_18_0= RULE_INT )
                            {
                            // InternalUmlModel.g:1812:7: (lv_iscedSubCategory_18_0= RULE_INT )
                            // InternalUmlModel.g:1813:8: lv_iscedSubCategory_18_0= RULE_INT
                            {
                            lv_iscedSubCategory_18_0=(Token)match(input,RULE_INT,FOLLOW_9); 

                            								newLeafNode(lv_iscedSubCategory_18_0, grammarAccess.getCtProgramAccess().getIscedSubCategoryINTTerminalRuleCall_7_2_2_1_0());
                            							

                            								if (current==null) {
                            									current = createModelElement(grammarAccess.getCtProgramRule());
                            								}
                            								setWithLastConsumed(
                            									current,
                            									"iscedSubCategory",
                            									lv_iscedSubCategory_18_0,
                            									"org.eclipse.xtext.common.Terminals.INT");
                            							

                            }


                            }


                            }
                            break;

                    }


                    }
                    break;

            }


            }

            // InternalUmlModel.g:1832:3: (otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) ) )
            // InternalUmlModel.g:1833:4: otherlv_19= 'description' ( (lv_description_20_0= RULE_STRING ) )
            {
            otherlv_19=(Token)match(input,14,FOLLOW_10); 

            				newLeafNode(otherlv_19, grammarAccess.getCtProgramAccess().getDescriptionKeyword_8_0());
            			
            // InternalUmlModel.g:1837:4: ( (lv_description_20_0= RULE_STRING ) )
            // InternalUmlModel.g:1838:5: (lv_description_20_0= RULE_STRING )
            {
            // InternalUmlModel.g:1838:5: (lv_description_20_0= RULE_STRING )
            // InternalUmlModel.g:1839:6: lv_description_20_0= RULE_STRING
            {
            lv_description_20_0=(Token)match(input,RULE_STRING,FOLLOW_50); 

            						newLeafNode(lv_description_20_0, grammarAccess.getCtProgramAccess().getDescriptionSTRINGTerminalRuleCall_8_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtProgramRule());
            						}
            						setWithLastConsumed(
            							current,
            							"description",
            							lv_description_20_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalUmlModel.g:1856:3: (otherlv_21= 'program director' ( ( ruleFQN ) ) )
            // InternalUmlModel.g:1857:4: otherlv_21= 'program director' ( ( ruleFQN ) )
            {
            otherlv_21=(Token)match(input,46,FOLLOW_4); 

            				newLeafNode(otherlv_21, grammarAccess.getCtProgramAccess().getProgramDirectorKeyword_9_0());
            			
            // InternalUmlModel.g:1861:4: ( ( ruleFQN ) )
            // InternalUmlModel.g:1862:5: ( ruleFQN )
            {
            // InternalUmlModel.g:1862:5: ( ruleFQN )
            // InternalUmlModel.g:1863:6: ruleFQN
            {

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtProgramRule());
            						}
            					

            						newCompositeNode(grammarAccess.getCtProgramAccess().getRnctprogramdirectorCtInstructorCrossReference_9_1_0());
            					
            pushFollow(FOLLOW_51);
            ruleFQN();

            state._fsp--;


            						afterParserOrEnumRuleCall();
            					

            }


            }


            }

            // InternalUmlModel.g:1878:3: (otherlv_23= 'prerequisites' ( (lv_prerequisites_24_0= RULE_STRING ) ) )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==47) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalUmlModel.g:1879:4: otherlv_23= 'prerequisites' ( (lv_prerequisites_24_0= RULE_STRING ) )
                    {
                    otherlv_23=(Token)match(input,47,FOLLOW_10); 

                    				newLeafNode(otherlv_23, grammarAccess.getCtProgramAccess().getPrerequisitesKeyword_10_0());
                    			
                    // InternalUmlModel.g:1883:4: ( (lv_prerequisites_24_0= RULE_STRING ) )
                    // InternalUmlModel.g:1884:5: (lv_prerequisites_24_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:1884:5: (lv_prerequisites_24_0= RULE_STRING )
                    // InternalUmlModel.g:1885:6: lv_prerequisites_24_0= RULE_STRING
                    {
                    lv_prerequisites_24_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

                    						newLeafNode(lv_prerequisites_24_0, grammarAccess.getCtProgramAccess().getPrerequisitesSTRINGTerminalRuleCall_10_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtProgramRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"prerequisites",
                    							lv_prerequisites_24_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1902:3: (otherlv_25= 'requisites' ( (lv_requisites_26_0= RULE_STRING ) ) )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==48) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalUmlModel.g:1903:4: otherlv_25= 'requisites' ( (lv_requisites_26_0= RULE_STRING ) )
                    {
                    otherlv_25=(Token)match(input,48,FOLLOW_10); 

                    				newLeafNode(otherlv_25, grammarAccess.getCtProgramAccess().getRequisitesKeyword_11_0());
                    			
                    // InternalUmlModel.g:1907:4: ( (lv_requisites_26_0= RULE_STRING ) )
                    // InternalUmlModel.g:1908:5: (lv_requisites_26_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:1908:5: (lv_requisites_26_0= RULE_STRING )
                    // InternalUmlModel.g:1909:6: lv_requisites_26_0= RULE_STRING
                    {
                    lv_requisites_26_0=(Token)match(input,RULE_STRING,FOLLOW_53); 

                    						newLeafNode(lv_requisites_26_0, grammarAccess.getCtProgramAccess().getRequisitesSTRINGTerminalRuleCall_11_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtProgramRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"requisites",
                    							lv_requisites_26_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1926:3: (otherlv_27= 'costs' ( (lv_cost_28_0= RULE_STRING ) ) )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==49) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalUmlModel.g:1927:4: otherlv_27= 'costs' ( (lv_cost_28_0= RULE_STRING ) )
                    {
                    otherlv_27=(Token)match(input,49,FOLLOW_10); 

                    				newLeafNode(otherlv_27, grammarAccess.getCtProgramAccess().getCostsKeyword_12_0());
                    			
                    // InternalUmlModel.g:1931:4: ( (lv_cost_28_0= RULE_STRING ) )
                    // InternalUmlModel.g:1932:5: (lv_cost_28_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:1932:5: (lv_cost_28_0= RULE_STRING )
                    // InternalUmlModel.g:1933:6: lv_cost_28_0= RULE_STRING
                    {
                    lv_cost_28_0=(Token)match(input,RULE_STRING,FOLLOW_54); 

                    						newLeafNode(lv_cost_28_0, grammarAccess.getCtProgramAccess().getCostSTRINGTerminalRuleCall_12_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtProgramRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"cost",
                    							lv_cost_28_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:1950:3: (otherlv_29= 'language' ( (lv_language_30_0= ruleLANGUAGE ) ) (otherlv_31= ',' ( (lv_language_32_0= ruleLANGUAGE ) ) )* )
            // InternalUmlModel.g:1951:4: otherlv_29= 'language' ( (lv_language_30_0= ruleLANGUAGE ) ) (otherlv_31= ',' ( (lv_language_32_0= ruleLANGUAGE ) ) )*
            {
            otherlv_29=(Token)match(input,50,FOLLOW_10); 

            				newLeafNode(otherlv_29, grammarAccess.getCtProgramAccess().getLanguageKeyword_13_0());
            			
            // InternalUmlModel.g:1955:4: ( (lv_language_30_0= ruleLANGUAGE ) )
            // InternalUmlModel.g:1956:5: (lv_language_30_0= ruleLANGUAGE )
            {
            // InternalUmlModel.g:1956:5: (lv_language_30_0= ruleLANGUAGE )
            // InternalUmlModel.g:1957:6: lv_language_30_0= ruleLANGUAGE
            {

            						newCompositeNode(grammarAccess.getCtProgramAccess().getLanguageLANGUAGEParserRuleCall_13_1_0());
            					
            pushFollow(FOLLOW_55);
            lv_language_30_0=ruleLANGUAGE();

            state._fsp--;


            						if (current==null) {
            							current = createModelElementForParent(grammarAccess.getCtProgramRule());
            						}
            						add(
            							current,
            							"language",
            							lv_language_30_0,
            							"tesma.ovanes.UmlModel.LANGUAGE");
            						afterParserOrEnumRuleCall();
            					

            }


            }

            // InternalUmlModel.g:1974:4: (otherlv_31= ',' ( (lv_language_32_0= ruleLANGUAGE ) ) )*
            loop41:
            do {
                int alt41=2;
                int LA41_0 = input.LA(1);

                if ( (LA41_0==16) ) {
                    alt41=1;
                }


                switch (alt41) {
            	case 1 :
            	    // InternalUmlModel.g:1975:5: otherlv_31= ',' ( (lv_language_32_0= ruleLANGUAGE ) )
            	    {
            	    otherlv_31=(Token)match(input,16,FOLLOW_10); 

            	    					newLeafNode(otherlv_31, grammarAccess.getCtProgramAccess().getCommaKeyword_13_2_0());
            	    				
            	    // InternalUmlModel.g:1979:5: ( (lv_language_32_0= ruleLANGUAGE ) )
            	    // InternalUmlModel.g:1980:6: (lv_language_32_0= ruleLANGUAGE )
            	    {
            	    // InternalUmlModel.g:1980:6: (lv_language_32_0= ruleLANGUAGE )
            	    // InternalUmlModel.g:1981:7: lv_language_32_0= ruleLANGUAGE
            	    {

            	    							newCompositeNode(grammarAccess.getCtProgramAccess().getLanguageLANGUAGEParserRuleCall_13_2_1_0());
            	    						
            	    pushFollow(FOLLOW_55);
            	    lv_language_32_0=ruleLANGUAGE();

            	    state._fsp--;


            	    							if (current==null) {
            	    								current = createModelElementForParent(grammarAccess.getCtProgramRule());
            	    							}
            	    							add(
            	    								current,
            	    								"language",
            	    								lv_language_32_0,
            	    								"tesma.ovanes.UmlModel.LANGUAGE");
            	    							afterParserOrEnumRuleCall();
            	    						

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop41;
                }
            } while (true);


            }

            // InternalUmlModel.g:2000:3: (otherlv_33= 'email' ( (lv_email_34_0= RULE_STRING ) ) )
            // InternalUmlModel.g:2001:4: otherlv_33= 'email' ( (lv_email_34_0= RULE_STRING ) )
            {
            otherlv_33=(Token)match(input,51,FOLLOW_10); 

            				newLeafNode(otherlv_33, grammarAccess.getCtProgramAccess().getEmailKeyword_14_0());
            			
            // InternalUmlModel.g:2005:4: ( (lv_email_34_0= RULE_STRING ) )
            // InternalUmlModel.g:2006:5: (lv_email_34_0= RULE_STRING )
            {
            // InternalUmlModel.g:2006:5: (lv_email_34_0= RULE_STRING )
            // InternalUmlModel.g:2007:6: lv_email_34_0= RULE_STRING
            {
            lv_email_34_0=(Token)match(input,RULE_STRING,FOLLOW_56); 

            						newLeafNode(lv_email_34_0, grammarAccess.getCtProgramAccess().getEmailSTRINGTerminalRuleCall_14_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtProgramRule());
            						}
            						setWithLastConsumed(
            							current,
            							"email",
            							lv_email_34_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalUmlModel.g:2024:3: (otherlv_35= 'weblink' ( (lv_weblink_36_0= RULE_STRING ) ) )
            // InternalUmlModel.g:2025:4: otherlv_35= 'weblink' ( (lv_weblink_36_0= RULE_STRING ) )
            {
            otherlv_35=(Token)match(input,52,FOLLOW_10); 

            				newLeafNode(otherlv_35, grammarAccess.getCtProgramAccess().getWeblinkKeyword_15_0());
            			
            // InternalUmlModel.g:2029:4: ( (lv_weblink_36_0= RULE_STRING ) )
            // InternalUmlModel.g:2030:5: (lv_weblink_36_0= RULE_STRING )
            {
            // InternalUmlModel.g:2030:5: (lv_weblink_36_0= RULE_STRING )
            // InternalUmlModel.g:2031:6: lv_weblink_36_0= RULE_STRING
            {
            lv_weblink_36_0=(Token)match(input,RULE_STRING,FOLLOW_57); 

            						newLeafNode(lv_weblink_36_0, grammarAccess.getCtProgramAccess().getWeblinkSTRINGTerminalRuleCall_15_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtProgramRule());
            						}
            						setWithLastConsumed(
            							current,
            							"weblink",
            							lv_weblink_36_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalUmlModel.g:2048:3: (otherlv_37= 'courses' ( ( ruleFQN ) ) (otherlv_39= ',' ( ( ruleFQN ) ) )* )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==53) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalUmlModel.g:2049:4: otherlv_37= 'courses' ( ( ruleFQN ) ) (otherlv_39= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_37=(Token)match(input,53,FOLLOW_4); 

                    				newLeafNode(otherlv_37, grammarAccess.getCtProgramAccess().getCoursesKeyword_16_0());
                    			
                    // InternalUmlModel.g:2053:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:2054:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:2054:5: ( ruleFQN )
                    // InternalUmlModel.g:2055:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtProgramRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtProgramAccess().getCoursesCtCourseCrossReference_16_1_0());
                    					
                    pushFollow(FOLLOW_58);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:2069:4: (otherlv_39= ',' ( ( ruleFQN ) ) )*
                    loop42:
                    do {
                        int alt42=2;
                        int LA42_0 = input.LA(1);

                        if ( (LA42_0==16) ) {
                            alt42=1;
                        }


                        switch (alt42) {
                    	case 1 :
                    	    // InternalUmlModel.g:2070:5: otherlv_39= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_39=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_39, grammarAccess.getCtProgramAccess().getCommaKeyword_16_2_0());
                    	    				
                    	    // InternalUmlModel.g:2074:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:2075:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:2075:6: ( ruleFQN )
                    	    // InternalUmlModel.g:2076:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtProgramRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtProgramAccess().getCoursesCtCourseCrossReference_16_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_58);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop42;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:2092:3: ( (lv_terms_41_0= rulectTerm ) )*
            loop44:
            do {
                int alt44=2;
                int LA44_0 = input.LA(1);

                if ( (LA44_0==102) ) {
                    alt44=1;
                }


                switch (alt44) {
            	case 1 :
            	    // InternalUmlModel.g:2093:4: (lv_terms_41_0= rulectTerm )
            	    {
            	    // InternalUmlModel.g:2093:4: (lv_terms_41_0= rulectTerm )
            	    // InternalUmlModel.g:2094:5: lv_terms_41_0= rulectTerm
            	    {

            	    					newCompositeNode(grammarAccess.getCtProgramAccess().getTermsCtTermParserRuleCall_17_0());
            	    				
            	    pushFollow(FOLLOW_59);
            	    lv_terms_41_0=rulectTerm();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCtProgramRule());
            	    					}
            	    					add(
            	    						current,
            	    						"terms",
            	    						lv_terms_41_0,
            	    						"tesma.ovanes.UmlModel.ctTerm");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop44;
                }
            } while (true);

            // InternalUmlModel.g:2111:3: ( (lv_modules_42_0= rulectModule ) )*
            loop45:
            do {
                int alt45=2;
                int LA45_0 = input.LA(1);

                if ( (LA45_0==104) ) {
                    alt45=1;
                }


                switch (alt45) {
            	case 1 :
            	    // InternalUmlModel.g:2112:4: (lv_modules_42_0= rulectModule )
            	    {
            	    // InternalUmlModel.g:2112:4: (lv_modules_42_0= rulectModule )
            	    // InternalUmlModel.g:2113:5: lv_modules_42_0= rulectModule
            	    {

            	    					newCompositeNode(grammarAccess.getCtProgramAccess().getModulesCtModuleParserRuleCall_18_0());
            	    				
            	    pushFollow(FOLLOW_60);
            	    lv_modules_42_0=rulectModule();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCtProgramRule());
            	    					}
            	    					add(
            	    						current,
            	    						"modules",
            	    						lv_modules_42_0,
            	    						"tesma.ovanes.UmlModel.ctModule");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop45;
                }
            } while (true);

            otherlv_43=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_43, grammarAccess.getCtProgramAccess().getRightCurlyBracketKeyword_19());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectProgram"


    // $ANTLR start "entryRulectCourse"
    // InternalUmlModel.g:2138:1: entryRulectCourse returns [EObject current=null] : iv_rulectCourse= rulectCourse EOF ;
    public final EObject entryRulectCourse() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectCourse = null;


        try {
            // InternalUmlModel.g:2138:49: (iv_rulectCourse= rulectCourse EOF )
            // InternalUmlModel.g:2139:2: iv_rulectCourse= rulectCourse EOF
            {
             newCompositeNode(grammarAccess.getCtCourseRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectCourse=rulectCourse();

            state._fsp--;

             current =iv_rulectCourse; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectCourse"


    // $ANTLR start "rulectCourse"
    // InternalUmlModel.g:2145:1: rulectCourse returns [EObject current=null] : ( ( (lv_hide_0_0= ruleHIDDEN ) )? otherlv_1= 'Course' ( (lv_nature_2_0= ruleNATUREOFCOURSE ) ) ( (lv_name_3_0= RULE_ID ) ) ( ( ( (lv_programtype_4_0= 'belongs' ) ) | ( (lv_programtype_5_0= 'in' ) ) ) ( ( ruleFQN ) ) )? otherlv_7= '{' (otherlv_8= 'name' ( (lv_label_9_0= RULE_STRING ) ) ) (otherlv_10= 'reference' ( (lv_reference_11_0= ruleREFERENCE ) ) ) (otherlv_12= 'corecourse' ( ( ruleFQN ) ) )? (otherlv_14= 'academicyear' ( (lv_beginyear_15_0= RULE_INT ) ) otherlv_16= '/' ( (lv_endyear_17_0= RULE_INT ) ) ) (otherlv_18= 'term' ( ( ruleFQN ) ) ) (otherlv_20= 'module' ( ( ruleFQN ) ) )? (otherlv_22= 'hoursPerWeek' ( (lv_hoursperweek_23_0= RULE_INT ) ) ) (otherlv_24= 'totalHours' ( (lv_hourstotal_25_0= RULE_INT ) ) ) (otherlv_26= 'description' ( (lv_description_27_0= RULE_STRING ) ) ) (otherlv_28= 'credits' ( (lv_credits_29_0= RULE_INT ) ) ) (otherlv_30= 'languages' ( (lv_languages_31_0= ruleLANGUAGE ) ) (otherlv_32= ',' ( (lv_languages_33_0= ruleLANGUAGE ) ) )* )? (otherlv_34= 'weblink' ( (lv_weblink_35_0= RULE_STRING ) ) )? (otherlv_36= 'coursemoderator' ( ( ruleFQN ) ) )? (otherlv_38= 'groups' ( ( ruleFQN ) ) (otherlv_40= ',' ( ( ruleFQN ) ) )* )? (otherlv_42= 'boards' ( ( ruleFQN ) ) (otherlv_44= ',' ( ( ruleFQN ) ) )* )? (otherlv_46= 'promotions' ( ( ruleFQN ) ) (otherlv_48= ',' ( ( ruleFQN ) ) )* )? (otherlv_50= 'students' ( ( ruleFQN ) ) (otherlv_52= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctCourseOrganisation_54_0= rulectCourseOrganization ) )* ( (lv_rnctPeriod_55_0= rulectPeriod ) )* (otherlv_56= 'tasks' ( ( ruleFQN ) ) (otherlv_58= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctFieldCoverage_60_0= rulectFieldCoverage ) )* otherlv_61= '}' ) ;
    public final EObject rulectCourse() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_3_0=null;
        Token lv_programtype_4_0=null;
        Token lv_programtype_5_0=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token lv_label_9_0=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token lv_beginyear_15_0=null;
        Token otherlv_16=null;
        Token lv_endyear_17_0=null;
        Token otherlv_18=null;
        Token otherlv_20=null;
        Token otherlv_22=null;
        Token lv_hoursperweek_23_0=null;
        Token otherlv_24=null;
        Token lv_hourstotal_25_0=null;
        Token otherlv_26=null;
        Token lv_description_27_0=null;
        Token otherlv_28=null;
        Token lv_credits_29_0=null;
        Token otherlv_30=null;
        Token otherlv_32=null;
        Token otherlv_34=null;
        Token lv_weblink_35_0=null;
        Token otherlv_36=null;
        Token otherlv_38=null;
        Token otherlv_40=null;
        Token otherlv_42=null;
        Token otherlv_44=null;
        Token otherlv_46=null;
        Token otherlv_48=null;
        Token otherlv_50=null;
        Token otherlv_52=null;
        Token otherlv_56=null;
        Token otherlv_58=null;
        Token otherlv_61=null;
        AntlrDatatypeRuleToken lv_hide_0_0 = null;

        AntlrDatatypeRuleToken lv_nature_2_0 = null;

        AntlrDatatypeRuleToken lv_reference_11_0 = null;

        AntlrDatatypeRuleToken lv_languages_31_0 = null;

        AntlrDatatypeRuleToken lv_languages_33_0 = null;

        EObject lv_rnctCourseOrganisation_54_0 = null;

        EObject lv_rnctPeriod_55_0 = null;

        EObject lv_rnctFieldCoverage_60_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:2151:2: ( ( ( (lv_hide_0_0= ruleHIDDEN ) )? otherlv_1= 'Course' ( (lv_nature_2_0= ruleNATUREOFCOURSE ) ) ( (lv_name_3_0= RULE_ID ) ) ( ( ( (lv_programtype_4_0= 'belongs' ) ) | ( (lv_programtype_5_0= 'in' ) ) ) ( ( ruleFQN ) ) )? otherlv_7= '{' (otherlv_8= 'name' ( (lv_label_9_0= RULE_STRING ) ) ) (otherlv_10= 'reference' ( (lv_reference_11_0= ruleREFERENCE ) ) ) (otherlv_12= 'corecourse' ( ( ruleFQN ) ) )? (otherlv_14= 'academicyear' ( (lv_beginyear_15_0= RULE_INT ) ) otherlv_16= '/' ( (lv_endyear_17_0= RULE_INT ) ) ) (otherlv_18= 'term' ( ( ruleFQN ) ) ) (otherlv_20= 'module' ( ( ruleFQN ) ) )? (otherlv_22= 'hoursPerWeek' ( (lv_hoursperweek_23_0= RULE_INT ) ) ) (otherlv_24= 'totalHours' ( (lv_hourstotal_25_0= RULE_INT ) ) ) (otherlv_26= 'description' ( (lv_description_27_0= RULE_STRING ) ) ) (otherlv_28= 'credits' ( (lv_credits_29_0= RULE_INT ) ) ) (otherlv_30= 'languages' ( (lv_languages_31_0= ruleLANGUAGE ) ) (otherlv_32= ',' ( (lv_languages_33_0= ruleLANGUAGE ) ) )* )? (otherlv_34= 'weblink' ( (lv_weblink_35_0= RULE_STRING ) ) )? (otherlv_36= 'coursemoderator' ( ( ruleFQN ) ) )? (otherlv_38= 'groups' ( ( ruleFQN ) ) (otherlv_40= ',' ( ( ruleFQN ) ) )* )? (otherlv_42= 'boards' ( ( ruleFQN ) ) (otherlv_44= ',' ( ( ruleFQN ) ) )* )? (otherlv_46= 'promotions' ( ( ruleFQN ) ) (otherlv_48= ',' ( ( ruleFQN ) ) )* )? (otherlv_50= 'students' ( ( ruleFQN ) ) (otherlv_52= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctCourseOrganisation_54_0= rulectCourseOrganization ) )* ( (lv_rnctPeriod_55_0= rulectPeriod ) )* (otherlv_56= 'tasks' ( ( ruleFQN ) ) (otherlv_58= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctFieldCoverage_60_0= rulectFieldCoverage ) )* otherlv_61= '}' ) )
            // InternalUmlModel.g:2152:2: ( ( (lv_hide_0_0= ruleHIDDEN ) )? otherlv_1= 'Course' ( (lv_nature_2_0= ruleNATUREOFCOURSE ) ) ( (lv_name_3_0= RULE_ID ) ) ( ( ( (lv_programtype_4_0= 'belongs' ) ) | ( (lv_programtype_5_0= 'in' ) ) ) ( ( ruleFQN ) ) )? otherlv_7= '{' (otherlv_8= 'name' ( (lv_label_9_0= RULE_STRING ) ) ) (otherlv_10= 'reference' ( (lv_reference_11_0= ruleREFERENCE ) ) ) (otherlv_12= 'corecourse' ( ( ruleFQN ) ) )? (otherlv_14= 'academicyear' ( (lv_beginyear_15_0= RULE_INT ) ) otherlv_16= '/' ( (lv_endyear_17_0= RULE_INT ) ) ) (otherlv_18= 'term' ( ( ruleFQN ) ) ) (otherlv_20= 'module' ( ( ruleFQN ) ) )? (otherlv_22= 'hoursPerWeek' ( (lv_hoursperweek_23_0= RULE_INT ) ) ) (otherlv_24= 'totalHours' ( (lv_hourstotal_25_0= RULE_INT ) ) ) (otherlv_26= 'description' ( (lv_description_27_0= RULE_STRING ) ) ) (otherlv_28= 'credits' ( (lv_credits_29_0= RULE_INT ) ) ) (otherlv_30= 'languages' ( (lv_languages_31_0= ruleLANGUAGE ) ) (otherlv_32= ',' ( (lv_languages_33_0= ruleLANGUAGE ) ) )* )? (otherlv_34= 'weblink' ( (lv_weblink_35_0= RULE_STRING ) ) )? (otherlv_36= 'coursemoderator' ( ( ruleFQN ) ) )? (otherlv_38= 'groups' ( ( ruleFQN ) ) (otherlv_40= ',' ( ( ruleFQN ) ) )* )? (otherlv_42= 'boards' ( ( ruleFQN ) ) (otherlv_44= ',' ( ( ruleFQN ) ) )* )? (otherlv_46= 'promotions' ( ( ruleFQN ) ) (otherlv_48= ',' ( ( ruleFQN ) ) )* )? (otherlv_50= 'students' ( ( ruleFQN ) ) (otherlv_52= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctCourseOrganisation_54_0= rulectCourseOrganization ) )* ( (lv_rnctPeriod_55_0= rulectPeriod ) )* (otherlv_56= 'tasks' ( ( ruleFQN ) ) (otherlv_58= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctFieldCoverage_60_0= rulectFieldCoverage ) )* otherlv_61= '}' )
            {
            // InternalUmlModel.g:2152:2: ( ( (lv_hide_0_0= ruleHIDDEN ) )? otherlv_1= 'Course' ( (lv_nature_2_0= ruleNATUREOFCOURSE ) ) ( (lv_name_3_0= RULE_ID ) ) ( ( ( (lv_programtype_4_0= 'belongs' ) ) | ( (lv_programtype_5_0= 'in' ) ) ) ( ( ruleFQN ) ) )? otherlv_7= '{' (otherlv_8= 'name' ( (lv_label_9_0= RULE_STRING ) ) ) (otherlv_10= 'reference' ( (lv_reference_11_0= ruleREFERENCE ) ) ) (otherlv_12= 'corecourse' ( ( ruleFQN ) ) )? (otherlv_14= 'academicyear' ( (lv_beginyear_15_0= RULE_INT ) ) otherlv_16= '/' ( (lv_endyear_17_0= RULE_INT ) ) ) (otherlv_18= 'term' ( ( ruleFQN ) ) ) (otherlv_20= 'module' ( ( ruleFQN ) ) )? (otherlv_22= 'hoursPerWeek' ( (lv_hoursperweek_23_0= RULE_INT ) ) ) (otherlv_24= 'totalHours' ( (lv_hourstotal_25_0= RULE_INT ) ) ) (otherlv_26= 'description' ( (lv_description_27_0= RULE_STRING ) ) ) (otherlv_28= 'credits' ( (lv_credits_29_0= RULE_INT ) ) ) (otherlv_30= 'languages' ( (lv_languages_31_0= ruleLANGUAGE ) ) (otherlv_32= ',' ( (lv_languages_33_0= ruleLANGUAGE ) ) )* )? (otherlv_34= 'weblink' ( (lv_weblink_35_0= RULE_STRING ) ) )? (otherlv_36= 'coursemoderator' ( ( ruleFQN ) ) )? (otherlv_38= 'groups' ( ( ruleFQN ) ) (otherlv_40= ',' ( ( ruleFQN ) ) )* )? (otherlv_42= 'boards' ( ( ruleFQN ) ) (otherlv_44= ',' ( ( ruleFQN ) ) )* )? (otherlv_46= 'promotions' ( ( ruleFQN ) ) (otherlv_48= ',' ( ( ruleFQN ) ) )* )? (otherlv_50= 'students' ( ( ruleFQN ) ) (otherlv_52= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctCourseOrganisation_54_0= rulectCourseOrganization ) )* ( (lv_rnctPeriod_55_0= rulectPeriod ) )* (otherlv_56= 'tasks' ( ( ruleFQN ) ) (otherlv_58= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctFieldCoverage_60_0= rulectFieldCoverage ) )* otherlv_61= '}' )
            // InternalUmlModel.g:2153:3: ( (lv_hide_0_0= ruleHIDDEN ) )? otherlv_1= 'Course' ( (lv_nature_2_0= ruleNATUREOFCOURSE ) ) ( (lv_name_3_0= RULE_ID ) ) ( ( ( (lv_programtype_4_0= 'belongs' ) ) | ( (lv_programtype_5_0= 'in' ) ) ) ( ( ruleFQN ) ) )? otherlv_7= '{' (otherlv_8= 'name' ( (lv_label_9_0= RULE_STRING ) ) ) (otherlv_10= 'reference' ( (lv_reference_11_0= ruleREFERENCE ) ) ) (otherlv_12= 'corecourse' ( ( ruleFQN ) ) )? (otherlv_14= 'academicyear' ( (lv_beginyear_15_0= RULE_INT ) ) otherlv_16= '/' ( (lv_endyear_17_0= RULE_INT ) ) ) (otherlv_18= 'term' ( ( ruleFQN ) ) ) (otherlv_20= 'module' ( ( ruleFQN ) ) )? (otherlv_22= 'hoursPerWeek' ( (lv_hoursperweek_23_0= RULE_INT ) ) ) (otherlv_24= 'totalHours' ( (lv_hourstotal_25_0= RULE_INT ) ) ) (otherlv_26= 'description' ( (lv_description_27_0= RULE_STRING ) ) ) (otherlv_28= 'credits' ( (lv_credits_29_0= RULE_INT ) ) ) (otherlv_30= 'languages' ( (lv_languages_31_0= ruleLANGUAGE ) ) (otherlv_32= ',' ( (lv_languages_33_0= ruleLANGUAGE ) ) )* )? (otherlv_34= 'weblink' ( (lv_weblink_35_0= RULE_STRING ) ) )? (otherlv_36= 'coursemoderator' ( ( ruleFQN ) ) )? (otherlv_38= 'groups' ( ( ruleFQN ) ) (otherlv_40= ',' ( ( ruleFQN ) ) )* )? (otherlv_42= 'boards' ( ( ruleFQN ) ) (otherlv_44= ',' ( ( ruleFQN ) ) )* )? (otherlv_46= 'promotions' ( ( ruleFQN ) ) (otherlv_48= ',' ( ( ruleFQN ) ) )* )? (otherlv_50= 'students' ( ( ruleFQN ) ) (otherlv_52= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctCourseOrganisation_54_0= rulectCourseOrganization ) )* ( (lv_rnctPeriod_55_0= rulectPeriod ) )* (otherlv_56= 'tasks' ( ( ruleFQN ) ) (otherlv_58= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctFieldCoverage_60_0= rulectFieldCoverage ) )* otherlv_61= '}'
            {
            // InternalUmlModel.g:2153:3: ( (lv_hide_0_0= ruleHIDDEN ) )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==105) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalUmlModel.g:2154:4: (lv_hide_0_0= ruleHIDDEN )
                    {
                    // InternalUmlModel.g:2154:4: (lv_hide_0_0= ruleHIDDEN )
                    // InternalUmlModel.g:2155:5: lv_hide_0_0= ruleHIDDEN
                    {

                    					newCompositeNode(grammarAccess.getCtCourseAccess().getHideHIDDENParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_61);
                    lv_hide_0_0=ruleHIDDEN();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtCourseRule());
                    					}
                    					set(
                    						current,
                    						"hide",
                    						lv_hide_0_0,
                    						"tesma.ovanes.UmlModel.HIDDEN");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            otherlv_1=(Token)match(input,54,FOLLOW_62); 

            			newLeafNode(otherlv_1, grammarAccess.getCtCourseAccess().getCourseKeyword_1());
            		
            // InternalUmlModel.g:2176:3: ( (lv_nature_2_0= ruleNATUREOFCOURSE ) )
            // InternalUmlModel.g:2177:4: (lv_nature_2_0= ruleNATUREOFCOURSE )
            {
            // InternalUmlModel.g:2177:4: (lv_nature_2_0= ruleNATUREOFCOURSE )
            // InternalUmlModel.g:2178:5: lv_nature_2_0= ruleNATUREOFCOURSE
            {

            					newCompositeNode(grammarAccess.getCtCourseAccess().getNatureNATUREOFCOURSEParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_4);
            lv_nature_2_0=ruleNATUREOFCOURSE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCtCourseRule());
            					}
            					set(
            						current,
            						"nature",
            						lv_nature_2_0,
            						"tesma.ovanes.UmlModel.NATUREOFCOURSE");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalUmlModel.g:2195:3: ( (lv_name_3_0= RULE_ID ) )
            // InternalUmlModel.g:2196:4: (lv_name_3_0= RULE_ID )
            {
            // InternalUmlModel.g:2196:4: (lv_name_3_0= RULE_ID )
            // InternalUmlModel.g:2197:5: lv_name_3_0= RULE_ID
            {
            lv_name_3_0=(Token)match(input,RULE_ID,FOLLOW_63); 

            					newLeafNode(lv_name_3_0, grammarAccess.getCtCourseAccess().getNameIDTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtCourseRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalUmlModel.g:2213:3: ( ( ( (lv_programtype_4_0= 'belongs' ) ) | ( (lv_programtype_5_0= 'in' ) ) ) ( ( ruleFQN ) ) )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==44||LA48_0==55) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalUmlModel.g:2214:4: ( ( (lv_programtype_4_0= 'belongs' ) ) | ( (lv_programtype_5_0= 'in' ) ) ) ( ( ruleFQN ) )
                    {
                    // InternalUmlModel.g:2214:4: ( ( (lv_programtype_4_0= 'belongs' ) ) | ( (lv_programtype_5_0= 'in' ) ) )
                    int alt47=2;
                    int LA47_0 = input.LA(1);

                    if ( (LA47_0==55) ) {
                        alt47=1;
                    }
                    else if ( (LA47_0==44) ) {
                        alt47=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 47, 0, input);

                        throw nvae;
                    }
                    switch (alt47) {
                        case 1 :
                            // InternalUmlModel.g:2215:5: ( (lv_programtype_4_0= 'belongs' ) )
                            {
                            // InternalUmlModel.g:2215:5: ( (lv_programtype_4_0= 'belongs' ) )
                            // InternalUmlModel.g:2216:6: (lv_programtype_4_0= 'belongs' )
                            {
                            // InternalUmlModel.g:2216:6: (lv_programtype_4_0= 'belongs' )
                            // InternalUmlModel.g:2217:7: lv_programtype_4_0= 'belongs'
                            {
                            lv_programtype_4_0=(Token)match(input,55,FOLLOW_4); 

                            							newLeafNode(lv_programtype_4_0, grammarAccess.getCtCourseAccess().getProgramtypeBelongsKeyword_4_0_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getCtCourseRule());
                            							}
                            							setWithLastConsumed(current, "programtype", lv_programtype_4_0, "belongs");
                            						

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalUmlModel.g:2230:5: ( (lv_programtype_5_0= 'in' ) )
                            {
                            // InternalUmlModel.g:2230:5: ( (lv_programtype_5_0= 'in' ) )
                            // InternalUmlModel.g:2231:6: (lv_programtype_5_0= 'in' )
                            {
                            // InternalUmlModel.g:2231:6: (lv_programtype_5_0= 'in' )
                            // InternalUmlModel.g:2232:7: lv_programtype_5_0= 'in'
                            {
                            lv_programtype_5_0=(Token)match(input,44,FOLLOW_4); 

                            							newLeafNode(lv_programtype_5_0, grammarAccess.getCtCourseAccess().getProgramtypeInKeyword_4_0_1_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getCtCourseRule());
                            							}
                            							setWithLastConsumed(current, "programtype", lv_programtype_5_0, "in");
                            						

                            }


                            }


                            }
                            break;

                    }

                    // InternalUmlModel.g:2245:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:2246:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:2246:5: ( ruleFQN )
                    // InternalUmlModel.g:2247:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtCourseAccess().getRnctMotherProgramCtProgramCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_47);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_7=(Token)match(input,20,FOLLOW_35); 

            			newLeafNode(otherlv_7, grammarAccess.getCtCourseAccess().getLeftCurlyBracketKeyword_5());
            		
            // InternalUmlModel.g:2266:3: (otherlv_8= 'name' ( (lv_label_9_0= RULE_STRING ) ) )
            // InternalUmlModel.g:2267:4: otherlv_8= 'name' ( (lv_label_9_0= RULE_STRING ) )
            {
            otherlv_8=(Token)match(input,36,FOLLOW_10); 

            				newLeafNode(otherlv_8, grammarAccess.getCtCourseAccess().getNameKeyword_6_0());
            			
            // InternalUmlModel.g:2271:4: ( (lv_label_9_0= RULE_STRING ) )
            // InternalUmlModel.g:2272:5: (lv_label_9_0= RULE_STRING )
            {
            // InternalUmlModel.g:2272:5: (lv_label_9_0= RULE_STRING )
            // InternalUmlModel.g:2273:6: lv_label_9_0= RULE_STRING
            {
            lv_label_9_0=(Token)match(input,RULE_STRING,FOLLOW_64); 

            						newLeafNode(lv_label_9_0, grammarAccess.getCtCourseAccess().getLabelSTRINGTerminalRuleCall_6_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtCourseRule());
            						}
            						setWithLastConsumed(
            							current,
            							"label",
            							lv_label_9_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalUmlModel.g:2290:3: (otherlv_10= 'reference' ( (lv_reference_11_0= ruleREFERENCE ) ) )
            // InternalUmlModel.g:2291:4: otherlv_10= 'reference' ( (lv_reference_11_0= ruleREFERENCE ) )
            {
            otherlv_10=(Token)match(input,56,FOLLOW_6); 

            				newLeafNode(otherlv_10, grammarAccess.getCtCourseAccess().getReferenceKeyword_7_0());
            			
            // InternalUmlModel.g:2295:4: ( (lv_reference_11_0= ruleREFERENCE ) )
            // InternalUmlModel.g:2296:5: (lv_reference_11_0= ruleREFERENCE )
            {
            // InternalUmlModel.g:2296:5: (lv_reference_11_0= ruleREFERENCE )
            // InternalUmlModel.g:2297:6: lv_reference_11_0= ruleREFERENCE
            {

            						newCompositeNode(grammarAccess.getCtCourseAccess().getReferenceREFERENCEParserRuleCall_7_1_0());
            					
            pushFollow(FOLLOW_65);
            lv_reference_11_0=ruleREFERENCE();

            state._fsp--;


            						if (current==null) {
            							current = createModelElementForParent(grammarAccess.getCtCourseRule());
            						}
            						set(
            							current,
            							"reference",
            							lv_reference_11_0,
            							"tesma.ovanes.UmlModel.REFERENCE");
            						afterParserOrEnumRuleCall();
            					

            }


            }


            }

            // InternalUmlModel.g:2315:3: (otherlv_12= 'corecourse' ( ( ruleFQN ) ) )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==57) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalUmlModel.g:2316:4: otherlv_12= 'corecourse' ( ( ruleFQN ) )
                    {
                    otherlv_12=(Token)match(input,57,FOLLOW_4); 

                    				newLeafNode(otherlv_12, grammarAccess.getCtCourseAccess().getCorecourseKeyword_8_0());
                    			
                    // InternalUmlModel.g:2320:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:2321:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:2321:5: ( ruleFQN )
                    // InternalUmlModel.g:2322:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtCourseAccess().getCorecourseCtCourseCrossReference_8_1_0());
                    					
                    pushFollow(FOLLOW_66);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:2337:3: (otherlv_14= 'academicyear' ( (lv_beginyear_15_0= RULE_INT ) ) otherlv_16= '/' ( (lv_endyear_17_0= RULE_INT ) ) )
            // InternalUmlModel.g:2338:4: otherlv_14= 'academicyear' ( (lv_beginyear_15_0= RULE_INT ) ) otherlv_16= '/' ( (lv_endyear_17_0= RULE_INT ) )
            {
            otherlv_14=(Token)match(input,58,FOLLOW_6); 

            				newLeafNode(otherlv_14, grammarAccess.getCtCourseAccess().getAcademicyearKeyword_9_0());
            			
            // InternalUmlModel.g:2342:4: ( (lv_beginyear_15_0= RULE_INT ) )
            // InternalUmlModel.g:2343:5: (lv_beginyear_15_0= RULE_INT )
            {
            // InternalUmlModel.g:2343:5: (lv_beginyear_15_0= RULE_INT )
            // InternalUmlModel.g:2344:6: lv_beginyear_15_0= RULE_INT
            {
            lv_beginyear_15_0=(Token)match(input,RULE_INT,FOLLOW_67); 

            						newLeafNode(lv_beginyear_15_0, grammarAccess.getCtCourseAccess().getBeginyearINTTerminalRuleCall_9_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtCourseRule());
            						}
            						setWithLastConsumed(
            							current,
            							"beginyear",
            							lv_beginyear_15_0,
            							"org.eclipse.xtext.common.Terminals.INT");
            					

            }


            }

            otherlv_16=(Token)match(input,59,FOLLOW_6); 

            				newLeafNode(otherlv_16, grammarAccess.getCtCourseAccess().getSolidusKeyword_9_2());
            			
            // InternalUmlModel.g:2364:4: ( (lv_endyear_17_0= RULE_INT ) )
            // InternalUmlModel.g:2365:5: (lv_endyear_17_0= RULE_INT )
            {
            // InternalUmlModel.g:2365:5: (lv_endyear_17_0= RULE_INT )
            // InternalUmlModel.g:2366:6: lv_endyear_17_0= RULE_INT
            {
            lv_endyear_17_0=(Token)match(input,RULE_INT,FOLLOW_68); 

            						newLeafNode(lv_endyear_17_0, grammarAccess.getCtCourseAccess().getEndyearINTTerminalRuleCall_9_3_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtCourseRule());
            						}
            						setWithLastConsumed(
            							current,
            							"endyear",
            							lv_endyear_17_0,
            							"org.eclipse.xtext.common.Terminals.INT");
            					

            }


            }


            }

            // InternalUmlModel.g:2383:3: (otherlv_18= 'term' ( ( ruleFQN ) ) )
            // InternalUmlModel.g:2384:4: otherlv_18= 'term' ( ( ruleFQN ) )
            {
            otherlv_18=(Token)match(input,60,FOLLOW_4); 

            				newLeafNode(otherlv_18, grammarAccess.getCtCourseAccess().getTermKeyword_10_0());
            			
            // InternalUmlModel.g:2388:4: ( ( ruleFQN ) )
            // InternalUmlModel.g:2389:5: ( ruleFQN )
            {
            // InternalUmlModel.g:2389:5: ( ruleFQN )
            // InternalUmlModel.g:2390:6: ruleFQN
            {

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtCourseRule());
            						}
            					

            						newCompositeNode(grammarAccess.getCtCourseAccess().getRnctTermCtTermCrossReference_10_1_0());
            					
            pushFollow(FOLLOW_69);
            ruleFQN();

            state._fsp--;


            						afterParserOrEnumRuleCall();
            					

            }


            }


            }

            // InternalUmlModel.g:2405:3: (otherlv_20= 'module' ( ( ruleFQN ) ) )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==61) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // InternalUmlModel.g:2406:4: otherlv_20= 'module' ( ( ruleFQN ) )
                    {
                    otherlv_20=(Token)match(input,61,FOLLOW_4); 

                    				newLeafNode(otherlv_20, grammarAccess.getCtCourseAccess().getModuleKeyword_11_0());
                    			
                    // InternalUmlModel.g:2410:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:2411:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:2411:5: ( ruleFQN )
                    // InternalUmlModel.g:2412:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtCourseAccess().getRnctModuleCtModuleCrossReference_11_1_0());
                    					
                    pushFollow(FOLLOW_70);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:2427:3: (otherlv_22= 'hoursPerWeek' ( (lv_hoursperweek_23_0= RULE_INT ) ) )
            // InternalUmlModel.g:2428:4: otherlv_22= 'hoursPerWeek' ( (lv_hoursperweek_23_0= RULE_INT ) )
            {
            otherlv_22=(Token)match(input,62,FOLLOW_6); 

            				newLeafNode(otherlv_22, grammarAccess.getCtCourseAccess().getHoursPerWeekKeyword_12_0());
            			
            // InternalUmlModel.g:2432:4: ( (lv_hoursperweek_23_0= RULE_INT ) )
            // InternalUmlModel.g:2433:5: (lv_hoursperweek_23_0= RULE_INT )
            {
            // InternalUmlModel.g:2433:5: (lv_hoursperweek_23_0= RULE_INT )
            // InternalUmlModel.g:2434:6: lv_hoursperweek_23_0= RULE_INT
            {
            lv_hoursperweek_23_0=(Token)match(input,RULE_INT,FOLLOW_71); 

            						newLeafNode(lv_hoursperweek_23_0, grammarAccess.getCtCourseAccess().getHoursperweekINTTerminalRuleCall_12_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtCourseRule());
            						}
            						setWithLastConsumed(
            							current,
            							"hoursperweek",
            							lv_hoursperweek_23_0,
            							"org.eclipse.xtext.common.Terminals.INT");
            					

            }


            }


            }

            // InternalUmlModel.g:2451:3: (otherlv_24= 'totalHours' ( (lv_hourstotal_25_0= RULE_INT ) ) )
            // InternalUmlModel.g:2452:4: otherlv_24= 'totalHours' ( (lv_hourstotal_25_0= RULE_INT ) )
            {
            otherlv_24=(Token)match(input,63,FOLLOW_6); 

            				newLeafNode(otherlv_24, grammarAccess.getCtCourseAccess().getTotalHoursKeyword_13_0());
            			
            // InternalUmlModel.g:2456:4: ( (lv_hourstotal_25_0= RULE_INT ) )
            // InternalUmlModel.g:2457:5: (lv_hourstotal_25_0= RULE_INT )
            {
            // InternalUmlModel.g:2457:5: (lv_hourstotal_25_0= RULE_INT )
            // InternalUmlModel.g:2458:6: lv_hourstotal_25_0= RULE_INT
            {
            lv_hourstotal_25_0=(Token)match(input,RULE_INT,FOLLOW_9); 

            						newLeafNode(lv_hourstotal_25_0, grammarAccess.getCtCourseAccess().getHourstotalINTTerminalRuleCall_13_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtCourseRule());
            						}
            						setWithLastConsumed(
            							current,
            							"hourstotal",
            							lv_hourstotal_25_0,
            							"org.eclipse.xtext.common.Terminals.INT");
            					

            }


            }


            }

            // InternalUmlModel.g:2475:3: (otherlv_26= 'description' ( (lv_description_27_0= RULE_STRING ) ) )
            // InternalUmlModel.g:2476:4: otherlv_26= 'description' ( (lv_description_27_0= RULE_STRING ) )
            {
            otherlv_26=(Token)match(input,14,FOLLOW_10); 

            				newLeafNode(otherlv_26, grammarAccess.getCtCourseAccess().getDescriptionKeyword_14_0());
            			
            // InternalUmlModel.g:2480:4: ( (lv_description_27_0= RULE_STRING ) )
            // InternalUmlModel.g:2481:5: (lv_description_27_0= RULE_STRING )
            {
            // InternalUmlModel.g:2481:5: (lv_description_27_0= RULE_STRING )
            // InternalUmlModel.g:2482:6: lv_description_27_0= RULE_STRING
            {
            lv_description_27_0=(Token)match(input,RULE_STRING,FOLLOW_72); 

            						newLeafNode(lv_description_27_0, grammarAccess.getCtCourseAccess().getDescriptionSTRINGTerminalRuleCall_14_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtCourseRule());
            						}
            						setWithLastConsumed(
            							current,
            							"description",
            							lv_description_27_0,
            							"org.eclipse.xtext.common.Terminals.STRING");
            					

            }


            }


            }

            // InternalUmlModel.g:2499:3: (otherlv_28= 'credits' ( (lv_credits_29_0= RULE_INT ) ) )
            // InternalUmlModel.g:2500:4: otherlv_28= 'credits' ( (lv_credits_29_0= RULE_INT ) )
            {
            otherlv_28=(Token)match(input,64,FOLLOW_6); 

            				newLeafNode(otherlv_28, grammarAccess.getCtCourseAccess().getCreditsKeyword_15_0());
            			
            // InternalUmlModel.g:2504:4: ( (lv_credits_29_0= RULE_INT ) )
            // InternalUmlModel.g:2505:5: (lv_credits_29_0= RULE_INT )
            {
            // InternalUmlModel.g:2505:5: (lv_credits_29_0= RULE_INT )
            // InternalUmlModel.g:2506:6: lv_credits_29_0= RULE_INT
            {
            lv_credits_29_0=(Token)match(input,RULE_INT,FOLLOW_73); 

            						newLeafNode(lv_credits_29_0, grammarAccess.getCtCourseAccess().getCreditsINTTerminalRuleCall_15_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtCourseRule());
            						}
            						setWithLastConsumed(
            							current,
            							"credits",
            							lv_credits_29_0,
            							"org.eclipse.xtext.common.Terminals.INT");
            					

            }


            }


            }

            // InternalUmlModel.g:2523:3: (otherlv_30= 'languages' ( (lv_languages_31_0= ruleLANGUAGE ) ) (otherlv_32= ',' ( (lv_languages_33_0= ruleLANGUAGE ) ) )* )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==65) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalUmlModel.g:2524:4: otherlv_30= 'languages' ( (lv_languages_31_0= ruleLANGUAGE ) ) (otherlv_32= ',' ( (lv_languages_33_0= ruleLANGUAGE ) ) )*
                    {
                    otherlv_30=(Token)match(input,65,FOLLOW_10); 

                    				newLeafNode(otherlv_30, grammarAccess.getCtCourseAccess().getLanguagesKeyword_16_0());
                    			
                    // InternalUmlModel.g:2528:4: ( (lv_languages_31_0= ruleLANGUAGE ) )
                    // InternalUmlModel.g:2529:5: (lv_languages_31_0= ruleLANGUAGE )
                    {
                    // InternalUmlModel.g:2529:5: (lv_languages_31_0= ruleLANGUAGE )
                    // InternalUmlModel.g:2530:6: lv_languages_31_0= ruleLANGUAGE
                    {

                    						newCompositeNode(grammarAccess.getCtCourseAccess().getLanguagesLANGUAGEParserRuleCall_16_1_0());
                    					
                    pushFollow(FOLLOW_74);
                    lv_languages_31_0=ruleLANGUAGE();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCtCourseRule());
                    						}
                    						add(
                    							current,
                    							"languages",
                    							lv_languages_31_0,
                    							"tesma.ovanes.UmlModel.LANGUAGE");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:2547:4: (otherlv_32= ',' ( (lv_languages_33_0= ruleLANGUAGE ) ) )*
                    loop51:
                    do {
                        int alt51=2;
                        int LA51_0 = input.LA(1);

                        if ( (LA51_0==16) ) {
                            alt51=1;
                        }


                        switch (alt51) {
                    	case 1 :
                    	    // InternalUmlModel.g:2548:5: otherlv_32= ',' ( (lv_languages_33_0= ruleLANGUAGE ) )
                    	    {
                    	    otherlv_32=(Token)match(input,16,FOLLOW_10); 

                    	    					newLeafNode(otherlv_32, grammarAccess.getCtCourseAccess().getCommaKeyword_16_2_0());
                    	    				
                    	    // InternalUmlModel.g:2552:5: ( (lv_languages_33_0= ruleLANGUAGE ) )
                    	    // InternalUmlModel.g:2553:6: (lv_languages_33_0= ruleLANGUAGE )
                    	    {
                    	    // InternalUmlModel.g:2553:6: (lv_languages_33_0= ruleLANGUAGE )
                    	    // InternalUmlModel.g:2554:7: lv_languages_33_0= ruleLANGUAGE
                    	    {

                    	    							newCompositeNode(grammarAccess.getCtCourseAccess().getLanguagesLANGUAGEParserRuleCall_16_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_74);
                    	    lv_languages_33_0=ruleLANGUAGE();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getCtCourseRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"languages",
                    	    								lv_languages_33_0,
                    	    								"tesma.ovanes.UmlModel.LANGUAGE");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop51;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:2573:3: (otherlv_34= 'weblink' ( (lv_weblink_35_0= RULE_STRING ) ) )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==52) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalUmlModel.g:2574:4: otherlv_34= 'weblink' ( (lv_weblink_35_0= RULE_STRING ) )
                    {
                    otherlv_34=(Token)match(input,52,FOLLOW_10); 

                    				newLeafNode(otherlv_34, grammarAccess.getCtCourseAccess().getWeblinkKeyword_17_0());
                    			
                    // InternalUmlModel.g:2578:4: ( (lv_weblink_35_0= RULE_STRING ) )
                    // InternalUmlModel.g:2579:5: (lv_weblink_35_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:2579:5: (lv_weblink_35_0= RULE_STRING )
                    // InternalUmlModel.g:2580:6: lv_weblink_35_0= RULE_STRING
                    {
                    lv_weblink_35_0=(Token)match(input,RULE_STRING,FOLLOW_75); 

                    						newLeafNode(lv_weblink_35_0, grammarAccess.getCtCourseAccess().getWeblinkSTRINGTerminalRuleCall_17_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"weblink",
                    							lv_weblink_35_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:2597:3: (otherlv_36= 'coursemoderator' ( ( ruleFQN ) ) )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==66) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalUmlModel.g:2598:4: otherlv_36= 'coursemoderator' ( ( ruleFQN ) )
                    {
                    otherlv_36=(Token)match(input,66,FOLLOW_4); 

                    				newLeafNode(otherlv_36, grammarAccess.getCtCourseAccess().getCoursemoderatorKeyword_18_0());
                    			
                    // InternalUmlModel.g:2602:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:2603:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:2603:5: ( ruleFQN )
                    // InternalUmlModel.g:2604:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtCourseAccess().getCoursemoderatorCtInstructorCrossReference_18_1_0());
                    					
                    pushFollow(FOLLOW_76);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:2619:3: (otherlv_38= 'groups' ( ( ruleFQN ) ) (otherlv_40= ',' ( ( ruleFQN ) ) )* )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==67) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalUmlModel.g:2620:4: otherlv_38= 'groups' ( ( ruleFQN ) ) (otherlv_40= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_38=(Token)match(input,67,FOLLOW_4); 

                    				newLeafNode(otherlv_38, grammarAccess.getCtCourseAccess().getGroupsKeyword_19_0());
                    			
                    // InternalUmlModel.g:2624:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:2625:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:2625:5: ( ruleFQN )
                    // InternalUmlModel.g:2626:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtCourseAccess().getRnctGroupCtGroupCrossReference_19_1_0());
                    					
                    pushFollow(FOLLOW_77);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:2640:4: (otherlv_40= ',' ( ( ruleFQN ) ) )*
                    loop55:
                    do {
                        int alt55=2;
                        int LA55_0 = input.LA(1);

                        if ( (LA55_0==16) ) {
                            alt55=1;
                        }


                        switch (alt55) {
                    	case 1 :
                    	    // InternalUmlModel.g:2641:5: otherlv_40= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_40=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_40, grammarAccess.getCtCourseAccess().getCommaKeyword_19_2_0());
                    	    				
                    	    // InternalUmlModel.g:2645:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:2646:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:2646:6: ( ruleFQN )
                    	    // InternalUmlModel.g:2647:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtCourseRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtCourseAccess().getRnctGroupCtGroupCrossReference_19_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_77);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop55;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:2663:3: (otherlv_42= 'boards' ( ( ruleFQN ) ) (otherlv_44= ',' ( ( ruleFQN ) ) )* )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==68) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalUmlModel.g:2664:4: otherlv_42= 'boards' ( ( ruleFQN ) ) (otherlv_44= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_42=(Token)match(input,68,FOLLOW_4); 

                    				newLeafNode(otherlv_42, grammarAccess.getCtCourseAccess().getBoardsKeyword_20_0());
                    			
                    // InternalUmlModel.g:2668:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:2669:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:2669:5: ( ruleFQN )
                    // InternalUmlModel.g:2670:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtCourseAccess().getRnctBoardCtBoardCrossReference_20_1_0());
                    					
                    pushFollow(FOLLOW_78);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:2684:4: (otherlv_44= ',' ( ( ruleFQN ) ) )*
                    loop57:
                    do {
                        int alt57=2;
                        int LA57_0 = input.LA(1);

                        if ( (LA57_0==16) ) {
                            alt57=1;
                        }


                        switch (alt57) {
                    	case 1 :
                    	    // InternalUmlModel.g:2685:5: otherlv_44= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_44=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_44, grammarAccess.getCtCourseAccess().getCommaKeyword_20_2_0());
                    	    				
                    	    // InternalUmlModel.g:2689:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:2690:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:2690:6: ( ruleFQN )
                    	    // InternalUmlModel.g:2691:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtCourseRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtCourseAccess().getRnctBoardCtBoardCrossReference_20_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_78);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop57;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:2707:3: (otherlv_46= 'promotions' ( ( ruleFQN ) ) (otherlv_48= ',' ( ( ruleFQN ) ) )* )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==69) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalUmlModel.g:2708:4: otherlv_46= 'promotions' ( ( ruleFQN ) ) (otherlv_48= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_46=(Token)match(input,69,FOLLOW_4); 

                    				newLeafNode(otherlv_46, grammarAccess.getCtCourseAccess().getPromotionsKeyword_21_0());
                    			
                    // InternalUmlModel.g:2712:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:2713:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:2713:5: ( ruleFQN )
                    // InternalUmlModel.g:2714:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtCourseAccess().getRnctPromotionCtPromotionCrossReference_21_1_0());
                    					
                    pushFollow(FOLLOW_79);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:2728:4: (otherlv_48= ',' ( ( ruleFQN ) ) )*
                    loop59:
                    do {
                        int alt59=2;
                        int LA59_0 = input.LA(1);

                        if ( (LA59_0==16) ) {
                            alt59=1;
                        }


                        switch (alt59) {
                    	case 1 :
                    	    // InternalUmlModel.g:2729:5: otherlv_48= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_48=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_48, grammarAccess.getCtCourseAccess().getCommaKeyword_21_2_0());
                    	    				
                    	    // InternalUmlModel.g:2733:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:2734:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:2734:6: ( ruleFQN )
                    	    // InternalUmlModel.g:2735:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtCourseRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtCourseAccess().getRnctPromotionCtPromotionCrossReference_21_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_79);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop59;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:2751:3: (otherlv_50= 'students' ( ( ruleFQN ) ) (otherlv_52= ',' ( ( ruleFQN ) ) )* )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==70) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalUmlModel.g:2752:4: otherlv_50= 'students' ( ( ruleFQN ) ) (otherlv_52= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_50=(Token)match(input,70,FOLLOW_4); 

                    				newLeafNode(otherlv_50, grammarAccess.getCtCourseAccess().getStudentsKeyword_22_0());
                    			
                    // InternalUmlModel.g:2756:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:2757:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:2757:5: ( ruleFQN )
                    // InternalUmlModel.g:2758:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtCourseAccess().getRnctStudentCtStudentCrossReference_22_1_0());
                    					
                    pushFollow(FOLLOW_80);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:2772:4: (otherlv_52= ',' ( ( ruleFQN ) ) )*
                    loop61:
                    do {
                        int alt61=2;
                        int LA61_0 = input.LA(1);

                        if ( (LA61_0==16) ) {
                            alt61=1;
                        }


                        switch (alt61) {
                    	case 1 :
                    	    // InternalUmlModel.g:2773:5: otherlv_52= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_52=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_52, grammarAccess.getCtCourseAccess().getCommaKeyword_22_2_0());
                    	    				
                    	    // InternalUmlModel.g:2777:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:2778:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:2778:6: ( ruleFQN )
                    	    // InternalUmlModel.g:2779:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtCourseRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtCourseAccess().getRnctStudentCtStudentCrossReference_22_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_80);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop61;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:2795:3: ( (lv_rnctCourseOrganisation_54_0= rulectCourseOrganization ) )*
            loop63:
            do {
                int alt63=2;
                int LA63_0 = input.LA(1);

                if ( (LA63_0==72) ) {
                    alt63=1;
                }


                switch (alt63) {
            	case 1 :
            	    // InternalUmlModel.g:2796:4: (lv_rnctCourseOrganisation_54_0= rulectCourseOrganization )
            	    {
            	    // InternalUmlModel.g:2796:4: (lv_rnctCourseOrganisation_54_0= rulectCourseOrganization )
            	    // InternalUmlModel.g:2797:5: lv_rnctCourseOrganisation_54_0= rulectCourseOrganization
            	    {

            	    					newCompositeNode(grammarAccess.getCtCourseAccess().getRnctCourseOrganisationCtCourseOrganizationParserRuleCall_23_0());
            	    				
            	    pushFollow(FOLLOW_81);
            	    lv_rnctCourseOrganisation_54_0=rulectCourseOrganization();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCtCourseRule());
            	    					}
            	    					add(
            	    						current,
            	    						"rnctCourseOrganisation",
            	    						lv_rnctCourseOrganisation_54_0,
            	    						"tesma.ovanes.UmlModel.ctCourseOrganization");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop63;
                }
            } while (true);

            // InternalUmlModel.g:2814:3: ( (lv_rnctPeriod_55_0= rulectPeriod ) )*
            loop64:
            do {
                int alt64=2;
                int LA64_0 = input.LA(1);

                if ( (LA64_0==77) ) {
                    alt64=1;
                }


                switch (alt64) {
            	case 1 :
            	    // InternalUmlModel.g:2815:4: (lv_rnctPeriod_55_0= rulectPeriod )
            	    {
            	    // InternalUmlModel.g:2815:4: (lv_rnctPeriod_55_0= rulectPeriod )
            	    // InternalUmlModel.g:2816:5: lv_rnctPeriod_55_0= rulectPeriod
            	    {

            	    					newCompositeNode(grammarAccess.getCtCourseAccess().getRnctPeriodCtPeriodParserRuleCall_24_0());
            	    				
            	    pushFollow(FOLLOW_82);
            	    lv_rnctPeriod_55_0=rulectPeriod();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCtCourseRule());
            	    					}
            	    					add(
            	    						current,
            	    						"rnctPeriod",
            	    						lv_rnctPeriod_55_0,
            	    						"tesma.ovanes.UmlModel.ctPeriod");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop64;
                }
            } while (true);

            // InternalUmlModel.g:2833:3: (otherlv_56= 'tasks' ( ( ruleFQN ) ) (otherlv_58= ',' ( ( ruleFQN ) ) )* )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==71) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalUmlModel.g:2834:4: otherlv_56= 'tasks' ( ( ruleFQN ) ) (otherlv_58= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_56=(Token)match(input,71,FOLLOW_4); 

                    				newLeafNode(otherlv_56, grammarAccess.getCtCourseAccess().getTasksKeyword_25_0());
                    			
                    // InternalUmlModel.g:2838:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:2839:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:2839:5: ( ruleFQN )
                    // InternalUmlModel.g:2840:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtCourseAccess().getRnctTasksCtTaskCrossReference_25_1_0());
                    					
                    pushFollow(FOLLOW_83);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:2854:4: (otherlv_58= ',' ( ( ruleFQN ) ) )*
                    loop65:
                    do {
                        int alt65=2;
                        int LA65_0 = input.LA(1);

                        if ( (LA65_0==16) ) {
                            alt65=1;
                        }


                        switch (alt65) {
                    	case 1 :
                    	    // InternalUmlModel.g:2855:5: otherlv_58= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_58=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_58, grammarAccess.getCtCourseAccess().getCommaKeyword_25_2_0());
                    	    				
                    	    // InternalUmlModel.g:2859:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:2860:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:2860:6: ( ruleFQN )
                    	    // InternalUmlModel.g:2861:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtCourseRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtCourseAccess().getRnctTasksCtTaskCrossReference_25_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_83);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop65;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:2877:3: ( (lv_rnctFieldCoverage_60_0= rulectFieldCoverage ) )*
            loop67:
            do {
                int alt67=2;
                int LA67_0 = input.LA(1);

                if ( (LA67_0==99) ) {
                    alt67=1;
                }


                switch (alt67) {
            	case 1 :
            	    // InternalUmlModel.g:2878:4: (lv_rnctFieldCoverage_60_0= rulectFieldCoverage )
            	    {
            	    // InternalUmlModel.g:2878:4: (lv_rnctFieldCoverage_60_0= rulectFieldCoverage )
            	    // InternalUmlModel.g:2879:5: lv_rnctFieldCoverage_60_0= rulectFieldCoverage
            	    {

            	    					newCompositeNode(grammarAccess.getCtCourseAccess().getRnctFieldCoverageCtFieldCoverageParserRuleCall_26_0());
            	    				
            	    pushFollow(FOLLOW_84);
            	    lv_rnctFieldCoverage_60_0=rulectFieldCoverage();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCtCourseRule());
            	    					}
            	    					add(
            	    						current,
            	    						"rnctFieldCoverage",
            	    						lv_rnctFieldCoverage_60_0,
            	    						"tesma.ovanes.UmlModel.ctFieldCoverage");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop67;
                }
            } while (true);

            otherlv_61=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_61, grammarAccess.getCtCourseAccess().getRightCurlyBracketKeyword_27());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectCourse"


    // $ANTLR start "entryRulectCourseOrganization"
    // InternalUmlModel.g:2904:1: entryRulectCourseOrganization returns [EObject current=null] : iv_rulectCourseOrganization= rulectCourseOrganization EOF ;
    public final EObject entryRulectCourseOrganization() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectCourseOrganization = null;


        try {
            // InternalUmlModel.g:2904:61: (iv_rulectCourseOrganization= rulectCourseOrganization EOF )
            // InternalUmlModel.g:2905:2: iv_rulectCourseOrganization= rulectCourseOrganization EOF
            {
             newCompositeNode(grammarAccess.getCtCourseOrganizationRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectCourseOrganization=rulectCourseOrganization();

            state._fsp--;

             current =iv_rulectCourseOrganization; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectCourseOrganization"


    // $ANTLR start "rulectCourseOrganization"
    // InternalUmlModel.g:2911:1: rulectCourseOrganization returns [EObject current=null] : (otherlv_0= 'organization' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'typeof' ( (lv_coursetype_3_0= ruleSUBCOURSETYPE ) ) (otherlv_4= 'called' ( (lv_other_5_0= RULE_STRING ) ) )? otherlv_6= '{' (otherlv_7= 'instructor' ( ( ruleFQN ) ) otherlv_9= ':' otherlv_10= 'hours' ( (lv_totalhours_11_0= RULE_INT ) ) otherlv_12= ',' otherlv_13= 'weight' ( (lv_weight_14_0= RULE_INT ) ) otherlv_15= ',' (otherlv_16= 'language' ( (lv_language_17_0= ruleLANGUAGE ) ) ) )* otherlv_18= '}' ) ;
    public final EObject rulectCourseOrganization() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token lv_other_5_0=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token lv_totalhours_11_0=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token lv_weight_14_0=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_18=null;
        AntlrDatatypeRuleToken lv_coursetype_3_0 = null;

        AntlrDatatypeRuleToken lv_language_17_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:2917:2: ( (otherlv_0= 'organization' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'typeof' ( (lv_coursetype_3_0= ruleSUBCOURSETYPE ) ) (otherlv_4= 'called' ( (lv_other_5_0= RULE_STRING ) ) )? otherlv_6= '{' (otherlv_7= 'instructor' ( ( ruleFQN ) ) otherlv_9= ':' otherlv_10= 'hours' ( (lv_totalhours_11_0= RULE_INT ) ) otherlv_12= ',' otherlv_13= 'weight' ( (lv_weight_14_0= RULE_INT ) ) otherlv_15= ',' (otherlv_16= 'language' ( (lv_language_17_0= ruleLANGUAGE ) ) ) )* otherlv_18= '}' ) )
            // InternalUmlModel.g:2918:2: (otherlv_0= 'organization' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'typeof' ( (lv_coursetype_3_0= ruleSUBCOURSETYPE ) ) (otherlv_4= 'called' ( (lv_other_5_0= RULE_STRING ) ) )? otherlv_6= '{' (otherlv_7= 'instructor' ( ( ruleFQN ) ) otherlv_9= ':' otherlv_10= 'hours' ( (lv_totalhours_11_0= RULE_INT ) ) otherlv_12= ',' otherlv_13= 'weight' ( (lv_weight_14_0= RULE_INT ) ) otherlv_15= ',' (otherlv_16= 'language' ( (lv_language_17_0= ruleLANGUAGE ) ) ) )* otherlv_18= '}' )
            {
            // InternalUmlModel.g:2918:2: (otherlv_0= 'organization' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'typeof' ( (lv_coursetype_3_0= ruleSUBCOURSETYPE ) ) (otherlv_4= 'called' ( (lv_other_5_0= RULE_STRING ) ) )? otherlv_6= '{' (otherlv_7= 'instructor' ( ( ruleFQN ) ) otherlv_9= ':' otherlv_10= 'hours' ( (lv_totalhours_11_0= RULE_INT ) ) otherlv_12= ',' otherlv_13= 'weight' ( (lv_weight_14_0= RULE_INT ) ) otherlv_15= ',' (otherlv_16= 'language' ( (lv_language_17_0= ruleLANGUAGE ) ) ) )* otherlv_18= '}' )
            // InternalUmlModel.g:2919:3: otherlv_0= 'organization' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'typeof' ( (lv_coursetype_3_0= ruleSUBCOURSETYPE ) ) (otherlv_4= 'called' ( (lv_other_5_0= RULE_STRING ) ) )? otherlv_6= '{' (otherlv_7= 'instructor' ( ( ruleFQN ) ) otherlv_9= ':' otherlv_10= 'hours' ( (lv_totalhours_11_0= RULE_INT ) ) otherlv_12= ',' otherlv_13= 'weight' ( (lv_weight_14_0= RULE_INT ) ) otherlv_15= ',' (otherlv_16= 'language' ( (lv_language_17_0= ruleLANGUAGE ) ) ) )* otherlv_18= '}'
            {
            otherlv_0=(Token)match(input,72,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtCourseOrganizationAccess().getOrganizationKeyword_0());
            		
            // InternalUmlModel.g:2923:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:2924:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:2924:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:2925:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_85); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtCourseOrganizationAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtCourseOrganizationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,73,FOLLOW_86); 

            			newLeafNode(otherlv_2, grammarAccess.getCtCourseOrganizationAccess().getTypeofKeyword_2());
            		
            // InternalUmlModel.g:2945:3: ( (lv_coursetype_3_0= ruleSUBCOURSETYPE ) )
            // InternalUmlModel.g:2946:4: (lv_coursetype_3_0= ruleSUBCOURSETYPE )
            {
            // InternalUmlModel.g:2946:4: (lv_coursetype_3_0= ruleSUBCOURSETYPE )
            // InternalUmlModel.g:2947:5: lv_coursetype_3_0= ruleSUBCOURSETYPE
            {

            					newCompositeNode(grammarAccess.getCtCourseOrganizationAccess().getCoursetypeSUBCOURSETYPEParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_87);
            lv_coursetype_3_0=ruleSUBCOURSETYPE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCtCourseOrganizationRule());
            					}
            					set(
            						current,
            						"coursetype",
            						lv_coursetype_3_0,
            						"tesma.ovanes.UmlModel.SUBCOURSETYPE");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalUmlModel.g:2964:3: (otherlv_4= 'called' ( (lv_other_5_0= RULE_STRING ) ) )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==74) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalUmlModel.g:2965:4: otherlv_4= 'called' ( (lv_other_5_0= RULE_STRING ) )
                    {
                    otherlv_4=(Token)match(input,74,FOLLOW_10); 

                    				newLeafNode(otherlv_4, grammarAccess.getCtCourseOrganizationAccess().getCalledKeyword_4_0());
                    			
                    // InternalUmlModel.g:2969:4: ( (lv_other_5_0= RULE_STRING ) )
                    // InternalUmlModel.g:2970:5: (lv_other_5_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:2970:5: (lv_other_5_0= RULE_STRING )
                    // InternalUmlModel.g:2971:6: lv_other_5_0= RULE_STRING
                    {
                    lv_other_5_0=(Token)match(input,RULE_STRING,FOLLOW_47); 

                    						newLeafNode(lv_other_5_0, grammarAccess.getCtCourseOrganizationAccess().getOtherSTRINGTerminalRuleCall_4_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtCourseOrganizationRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"other",
                    							lv_other_5_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,20,FOLLOW_88); 

            			newLeafNode(otherlv_6, grammarAccess.getCtCourseOrganizationAccess().getLeftCurlyBracketKeyword_5());
            		
            // InternalUmlModel.g:2992:3: (otherlv_7= 'instructor' ( ( ruleFQN ) ) otherlv_9= ':' otherlv_10= 'hours' ( (lv_totalhours_11_0= RULE_INT ) ) otherlv_12= ',' otherlv_13= 'weight' ( (lv_weight_14_0= RULE_INT ) ) otherlv_15= ',' (otherlv_16= 'language' ( (lv_language_17_0= ruleLANGUAGE ) ) ) )*
            loop69:
            do {
                int alt69=2;
                int LA69_0 = input.LA(1);

                if ( (LA69_0==75) ) {
                    alt69=1;
                }


                switch (alt69) {
            	case 1 :
            	    // InternalUmlModel.g:2993:4: otherlv_7= 'instructor' ( ( ruleFQN ) ) otherlv_9= ':' otherlv_10= 'hours' ( (lv_totalhours_11_0= RULE_INT ) ) otherlv_12= ',' otherlv_13= 'weight' ( (lv_weight_14_0= RULE_INT ) ) otherlv_15= ',' (otherlv_16= 'language' ( (lv_language_17_0= ruleLANGUAGE ) ) )
            	    {
            	    otherlv_7=(Token)match(input,75,FOLLOW_4); 

            	    				newLeafNode(otherlv_7, grammarAccess.getCtCourseOrganizationAccess().getInstructorKeyword_6_0());
            	    			
            	    // InternalUmlModel.g:2997:4: ( ( ruleFQN ) )
            	    // InternalUmlModel.g:2998:5: ( ruleFQN )
            	    {
            	    // InternalUmlModel.g:2998:5: ( ruleFQN )
            	    // InternalUmlModel.g:2999:6: ruleFQN
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getCtCourseOrganizationRule());
            	    						}
            	    					

            	    						newCompositeNode(grammarAccess.getCtCourseOrganizationAccess().getRnctInstructorCtInstructorCrossReference_6_1_0());
            	    					
            	    pushFollow(FOLLOW_16);
            	    ruleFQN();

            	    state._fsp--;


            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }

            	    otherlv_9=(Token)match(input,22,FOLLOW_89); 

            	    				newLeafNode(otherlv_9, grammarAccess.getCtCourseOrganizationAccess().getColonKeyword_6_2());
            	    			
            	    otherlv_10=(Token)match(input,76,FOLLOW_6); 

            	    				newLeafNode(otherlv_10, grammarAccess.getCtCourseOrganizationAccess().getHoursKeyword_6_3());
            	    			
            	    // InternalUmlModel.g:3021:4: ( (lv_totalhours_11_0= RULE_INT ) )
            	    // InternalUmlModel.g:3022:5: (lv_totalhours_11_0= RULE_INT )
            	    {
            	    // InternalUmlModel.g:3022:5: (lv_totalhours_11_0= RULE_INT )
            	    // InternalUmlModel.g:3023:6: lv_totalhours_11_0= RULE_INT
            	    {
            	    lv_totalhours_11_0=(Token)match(input,RULE_INT,FOLLOW_11); 

            	    						newLeafNode(lv_totalhours_11_0, grammarAccess.getCtCourseOrganizationAccess().getTotalhoursINTTerminalRuleCall_6_4_0());
            	    					

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getCtCourseOrganizationRule());
            	    						}
            	    						addWithLastConsumed(
            	    							current,
            	    							"totalhours",
            	    							lv_totalhours_11_0,
            	    							"org.eclipse.xtext.common.Terminals.INT");
            	    					

            	    }


            	    }

            	    otherlv_12=(Token)match(input,16,FOLLOW_5); 

            	    				newLeafNode(otherlv_12, grammarAccess.getCtCourseOrganizationAccess().getCommaKeyword_6_5());
            	    			
            	    otherlv_13=(Token)match(input,12,FOLLOW_6); 

            	    				newLeafNode(otherlv_13, grammarAccess.getCtCourseOrganizationAccess().getWeightKeyword_6_6());
            	    			
            	    // InternalUmlModel.g:3047:4: ( (lv_weight_14_0= RULE_INT ) )
            	    // InternalUmlModel.g:3048:5: (lv_weight_14_0= RULE_INT )
            	    {
            	    // InternalUmlModel.g:3048:5: (lv_weight_14_0= RULE_INT )
            	    // InternalUmlModel.g:3049:6: lv_weight_14_0= RULE_INT
            	    {
            	    lv_weight_14_0=(Token)match(input,RULE_INT,FOLLOW_11); 

            	    						newLeafNode(lv_weight_14_0, grammarAccess.getCtCourseOrganizationAccess().getWeightINTTerminalRuleCall_6_7_0());
            	    					

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getCtCourseOrganizationRule());
            	    						}
            	    						addWithLastConsumed(
            	    							current,
            	    							"weight",
            	    							lv_weight_14_0,
            	    							"org.eclipse.xtext.common.Terminals.INT");
            	    					

            	    }


            	    }

            	    otherlv_15=(Token)match(input,16,FOLLOW_54); 

            	    				newLeafNode(otherlv_15, grammarAccess.getCtCourseOrganizationAccess().getCommaKeyword_6_8());
            	    			
            	    // InternalUmlModel.g:3069:4: (otherlv_16= 'language' ( (lv_language_17_0= ruleLANGUAGE ) ) )
            	    // InternalUmlModel.g:3070:5: otherlv_16= 'language' ( (lv_language_17_0= ruleLANGUAGE ) )
            	    {
            	    otherlv_16=(Token)match(input,50,FOLLOW_10); 

            	    					newLeafNode(otherlv_16, grammarAccess.getCtCourseOrganizationAccess().getLanguageKeyword_6_9_0());
            	    				
            	    // InternalUmlModel.g:3074:5: ( (lv_language_17_0= ruleLANGUAGE ) )
            	    // InternalUmlModel.g:3075:6: (lv_language_17_0= ruleLANGUAGE )
            	    {
            	    // InternalUmlModel.g:3075:6: (lv_language_17_0= ruleLANGUAGE )
            	    // InternalUmlModel.g:3076:7: lv_language_17_0= ruleLANGUAGE
            	    {

            	    							newCompositeNode(grammarAccess.getCtCourseOrganizationAccess().getLanguageLANGUAGEParserRuleCall_6_9_1_0());
            	    						
            	    pushFollow(FOLLOW_88);
            	    lv_language_17_0=ruleLANGUAGE();

            	    state._fsp--;


            	    							if (current==null) {
            	    								current = createModelElementForParent(grammarAccess.getCtCourseOrganizationRule());
            	    							}
            	    							add(
            	    								current,
            	    								"language",
            	    								lv_language_17_0,
            	    								"tesma.ovanes.UmlModel.LANGUAGE");
            	    							afterParserOrEnumRuleCall();
            	    						

            	    }


            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop69;
                }
            } while (true);

            otherlv_18=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_18, grammarAccess.getCtCourseOrganizationAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectCourseOrganization"


    // $ANTLR start "entryRulectPeriod"
    // InternalUmlModel.g:3103:1: entryRulectPeriod returns [EObject current=null] : iv_rulectPeriod= rulectPeriod EOF ;
    public final EObject entryRulectPeriod() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectPeriod = null;


        try {
            // InternalUmlModel.g:3103:49: (iv_rulectPeriod= rulectPeriod EOF )
            // InternalUmlModel.g:3104:2: iv_rulectPeriod= rulectPeriod EOF
            {
             newCompositeNode(grammarAccess.getCtPeriodRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectPeriod=rulectPeriod();

            state._fsp--;

             current =iv_rulectPeriod; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectPeriod"


    // $ANTLR start "rulectPeriod"
    // InternalUmlModel.g:3110:1: rulectPeriod returns [EObject current=null] : (otherlv_0= 'Period' otherlv_1= '(' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= ',' ( (lv_level_4_0= RULE_INT ) ) ) (otherlv_5= ',' ( (lv_number_6_0= RULE_INT ) ) ) otherlv_7= ')' ( (otherlv_8= 'start' ( (lv_startDate_9_0= rulectDate ) ) (otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) ) )? ) (otherlv_12= 'from' ( (lv_startTime_13_0= rulectTime ) ) (otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) ) )? )? )? otherlv_16= '{' (otherlv_17= 'tasks' ( ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* ) )? (otherlv_21= 'tests' ( ( ruleFQN ) ) (otherlv_23= ',' ( ( ruleFQN ) ) )* )? ( (lv_subPeriod_25_0= rulectPeriod ) )* otherlv_26= '}' ) ;
    public final EObject rulectPeriod() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token lv_level_4_0=null;
        Token otherlv_5=null;
        Token lv_number_6_0=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_21=null;
        Token otherlv_23=null;
        Token otherlv_26=null;
        EObject lv_startDate_9_0 = null;

        EObject lv_endDate_11_0 = null;

        EObject lv_startTime_13_0 = null;

        EObject lv_endTime_15_0 = null;

        EObject lv_subPeriod_25_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:3116:2: ( (otherlv_0= 'Period' otherlv_1= '(' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= ',' ( (lv_level_4_0= RULE_INT ) ) ) (otherlv_5= ',' ( (lv_number_6_0= RULE_INT ) ) ) otherlv_7= ')' ( (otherlv_8= 'start' ( (lv_startDate_9_0= rulectDate ) ) (otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) ) )? ) (otherlv_12= 'from' ( (lv_startTime_13_0= rulectTime ) ) (otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) ) )? )? )? otherlv_16= '{' (otherlv_17= 'tasks' ( ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* ) )? (otherlv_21= 'tests' ( ( ruleFQN ) ) (otherlv_23= ',' ( ( ruleFQN ) ) )* )? ( (lv_subPeriod_25_0= rulectPeriod ) )* otherlv_26= '}' ) )
            // InternalUmlModel.g:3117:2: (otherlv_0= 'Period' otherlv_1= '(' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= ',' ( (lv_level_4_0= RULE_INT ) ) ) (otherlv_5= ',' ( (lv_number_6_0= RULE_INT ) ) ) otherlv_7= ')' ( (otherlv_8= 'start' ( (lv_startDate_9_0= rulectDate ) ) (otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) ) )? ) (otherlv_12= 'from' ( (lv_startTime_13_0= rulectTime ) ) (otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) ) )? )? )? otherlv_16= '{' (otherlv_17= 'tasks' ( ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* ) )? (otherlv_21= 'tests' ( ( ruleFQN ) ) (otherlv_23= ',' ( ( ruleFQN ) ) )* )? ( (lv_subPeriod_25_0= rulectPeriod ) )* otherlv_26= '}' )
            {
            // InternalUmlModel.g:3117:2: (otherlv_0= 'Period' otherlv_1= '(' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= ',' ( (lv_level_4_0= RULE_INT ) ) ) (otherlv_5= ',' ( (lv_number_6_0= RULE_INT ) ) ) otherlv_7= ')' ( (otherlv_8= 'start' ( (lv_startDate_9_0= rulectDate ) ) (otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) ) )? ) (otherlv_12= 'from' ( (lv_startTime_13_0= rulectTime ) ) (otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) ) )? )? )? otherlv_16= '{' (otherlv_17= 'tasks' ( ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* ) )? (otherlv_21= 'tests' ( ( ruleFQN ) ) (otherlv_23= ',' ( ( ruleFQN ) ) )* )? ( (lv_subPeriod_25_0= rulectPeriod ) )* otherlv_26= '}' )
            // InternalUmlModel.g:3118:3: otherlv_0= 'Period' otherlv_1= '(' ( (lv_name_2_0= RULE_ID ) ) (otherlv_3= ',' ( (lv_level_4_0= RULE_INT ) ) ) (otherlv_5= ',' ( (lv_number_6_0= RULE_INT ) ) ) otherlv_7= ')' ( (otherlv_8= 'start' ( (lv_startDate_9_0= rulectDate ) ) (otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) ) )? ) (otherlv_12= 'from' ( (lv_startTime_13_0= rulectTime ) ) (otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) ) )? )? )? otherlv_16= '{' (otherlv_17= 'tasks' ( ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* ) )? (otherlv_21= 'tests' ( ( ruleFQN ) ) (otherlv_23= ',' ( ( ruleFQN ) ) )* )? ( (lv_subPeriod_25_0= rulectPeriod ) )* otherlv_26= '}'
            {
            otherlv_0=(Token)match(input,77,FOLLOW_90); 

            			newLeafNode(otherlv_0, grammarAccess.getCtPeriodAccess().getPeriodKeyword_0());
            		
            otherlv_1=(Token)match(input,78,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getCtPeriodAccess().getLeftParenthesisKeyword_1());
            		
            // InternalUmlModel.g:3126:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalUmlModel.g:3127:4: (lv_name_2_0= RULE_ID )
            {
            // InternalUmlModel.g:3127:4: (lv_name_2_0= RULE_ID )
            // InternalUmlModel.g:3128:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_11); 

            					newLeafNode(lv_name_2_0, grammarAccess.getCtPeriodAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtPeriodRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalUmlModel.g:3144:3: (otherlv_3= ',' ( (lv_level_4_0= RULE_INT ) ) )
            // InternalUmlModel.g:3145:4: otherlv_3= ',' ( (lv_level_4_0= RULE_INT ) )
            {
            otherlv_3=(Token)match(input,16,FOLLOW_6); 

            				newLeafNode(otherlv_3, grammarAccess.getCtPeriodAccess().getCommaKeyword_3_0());
            			
            // InternalUmlModel.g:3149:4: ( (lv_level_4_0= RULE_INT ) )
            // InternalUmlModel.g:3150:5: (lv_level_4_0= RULE_INT )
            {
            // InternalUmlModel.g:3150:5: (lv_level_4_0= RULE_INT )
            // InternalUmlModel.g:3151:6: lv_level_4_0= RULE_INT
            {
            lv_level_4_0=(Token)match(input,RULE_INT,FOLLOW_11); 

            						newLeafNode(lv_level_4_0, grammarAccess.getCtPeriodAccess().getLevelINTTerminalRuleCall_3_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtPeriodRule());
            						}
            						setWithLastConsumed(
            							current,
            							"level",
            							lv_level_4_0,
            							"org.eclipse.xtext.common.Terminals.INT");
            					

            }


            }


            }

            // InternalUmlModel.g:3168:3: (otherlv_5= ',' ( (lv_number_6_0= RULE_INT ) ) )
            // InternalUmlModel.g:3169:4: otherlv_5= ',' ( (lv_number_6_0= RULE_INT ) )
            {
            otherlv_5=(Token)match(input,16,FOLLOW_6); 

            				newLeafNode(otherlv_5, grammarAccess.getCtPeriodAccess().getCommaKeyword_4_0());
            			
            // InternalUmlModel.g:3173:4: ( (lv_number_6_0= RULE_INT ) )
            // InternalUmlModel.g:3174:5: (lv_number_6_0= RULE_INT )
            {
            // InternalUmlModel.g:3174:5: (lv_number_6_0= RULE_INT )
            // InternalUmlModel.g:3175:6: lv_number_6_0= RULE_INT
            {
            lv_number_6_0=(Token)match(input,RULE_INT,FOLLOW_91); 

            						newLeafNode(lv_number_6_0, grammarAccess.getCtPeriodAccess().getNumberINTTerminalRuleCall_4_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtPeriodRule());
            						}
            						setWithLastConsumed(
            							current,
            							"number",
            							lv_number_6_0,
            							"org.eclipse.xtext.common.Terminals.INT");
            					

            }


            }


            }

            otherlv_7=(Token)match(input,79,FOLLOW_92); 

            			newLeafNode(otherlv_7, grammarAccess.getCtPeriodAccess().getRightParenthesisKeyword_5());
            		
            // InternalUmlModel.g:3196:3: ( (otherlv_8= 'start' ( (lv_startDate_9_0= rulectDate ) ) (otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) ) )? ) (otherlv_12= 'from' ( (lv_startTime_13_0= rulectTime ) ) (otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) ) )? )? )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==80) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // InternalUmlModel.g:3197:4: (otherlv_8= 'start' ( (lv_startDate_9_0= rulectDate ) ) (otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) ) )? ) (otherlv_12= 'from' ( (lv_startTime_13_0= rulectTime ) ) (otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) ) )? )?
                    {
                    // InternalUmlModel.g:3197:4: (otherlv_8= 'start' ( (lv_startDate_9_0= rulectDate ) ) (otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) ) )? )
                    // InternalUmlModel.g:3198:5: otherlv_8= 'start' ( (lv_startDate_9_0= rulectDate ) ) (otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) ) )?
                    {
                    otherlv_8=(Token)match(input,80,FOLLOW_6); 

                    					newLeafNode(otherlv_8, grammarAccess.getCtPeriodAccess().getStartKeyword_6_0_0());
                    				
                    // InternalUmlModel.g:3202:5: ( (lv_startDate_9_0= rulectDate ) )
                    // InternalUmlModel.g:3203:6: (lv_startDate_9_0= rulectDate )
                    {
                    // InternalUmlModel.g:3203:6: (lv_startDate_9_0= rulectDate )
                    // InternalUmlModel.g:3204:7: lv_startDate_9_0= rulectDate
                    {

                    							newCompositeNode(grammarAccess.getCtPeriodAccess().getStartDateCtDateParserRuleCall_6_0_1_0());
                    						
                    pushFollow(FOLLOW_93);
                    lv_startDate_9_0=rulectDate();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getCtPeriodRule());
                    							}
                    							set(
                    								current,
                    								"startDate",
                    								lv_startDate_9_0,
                    								"tesma.ovanes.UmlModel.ctDate");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    // InternalUmlModel.g:3221:5: (otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) ) )?
                    int alt70=2;
                    int LA70_0 = input.LA(1);

                    if ( (LA70_0==81) ) {
                        alt70=1;
                    }
                    switch (alt70) {
                        case 1 :
                            // InternalUmlModel.g:3222:6: otherlv_10= 'end' ( (lv_endDate_11_0= rulectDate ) )
                            {
                            otherlv_10=(Token)match(input,81,FOLLOW_6); 

                            						newLeafNode(otherlv_10, grammarAccess.getCtPeriodAccess().getEndKeyword_6_0_2_0());
                            					
                            // InternalUmlModel.g:3226:6: ( (lv_endDate_11_0= rulectDate ) )
                            // InternalUmlModel.g:3227:7: (lv_endDate_11_0= rulectDate )
                            {
                            // InternalUmlModel.g:3227:7: (lv_endDate_11_0= rulectDate )
                            // InternalUmlModel.g:3228:8: lv_endDate_11_0= rulectDate
                            {

                            								newCompositeNode(grammarAccess.getCtPeriodAccess().getEndDateCtDateParserRuleCall_6_0_2_1_0());
                            							
                            pushFollow(FOLLOW_94);
                            lv_endDate_11_0=rulectDate();

                            state._fsp--;


                            								if (current==null) {
                            									current = createModelElementForParent(grammarAccess.getCtPeriodRule());
                            								}
                            								set(
                            									current,
                            									"endDate",
                            									lv_endDate_11_0,
                            									"tesma.ovanes.UmlModel.ctDate");
                            								afterParserOrEnumRuleCall();
                            							

                            }


                            }


                            }
                            break;

                    }


                    }

                    // InternalUmlModel.g:3247:4: (otherlv_12= 'from' ( (lv_startTime_13_0= rulectTime ) ) (otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) ) )? )?
                    int alt72=2;
                    int LA72_0 = input.LA(1);

                    if ( (LA72_0==82) ) {
                        alt72=1;
                    }
                    switch (alt72) {
                        case 1 :
                            // InternalUmlModel.g:3248:5: otherlv_12= 'from' ( (lv_startTime_13_0= rulectTime ) ) (otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) ) )?
                            {
                            otherlv_12=(Token)match(input,82,FOLLOW_6); 

                            					newLeafNode(otherlv_12, grammarAccess.getCtPeriodAccess().getFromKeyword_6_1_0());
                            				
                            // InternalUmlModel.g:3252:5: ( (lv_startTime_13_0= rulectTime ) )
                            // InternalUmlModel.g:3253:6: (lv_startTime_13_0= rulectTime )
                            {
                            // InternalUmlModel.g:3253:6: (lv_startTime_13_0= rulectTime )
                            // InternalUmlModel.g:3254:7: lv_startTime_13_0= rulectTime
                            {

                            							newCompositeNode(grammarAccess.getCtPeriodAccess().getStartTimeCtTimeParserRuleCall_6_1_1_0());
                            						
                            pushFollow(FOLLOW_95);
                            lv_startTime_13_0=rulectTime();

                            state._fsp--;


                            							if (current==null) {
                            								current = createModelElementForParent(grammarAccess.getCtPeriodRule());
                            							}
                            							set(
                            								current,
                            								"startTime",
                            								lv_startTime_13_0,
                            								"tesma.ovanes.UmlModel.ctTime");
                            							afterParserOrEnumRuleCall();
                            						

                            }


                            }

                            // InternalUmlModel.g:3271:5: (otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) ) )?
                            int alt71=2;
                            int LA71_0 = input.LA(1);

                            if ( (LA71_0==83) ) {
                                alt71=1;
                            }
                            switch (alt71) {
                                case 1 :
                                    // InternalUmlModel.g:3272:6: otherlv_14= 'to' ( (lv_endTime_15_0= rulectTime ) )
                                    {
                                    otherlv_14=(Token)match(input,83,FOLLOW_6); 

                                    						newLeafNode(otherlv_14, grammarAccess.getCtPeriodAccess().getToKeyword_6_1_2_0());
                                    					
                                    // InternalUmlModel.g:3276:6: ( (lv_endTime_15_0= rulectTime ) )
                                    // InternalUmlModel.g:3277:7: (lv_endTime_15_0= rulectTime )
                                    {
                                    // InternalUmlModel.g:3277:7: (lv_endTime_15_0= rulectTime )
                                    // InternalUmlModel.g:3278:8: lv_endTime_15_0= rulectTime
                                    {

                                    								newCompositeNode(grammarAccess.getCtPeriodAccess().getEndTimeCtTimeParserRuleCall_6_1_2_1_0());
                                    							
                                    pushFollow(FOLLOW_47);
                                    lv_endTime_15_0=rulectTime();

                                    state._fsp--;


                                    								if (current==null) {
                                    									current = createModelElementForParent(grammarAccess.getCtPeriodRule());
                                    								}
                                    								set(
                                    									current,
                                    									"endTime",
                                    									lv_endTime_15_0,
                                    									"tesma.ovanes.UmlModel.ctTime");
                                    								afterParserOrEnumRuleCall();
                                    							

                                    }


                                    }


                                    }
                                    break;

                            }


                            }
                            break;

                    }


                    }
                    break;

            }

            otherlv_16=(Token)match(input,20,FOLLOW_96); 

            			newLeafNode(otherlv_16, grammarAccess.getCtPeriodAccess().getLeftCurlyBracketKeyword_7());
            		
            // InternalUmlModel.g:3302:3: (otherlv_17= 'tasks' ( ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* ) )?
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==71) ) {
                alt75=1;
            }
            switch (alt75) {
                case 1 :
                    // InternalUmlModel.g:3303:4: otherlv_17= 'tasks' ( ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* )
                    {
                    otherlv_17=(Token)match(input,71,FOLLOW_4); 

                    				newLeafNode(otherlv_17, grammarAccess.getCtPeriodAccess().getTasksKeyword_8_0());
                    			
                    // InternalUmlModel.g:3307:4: ( ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* )
                    // InternalUmlModel.g:3308:5: ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )*
                    {
                    // InternalUmlModel.g:3308:5: ( ( ruleFQN ) )
                    // InternalUmlModel.g:3309:6: ( ruleFQN )
                    {
                    // InternalUmlModel.g:3309:6: ( ruleFQN )
                    // InternalUmlModel.g:3310:7: ruleFQN
                    {

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getCtPeriodRule());
                    							}
                    						

                    							newCompositeNode(grammarAccess.getCtPeriodAccess().getRnctTasksCtTaskCrossReference_8_1_0_0());
                    						
                    pushFollow(FOLLOW_97);
                    ruleFQN();

                    state._fsp--;


                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    // InternalUmlModel.g:3324:5: (otherlv_19= ',' ( ( ruleFQN ) ) )*
                    loop74:
                    do {
                        int alt74=2;
                        int LA74_0 = input.LA(1);

                        if ( (LA74_0==16) ) {
                            alt74=1;
                        }


                        switch (alt74) {
                    	case 1 :
                    	    // InternalUmlModel.g:3325:6: otherlv_19= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_19=(Token)match(input,16,FOLLOW_4); 

                    	    						newLeafNode(otherlv_19, grammarAccess.getCtPeriodAccess().getCommaKeyword_8_1_1_0());
                    	    					
                    	    // InternalUmlModel.g:3329:6: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:3330:7: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:3330:7: ( ruleFQN )
                    	    // InternalUmlModel.g:3331:8: ruleFQN
                    	    {

                    	    								if (current==null) {
                    	    									current = createModelElement(grammarAccess.getCtPeriodRule());
                    	    								}
                    	    							

                    	    								newCompositeNode(grammarAccess.getCtPeriodAccess().getRnctTasksCtTaskCrossReference_8_1_1_1_0());
                    	    							
                    	    pushFollow(FOLLOW_97);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    								afterParserOrEnumRuleCall();
                    	    							

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop74;
                        }
                    } while (true);


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:3348:3: (otherlv_21= 'tests' ( ( ruleFQN ) ) (otherlv_23= ',' ( ( ruleFQN ) ) )* )?
            int alt77=2;
            int LA77_0 = input.LA(1);

            if ( (LA77_0==84) ) {
                alt77=1;
            }
            switch (alt77) {
                case 1 :
                    // InternalUmlModel.g:3349:4: otherlv_21= 'tests' ( ( ruleFQN ) ) (otherlv_23= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_21=(Token)match(input,84,FOLLOW_4); 

                    				newLeafNode(otherlv_21, grammarAccess.getCtPeriodAccess().getTestsKeyword_9_0());
                    			
                    // InternalUmlModel.g:3353:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:3354:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:3354:5: ( ruleFQN )
                    // InternalUmlModel.g:3355:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtPeriodRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtPeriodAccess().getRnctTestCtTestCrossReference_9_1_0());
                    					
                    pushFollow(FOLLOW_98);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:3369:4: (otherlv_23= ',' ( ( ruleFQN ) ) )*
                    loop76:
                    do {
                        int alt76=2;
                        int LA76_0 = input.LA(1);

                        if ( (LA76_0==16) ) {
                            alt76=1;
                        }


                        switch (alt76) {
                    	case 1 :
                    	    // InternalUmlModel.g:3370:5: otherlv_23= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_23=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_23, grammarAccess.getCtPeriodAccess().getCommaKeyword_9_2_0());
                    	    				
                    	    // InternalUmlModel.g:3374:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:3375:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:3375:6: ( ruleFQN )
                    	    // InternalUmlModel.g:3376:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtPeriodRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtPeriodAccess().getRnctTestCtTestCrossReference_9_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_98);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop76;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:3392:3: ( (lv_subPeriod_25_0= rulectPeriod ) )*
            loop78:
            do {
                int alt78=2;
                int LA78_0 = input.LA(1);

                if ( (LA78_0==77) ) {
                    alt78=1;
                }


                switch (alt78) {
            	case 1 :
            	    // InternalUmlModel.g:3393:4: (lv_subPeriod_25_0= rulectPeriod )
            	    {
            	    // InternalUmlModel.g:3393:4: (lv_subPeriod_25_0= rulectPeriod )
            	    // InternalUmlModel.g:3394:5: lv_subPeriod_25_0= rulectPeriod
            	    {

            	    					newCompositeNode(grammarAccess.getCtPeriodAccess().getSubPeriodCtPeriodParserRuleCall_10_0());
            	    				
            	    pushFollow(FOLLOW_99);
            	    lv_subPeriod_25_0=rulectPeriod();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCtPeriodRule());
            	    					}
            	    					add(
            	    						current,
            	    						"subPeriod",
            	    						lv_subPeriod_25_0,
            	    						"tesma.ovanes.UmlModel.ctPeriod");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop78;
                }
            } while (true);

            otherlv_26=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_26, grammarAccess.getCtPeriodAccess().getRightCurlyBracketKeyword_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectPeriod"


    // $ANTLR start "entryRulectArtefact"
    // InternalUmlModel.g:3419:1: entryRulectArtefact returns [EObject current=null] : iv_rulectArtefact= rulectArtefact EOF ;
    public final EObject entryRulectArtefact() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectArtefact = null;


        try {
            // InternalUmlModel.g:3419:51: (iv_rulectArtefact= rulectArtefact EOF )
            // InternalUmlModel.g:3420:2: iv_rulectArtefact= rulectArtefact EOF
            {
             newCompositeNode(grammarAccess.getCtArtefactRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectArtefact=rulectArtefact();

            state._fsp--;

             current =iv_rulectArtefact; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectArtefact"


    // $ANTLR start "rulectArtefact"
    // InternalUmlModel.g:3426:1: rulectArtefact returns [EObject current=null] : (otherlv_0= 'Artefact' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_artefacttype_3_0= ruleARTEFACTTYPE ) ) otherlv_4= ',' ( (lv_description_5_0= RULE_STRING ) ) otherlv_6= ')' ) ;
    public final EObject rulectArtefact() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token lv_description_5_0=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_artefacttype_3_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:3432:2: ( (otherlv_0= 'Artefact' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_artefacttype_3_0= ruleARTEFACTTYPE ) ) otherlv_4= ',' ( (lv_description_5_0= RULE_STRING ) ) otherlv_6= ')' ) )
            // InternalUmlModel.g:3433:2: (otherlv_0= 'Artefact' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_artefacttype_3_0= ruleARTEFACTTYPE ) ) otherlv_4= ',' ( (lv_description_5_0= RULE_STRING ) ) otherlv_6= ')' )
            {
            // InternalUmlModel.g:3433:2: (otherlv_0= 'Artefact' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_artefacttype_3_0= ruleARTEFACTTYPE ) ) otherlv_4= ',' ( (lv_description_5_0= RULE_STRING ) ) otherlv_6= ')' )
            // InternalUmlModel.g:3434:3: otherlv_0= 'Artefact' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_artefacttype_3_0= ruleARTEFACTTYPE ) ) otherlv_4= ',' ( (lv_description_5_0= RULE_STRING ) ) otherlv_6= ')'
            {
            otherlv_0=(Token)match(input,85,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtArtefactAccess().getArtefactKeyword_0());
            		
            // InternalUmlModel.g:3438:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:3439:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:3439:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:3440:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_90); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtArtefactAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtArtefactRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,78,FOLLOW_100); 

            			newLeafNode(otherlv_2, grammarAccess.getCtArtefactAccess().getLeftParenthesisKeyword_2());
            		
            // InternalUmlModel.g:3460:3: ( (lv_artefacttype_3_0= ruleARTEFACTTYPE ) )
            // InternalUmlModel.g:3461:4: (lv_artefacttype_3_0= ruleARTEFACTTYPE )
            {
            // InternalUmlModel.g:3461:4: (lv_artefacttype_3_0= ruleARTEFACTTYPE )
            // InternalUmlModel.g:3462:5: lv_artefacttype_3_0= ruleARTEFACTTYPE
            {

            					newCompositeNode(grammarAccess.getCtArtefactAccess().getArtefacttypeARTEFACTTYPEParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_11);
            lv_artefacttype_3_0=ruleARTEFACTTYPE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCtArtefactRule());
            					}
            					set(
            						current,
            						"artefacttype",
            						lv_artefacttype_3_0,
            						"tesma.ovanes.UmlModel.ARTEFACTTYPE");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,16,FOLLOW_10); 

            			newLeafNode(otherlv_4, grammarAccess.getCtArtefactAccess().getCommaKeyword_4());
            		
            // InternalUmlModel.g:3483:3: ( (lv_description_5_0= RULE_STRING ) )
            // InternalUmlModel.g:3484:4: (lv_description_5_0= RULE_STRING )
            {
            // InternalUmlModel.g:3484:4: (lv_description_5_0= RULE_STRING )
            // InternalUmlModel.g:3485:5: lv_description_5_0= RULE_STRING
            {
            lv_description_5_0=(Token)match(input,RULE_STRING,FOLLOW_91); 

            					newLeafNode(lv_description_5_0, grammarAccess.getCtArtefactAccess().getDescriptionSTRINGTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtArtefactRule());
            					}
            					setWithLastConsumed(
            						current,
            						"description",
            						lv_description_5_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_6=(Token)match(input,79,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getCtArtefactAccess().getRightParenthesisKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectArtefact"


    // $ANTLR start "entryRulectGrades"
    // InternalUmlModel.g:3509:1: entryRulectGrades returns [EObject current=null] : iv_rulectGrades= rulectGrades EOF ;
    public final EObject entryRulectGrades() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectGrades = null;


        try {
            // InternalUmlModel.g:3509:49: (iv_rulectGrades= rulectGrades EOF )
            // InternalUmlModel.g:3510:2: iv_rulectGrades= rulectGrades EOF
            {
             newCompositeNode(grammarAccess.getCtGradesRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectGrades=rulectGrades();

            state._fsp--;

             current =iv_rulectGrades; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectGrades"


    // $ANTLR start "rulectGrades"
    // InternalUmlModel.g:3516:1: rulectGrades returns [EObject current=null] : (otherlv_0= 'Grades' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'Course' ( ( ruleFQN ) ) otherlv_5= '{' (otherlv_6= 'Test' ( ( ruleFQN ) ) otherlv_8= '{' (otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}' )* otherlv_46= '}' )* otherlv_47= '}' ) ) ;
    public final EObject rulectGrades() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token lv_weight_15_0=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token lv_categoryGrade_18_0=null;
        Token otherlv_19=null;
        Token otherlv_21=null;
        Token lv_weight_22_0=null;
        Token otherlv_23=null;
        Token otherlv_24=null;
        Token lv_categoryGrade_25_0=null;
        Token otherlv_26=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        Token otherlv_31=null;
        Token lv_weight_32_0=null;
        Token otherlv_33=null;
        Token otherlv_34=null;
        Token lv_criteriaGrade_35_0=null;
        Token otherlv_36=null;
        Token otherlv_38=null;
        Token lv_weight_39_0=null;
        Token otherlv_40=null;
        Token otherlv_41=null;
        Token lv_criteriaGrade_42_0=null;
        Token otherlv_43=null;
        Token otherlv_44=null;
        Token otherlv_45=null;
        Token otherlv_46=null;
        Token otherlv_47=null;


        	enterRule();

        try {
            // InternalUmlModel.g:3522:2: ( (otherlv_0= 'Grades' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'Course' ( ( ruleFQN ) ) otherlv_5= '{' (otherlv_6= 'Test' ( ( ruleFQN ) ) otherlv_8= '{' (otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}' )* otherlv_46= '}' )* otherlv_47= '}' ) ) )
            // InternalUmlModel.g:3523:2: (otherlv_0= 'Grades' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'Course' ( ( ruleFQN ) ) otherlv_5= '{' (otherlv_6= 'Test' ( ( ruleFQN ) ) otherlv_8= '{' (otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}' )* otherlv_46= '}' )* otherlv_47= '}' ) )
            {
            // InternalUmlModel.g:3523:2: (otherlv_0= 'Grades' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'Course' ( ( ruleFQN ) ) otherlv_5= '{' (otherlv_6= 'Test' ( ( ruleFQN ) ) otherlv_8= '{' (otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}' )* otherlv_46= '}' )* otherlv_47= '}' ) )
            // InternalUmlModel.g:3524:3: otherlv_0= 'Grades' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'Course' ( ( ruleFQN ) ) otherlv_5= '{' (otherlv_6= 'Test' ( ( ruleFQN ) ) otherlv_8= '{' (otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}' )* otherlv_46= '}' )* otherlv_47= '}' )
            {
            otherlv_0=(Token)match(input,86,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtGradesAccess().getGradesKeyword_0());
            		
            // InternalUmlModel.g:3528:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:3529:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:3529:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:3530:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_47); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtGradesAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtGradesRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,20,FOLLOW_61); 

            			newLeafNode(otherlv_2, grammarAccess.getCtGradesAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalUmlModel.g:3550:3: (otherlv_3= 'Course' ( ( ruleFQN ) ) otherlv_5= '{' (otherlv_6= 'Test' ( ( ruleFQN ) ) otherlv_8= '{' (otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}' )* otherlv_46= '}' )* otherlv_47= '}' )
            // InternalUmlModel.g:3551:4: otherlv_3= 'Course' ( ( ruleFQN ) ) otherlv_5= '{' (otherlv_6= 'Test' ( ( ruleFQN ) ) otherlv_8= '{' (otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}' )* otherlv_46= '}' )* otherlv_47= '}'
            {
            otherlv_3=(Token)match(input,54,FOLLOW_4); 

            				newLeafNode(otherlv_3, grammarAccess.getCtGradesAccess().getCourseKeyword_3_0());
            			
            // InternalUmlModel.g:3555:4: ( ( ruleFQN ) )
            // InternalUmlModel.g:3556:5: ( ruleFQN )
            {
            // InternalUmlModel.g:3556:5: ( ruleFQN )
            // InternalUmlModel.g:3557:6: ruleFQN
            {

            						if (current==null) {
            							current = createModelElement(grammarAccess.getCtGradesRule());
            						}
            					

            						newCompositeNode(grammarAccess.getCtGradesAccess().getRnctCourseCtCourseCrossReference_3_1_0());
            					
            pushFollow(FOLLOW_47);
            ruleFQN();

            state._fsp--;


            						afterParserOrEnumRuleCall();
            					

            }


            }

            otherlv_5=(Token)match(input,20,FOLLOW_32); 

            				newLeafNode(otherlv_5, grammarAccess.getCtGradesAccess().getLeftCurlyBracketKeyword_3_2());
            			
            // InternalUmlModel.g:3575:4: (otherlv_6= 'Test' ( ( ruleFQN ) ) otherlv_8= '{' (otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}' )* otherlv_46= '}' )*
            loop86:
            do {
                int alt86=2;
                int LA86_0 = input.LA(1);

                if ( (LA86_0==27) ) {
                    alt86=1;
                }


                switch (alt86) {
            	case 1 :
            	    // InternalUmlModel.g:3576:5: otherlv_6= 'Test' ( ( ruleFQN ) ) otherlv_8= '{' (otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}' )* otherlv_46= '}'
            	    {
            	    otherlv_6=(Token)match(input,27,FOLLOW_4); 

            	    					newLeafNode(otherlv_6, grammarAccess.getCtGradesAccess().getTestKeyword_3_3_0());
            	    				
            	    // InternalUmlModel.g:3580:5: ( ( ruleFQN ) )
            	    // InternalUmlModel.g:3581:6: ( ruleFQN )
            	    {
            	    // InternalUmlModel.g:3581:6: ( ruleFQN )
            	    // InternalUmlModel.g:3582:7: ruleFQN
            	    {

            	    							if (current==null) {
            	    								current = createModelElement(grammarAccess.getCtGradesRule());
            	    							}
            	    						

            	    							newCompositeNode(grammarAccess.getCtGradesAccess().getRnctTestCtTestCrossReference_3_3_1_0());
            	    						
            	    pushFollow(FOLLOW_47);
            	    ruleFQN();

            	    state._fsp--;


            	    							afterParserOrEnumRuleCall();
            	    						

            	    }


            	    }

            	    otherlv_8=(Token)match(input,20,FOLLOW_101); 

            	    					newLeafNode(otherlv_8, grammarAccess.getCtGradesAccess().getLeftCurlyBracketKeyword_3_3_2());
            	    				
            	    // InternalUmlModel.g:3600:5: (otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}' )*
            	    loop85:
            	    do {
            	        int alt85=2;
            	        int LA85_0 = input.LA(1);

            	        if ( (LA85_0==87) ) {
            	            alt85=1;
            	        }


            	        switch (alt85) {
            	    	case 1 :
            	    	    // InternalUmlModel.g:3601:6: otherlv_9= 'gradingCategory' ( ( ruleFQN ) ) otherlv_11= '{' (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )? (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )* otherlv_45= '}'
            	    	    {
            	    	    otherlv_9=(Token)match(input,87,FOLLOW_4); 

            	    	    						newLeafNode(otherlv_9, grammarAccess.getCtGradesAccess().getGradingCategoryKeyword_3_3_3_0());
            	    	    					
            	    	    // InternalUmlModel.g:3605:6: ( ( ruleFQN ) )
            	    	    // InternalUmlModel.g:3606:7: ( ruleFQN )
            	    	    {
            	    	    // InternalUmlModel.g:3606:7: ( ruleFQN )
            	    	    // InternalUmlModel.g:3607:8: ruleFQN
            	    	    {

            	    	    								if (current==null) {
            	    	    									current = createModelElement(grammarAccess.getCtGradesRule());
            	    	    								}
            	    	    							

            	    	    								newCompositeNode(grammarAccess.getCtGradesAccess().getRnctCategoryCtCategoryCrossReference_3_3_3_1_0());
            	    	    							
            	    	    pushFollow(FOLLOW_47);
            	    	    ruleFQN();

            	    	    state._fsp--;


            	    	    								afterParserOrEnumRuleCall();
            	    	    							

            	    	    }


            	    	    }

            	    	    otherlv_11=(Token)match(input,20,FOLLOW_102); 

            	    	    						newLeafNode(otherlv_11, grammarAccess.getCtGradesAccess().getLeftCurlyBracketKeyword_3_3_3_2());
            	    	    					
            	    	    // InternalUmlModel.g:3625:6: (otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )* )?
            	    	    int alt80=2;
            	    	    int LA80_0 = input.LA(1);

            	    	    if ( (LA80_0==88) ) {
            	    	        alt80=1;
            	    	    }
            	    	    switch (alt80) {
            	    	        case 1 :
            	    	            // InternalUmlModel.g:3626:7: otherlv_12= 'grades' ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) ) (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )*
            	    	            {
            	    	            otherlv_12=(Token)match(input,88,FOLLOW_4); 

            	    	            							newLeafNode(otherlv_12, grammarAccess.getCtGradesAccess().getGradesKeyword_3_3_3_3_0());
            	    	            						
            	    	            // InternalUmlModel.g:3630:7: ( ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) ) )
            	    	            // InternalUmlModel.g:3631:8: ( ( ruleFQN ) ) (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' ) otherlv_17= ':' ( (lv_categoryGrade_18_0= RULE_INT ) )
            	    	            {
            	    	            // InternalUmlModel.g:3631:8: ( ( ruleFQN ) )
            	    	            // InternalUmlModel.g:3632:9: ( ruleFQN )
            	    	            {
            	    	            // InternalUmlModel.g:3632:9: ( ruleFQN )
            	    	            // InternalUmlModel.g:3633:10: ruleFQN
            	    	            {

            	    	            										if (current==null) {
            	    	            											current = createModelElement(grammarAccess.getCtGradesRule());
            	    	            										}
            	    	            									

            	    	            										newCompositeNode(grammarAccess.getCtGradesAccess().getRnctCatInsCtInstructorCrossReference_3_3_3_3_1_0_0());
            	    	            									
            	    	            pushFollow(FOLLOW_90);
            	    	            ruleFQN();

            	    	            state._fsp--;


            	    	            										afterParserOrEnumRuleCall();
            	    	            									

            	    	            }


            	    	            }

            	    	            // InternalUmlModel.g:3647:8: (otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')' )
            	    	            // InternalUmlModel.g:3648:9: otherlv_14= '(' ( (lv_weight_15_0= RULE_INT ) ) otherlv_16= ')'
            	    	            {
            	    	            otherlv_14=(Token)match(input,78,FOLLOW_6); 

            	    	            									newLeafNode(otherlv_14, grammarAccess.getCtGradesAccess().getLeftParenthesisKeyword_3_3_3_3_1_1_0());
            	    	            								
            	    	            // InternalUmlModel.g:3652:9: ( (lv_weight_15_0= RULE_INT ) )
            	    	            // InternalUmlModel.g:3653:10: (lv_weight_15_0= RULE_INT )
            	    	            {
            	    	            // InternalUmlModel.g:3653:10: (lv_weight_15_0= RULE_INT )
            	    	            // InternalUmlModel.g:3654:11: lv_weight_15_0= RULE_INT
            	    	            {
            	    	            lv_weight_15_0=(Token)match(input,RULE_INT,FOLLOW_91); 

            	    	            											newLeafNode(lv_weight_15_0, grammarAccess.getCtGradesAccess().getWeightINTTerminalRuleCall_3_3_3_3_1_1_1_0());
            	    	            										

            	    	            											if (current==null) {
            	    	            												current = createModelElement(grammarAccess.getCtGradesRule());
            	    	            											}
            	    	            											addWithLastConsumed(
            	    	            												current,
            	    	            												"weight",
            	    	            												lv_weight_15_0,
            	    	            												"org.eclipse.xtext.common.Terminals.INT");
            	    	            										

            	    	            }


            	    	            }

            	    	            otherlv_16=(Token)match(input,79,FOLLOW_16); 

            	    	            									newLeafNode(otherlv_16, grammarAccess.getCtGradesAccess().getRightParenthesisKeyword_3_3_3_3_1_1_2());
            	    	            								

            	    	            }

            	    	            otherlv_17=(Token)match(input,22,FOLLOW_6); 

            	    	            								newLeafNode(otherlv_17, grammarAccess.getCtGradesAccess().getColonKeyword_3_3_3_3_1_2());
            	    	            							
            	    	            // InternalUmlModel.g:3679:8: ( (lv_categoryGrade_18_0= RULE_INT ) )
            	    	            // InternalUmlModel.g:3680:9: (lv_categoryGrade_18_0= RULE_INT )
            	    	            {
            	    	            // InternalUmlModel.g:3680:9: (lv_categoryGrade_18_0= RULE_INT )
            	    	            // InternalUmlModel.g:3681:10: lv_categoryGrade_18_0= RULE_INT
            	    	            {
            	    	            lv_categoryGrade_18_0=(Token)match(input,RULE_INT,FOLLOW_103); 

            	    	            										newLeafNode(lv_categoryGrade_18_0, grammarAccess.getCtGradesAccess().getCategoryGradeINTTerminalRuleCall_3_3_3_3_1_3_0());
            	    	            									

            	    	            										if (current==null) {
            	    	            											current = createModelElement(grammarAccess.getCtGradesRule());
            	    	            										}
            	    	            										addWithLastConsumed(
            	    	            											current,
            	    	            											"categoryGrade",
            	    	            											lv_categoryGrade_18_0,
            	    	            											"org.eclipse.xtext.common.Terminals.INT");
            	    	            									

            	    	            }


            	    	            }


            	    	            }

            	    	            // InternalUmlModel.g:3698:7: (otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) ) )*
            	    	            loop79:
            	    	            do {
            	    	                int alt79=2;
            	    	                int LA79_0 = input.LA(1);

            	    	                if ( (LA79_0==16) ) {
            	    	                    alt79=1;
            	    	                }


            	    	                switch (alt79) {
            	    	            	case 1 :
            	    	            	    // InternalUmlModel.g:3699:8: otherlv_19= ',' ( ( ruleFQN ) ) (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' ) otherlv_24= ',' ( (lv_categoryGrade_25_0= RULE_INT ) )
            	    	            	    {
            	    	            	    otherlv_19=(Token)match(input,16,FOLLOW_4); 

            	    	            	    								newLeafNode(otherlv_19, grammarAccess.getCtGradesAccess().getCommaKeyword_3_3_3_3_2_0());
            	    	            	    							
            	    	            	    // InternalUmlModel.g:3703:8: ( ( ruleFQN ) )
            	    	            	    // InternalUmlModel.g:3704:9: ( ruleFQN )
            	    	            	    {
            	    	            	    // InternalUmlModel.g:3704:9: ( ruleFQN )
            	    	            	    // InternalUmlModel.g:3705:10: ruleFQN
            	    	            	    {

            	    	            	    										if (current==null) {
            	    	            	    											current = createModelElement(grammarAccess.getCtGradesRule());
            	    	            	    										}
            	    	            	    									

            	    	            	    										newCompositeNode(grammarAccess.getCtGradesAccess().getRnctCatInsCtInstructorCrossReference_3_3_3_3_2_1_0());
            	    	            	    									
            	    	            	    pushFollow(FOLLOW_90);
            	    	            	    ruleFQN();

            	    	            	    state._fsp--;


            	    	            	    										afterParserOrEnumRuleCall();
            	    	            	    									

            	    	            	    }


            	    	            	    }

            	    	            	    // InternalUmlModel.g:3719:8: (otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')' )
            	    	            	    // InternalUmlModel.g:3720:9: otherlv_21= '(' ( (lv_weight_22_0= RULE_INT ) ) otherlv_23= ')'
            	    	            	    {
            	    	            	    otherlv_21=(Token)match(input,78,FOLLOW_6); 

            	    	            	    									newLeafNode(otherlv_21, grammarAccess.getCtGradesAccess().getLeftParenthesisKeyword_3_3_3_3_2_2_0());
            	    	            	    								
            	    	            	    // InternalUmlModel.g:3724:9: ( (lv_weight_22_0= RULE_INT ) )
            	    	            	    // InternalUmlModel.g:3725:10: (lv_weight_22_0= RULE_INT )
            	    	            	    {
            	    	            	    // InternalUmlModel.g:3725:10: (lv_weight_22_0= RULE_INT )
            	    	            	    // InternalUmlModel.g:3726:11: lv_weight_22_0= RULE_INT
            	    	            	    {
            	    	            	    lv_weight_22_0=(Token)match(input,RULE_INT,FOLLOW_91); 

            	    	            	    											newLeafNode(lv_weight_22_0, grammarAccess.getCtGradesAccess().getWeightINTTerminalRuleCall_3_3_3_3_2_2_1_0());
            	    	            	    										

            	    	            	    											if (current==null) {
            	    	            	    												current = createModelElement(grammarAccess.getCtGradesRule());
            	    	            	    											}
            	    	            	    											addWithLastConsumed(
            	    	            	    												current,
            	    	            	    												"weight",
            	    	            	    												lv_weight_22_0,
            	    	            	    												"org.eclipse.xtext.common.Terminals.INT");
            	    	            	    										

            	    	            	    }


            	    	            	    }

            	    	            	    otherlv_23=(Token)match(input,79,FOLLOW_11); 

            	    	            	    									newLeafNode(otherlv_23, grammarAccess.getCtGradesAccess().getRightParenthesisKeyword_3_3_3_3_2_2_2());
            	    	            	    								

            	    	            	    }

            	    	            	    otherlv_24=(Token)match(input,16,FOLLOW_6); 

            	    	            	    								newLeafNode(otherlv_24, grammarAccess.getCtGradesAccess().getCommaKeyword_3_3_3_3_2_3());
            	    	            	    							
            	    	            	    // InternalUmlModel.g:3751:8: ( (lv_categoryGrade_25_0= RULE_INT ) )
            	    	            	    // InternalUmlModel.g:3752:9: (lv_categoryGrade_25_0= RULE_INT )
            	    	            	    {
            	    	            	    // InternalUmlModel.g:3752:9: (lv_categoryGrade_25_0= RULE_INT )
            	    	            	    // InternalUmlModel.g:3753:10: lv_categoryGrade_25_0= RULE_INT
            	    	            	    {
            	    	            	    lv_categoryGrade_25_0=(Token)match(input,RULE_INT,FOLLOW_103); 

            	    	            	    										newLeafNode(lv_categoryGrade_25_0, grammarAccess.getCtGradesAccess().getCategoryGradeINTTerminalRuleCall_3_3_3_3_2_4_0());
            	    	            	    									

            	    	            	    										if (current==null) {
            	    	            	    											current = createModelElement(grammarAccess.getCtGradesRule());
            	    	            	    										}
            	    	            	    										addWithLastConsumed(
            	    	            	    											current,
            	    	            	    											"categoryGrade",
            	    	            	    											lv_categoryGrade_25_0,
            	    	            	    											"org.eclipse.xtext.common.Terminals.INT");
            	    	            	    									

            	    	            	    }


            	    	            	    }


            	    	            	    }
            	    	            	    break;

            	    	            	default :
            	    	            	    break loop79;
            	    	                }
            	    	            } while (true);


            	    	            }
            	    	            break;

            	    	    }

            	    	    // InternalUmlModel.g:3771:6: (otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}' )*
            	    	    loop84:
            	    	    do {
            	    	        int alt84=2;
            	    	        int LA84_0 = input.LA(1);

            	    	        if ( (LA84_0==89) ) {
            	    	            alt84=1;
            	    	        }


            	    	        switch (alt84) {
            	    	    	case 1 :
            	    	    	    // InternalUmlModel.g:3772:7: otherlv_26= 'gradingCriteria' ( ( ruleFQN ) ) otherlv_28= '{' (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )* otherlv_44= '}'
            	    	    	    {
            	    	    	    otherlv_26=(Token)match(input,89,FOLLOW_4); 

            	    	    	    							newLeafNode(otherlv_26, grammarAccess.getCtGradesAccess().getGradingCriteriaKeyword_3_3_3_4_0());
            	    	    	    						
            	    	    	    // InternalUmlModel.g:3776:7: ( ( ruleFQN ) )
            	    	    	    // InternalUmlModel.g:3777:8: ( ruleFQN )
            	    	    	    {
            	    	    	    // InternalUmlModel.g:3777:8: ( ruleFQN )
            	    	    	    // InternalUmlModel.g:3778:9: ruleFQN
            	    	    	    {

            	    	    	    									if (current==null) {
            	    	    	    										current = createModelElement(grammarAccess.getCtGradesRule());
            	    	    	    									}
            	    	    	    								

            	    	    	    									newCompositeNode(grammarAccess.getCtGradesAccess().getRnctCriteriaCtCriteriaCrossReference_3_3_3_4_1_0());
            	    	    	    								
            	    	    	    pushFollow(FOLLOW_47);
            	    	    	    ruleFQN();

            	    	    	    state._fsp--;


            	    	    	    									afterParserOrEnumRuleCall();
            	    	    	    								

            	    	    	    }


            	    	    	    }

            	    	    	    otherlv_28=(Token)match(input,20,FOLLOW_104); 

            	    	    	    							newLeafNode(otherlv_28, grammarAccess.getCtGradesAccess().getLeftCurlyBracketKeyword_3_3_3_4_2());
            	    	    	    						
            	    	    	    // InternalUmlModel.g:3796:7: (otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}' )*
            	    	    	    loop83:
            	    	    	    do {
            	    	    	        int alt83=2;
            	    	    	        int LA83_0 = input.LA(1);

            	    	    	        if ( (LA83_0==88) ) {
            	    	    	            alt83=1;
            	    	    	        }


            	    	    	        switch (alt83) {
            	    	    	    	case 1 :
            	    	    	    	    // InternalUmlModel.g:3797:8: otherlv_29= 'grades' ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )? otherlv_43= '}'
            	    	    	    	    {
            	    	    	    	    otherlv_29=(Token)match(input,88,FOLLOW_105); 

            	    	    	    	    								newLeafNode(otherlv_29, grammarAccess.getCtGradesAccess().getGradesKeyword_3_3_3_4_3_0());
            	    	    	    	    							
            	    	    	    	    // InternalUmlModel.g:3801:8: ( ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )* )?
            	    	    	    	    int alt82=2;
            	    	    	    	    int LA82_0 = input.LA(1);

            	    	    	    	    if ( (LA82_0==RULE_ID) ) {
            	    	    	    	        alt82=1;
            	    	    	    	    }
            	    	    	    	    switch (alt82) {
            	    	    	    	        case 1 :
            	    	    	    	            // InternalUmlModel.g:3802:9: ( ( ruleFQN ) ) (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' ) otherlv_34= ':' ( (lv_criteriaGrade_35_0= RULE_INT ) ) (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )*
            	    	    	    	            {
            	    	    	    	            // InternalUmlModel.g:3802:9: ( ( ruleFQN ) )
            	    	    	    	            // InternalUmlModel.g:3803:10: ( ruleFQN )
            	    	    	    	            {
            	    	    	    	            // InternalUmlModel.g:3803:10: ( ruleFQN )
            	    	    	    	            // InternalUmlModel.g:3804:11: ruleFQN
            	    	    	    	            {

            	    	    	    	            											if (current==null) {
            	    	    	    	            												current = createModelElement(grammarAccess.getCtGradesRule());
            	    	    	    	            											}
            	    	    	    	            										

            	    	    	    	            											newCompositeNode(grammarAccess.getCtGradesAccess().getRnctCritInsCtInstructorCrossReference_3_3_3_4_3_1_0_0());
            	    	    	    	            										
            	    	    	    	            pushFollow(FOLLOW_90);
            	    	    	    	            ruleFQN();

            	    	    	    	            state._fsp--;


            	    	    	    	            											afterParserOrEnumRuleCall();
            	    	    	    	            										

            	    	    	    	            }


            	    	    	    	            }

            	    	    	    	            // InternalUmlModel.g:3818:9: (otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')' )
            	    	    	    	            // InternalUmlModel.g:3819:10: otherlv_31= '(' ( (lv_weight_32_0= RULE_INT ) ) otherlv_33= ')'
            	    	    	    	            {
            	    	    	    	            otherlv_31=(Token)match(input,78,FOLLOW_6); 

            	    	    	    	            										newLeafNode(otherlv_31, grammarAccess.getCtGradesAccess().getLeftParenthesisKeyword_3_3_3_4_3_1_1_0());
            	    	    	    	            									
            	    	    	    	            // InternalUmlModel.g:3823:10: ( (lv_weight_32_0= RULE_INT ) )
            	    	    	    	            // InternalUmlModel.g:3824:11: (lv_weight_32_0= RULE_INT )
            	    	    	    	            {
            	    	    	    	            // InternalUmlModel.g:3824:11: (lv_weight_32_0= RULE_INT )
            	    	    	    	            // InternalUmlModel.g:3825:12: lv_weight_32_0= RULE_INT
            	    	    	    	            {
            	    	    	    	            lv_weight_32_0=(Token)match(input,RULE_INT,FOLLOW_91); 

            	    	    	    	            												newLeafNode(lv_weight_32_0, grammarAccess.getCtGradesAccess().getWeightINTTerminalRuleCall_3_3_3_4_3_1_1_1_0());
            	    	    	    	            											

            	    	    	    	            												if (current==null) {
            	    	    	    	            													current = createModelElement(grammarAccess.getCtGradesRule());
            	    	    	    	            												}
            	    	    	    	            												addWithLastConsumed(
            	    	    	    	            													current,
            	    	    	    	            													"weight",
            	    	    	    	            													lv_weight_32_0,
            	    	    	    	            													"org.eclipse.xtext.common.Terminals.INT");
            	    	    	    	            											

            	    	    	    	            }


            	    	    	    	            }

            	    	    	    	            otherlv_33=(Token)match(input,79,FOLLOW_16); 

            	    	    	    	            										newLeafNode(otherlv_33, grammarAccess.getCtGradesAccess().getRightParenthesisKeyword_3_3_3_4_3_1_1_2());
            	    	    	    	            									

            	    	    	    	            }

            	    	    	    	            otherlv_34=(Token)match(input,22,FOLLOW_6); 

            	    	    	    	            									newLeafNode(otherlv_34, grammarAccess.getCtGradesAccess().getColonKeyword_3_3_3_4_3_1_2());
            	    	    	    	            								
            	    	    	    	            // InternalUmlModel.g:3850:9: ( (lv_criteriaGrade_35_0= RULE_INT ) )
            	    	    	    	            // InternalUmlModel.g:3851:10: (lv_criteriaGrade_35_0= RULE_INT )
            	    	    	    	            {
            	    	    	    	            // InternalUmlModel.g:3851:10: (lv_criteriaGrade_35_0= RULE_INT )
            	    	    	    	            // InternalUmlModel.g:3852:11: lv_criteriaGrade_35_0= RULE_INT
            	    	    	    	            {
            	    	    	    	            lv_criteriaGrade_35_0=(Token)match(input,RULE_INT,FOLLOW_15); 

            	    	    	    	            											newLeafNode(lv_criteriaGrade_35_0, grammarAccess.getCtGradesAccess().getCriteriaGradeINTTerminalRuleCall_3_3_3_4_3_1_3_0());
            	    	    	    	            										

            	    	    	    	            											if (current==null) {
            	    	    	    	            												current = createModelElement(grammarAccess.getCtGradesRule());
            	    	    	    	            											}
            	    	    	    	            											addWithLastConsumed(
            	    	    	    	            												current,
            	    	    	    	            												"criteriaGrade",
            	    	    	    	            												lv_criteriaGrade_35_0,
            	    	    	    	            												"org.eclipse.xtext.common.Terminals.INT");
            	    	    	    	            										

            	    	    	    	            }


            	    	    	    	            }

            	    	    	    	            // InternalUmlModel.g:3868:9: (otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) ) )*
            	    	    	    	            loop81:
            	    	    	    	            do {
            	    	    	    	                int alt81=2;
            	    	    	    	                int LA81_0 = input.LA(1);

            	    	    	    	                if ( (LA81_0==16) ) {
            	    	    	    	                    alt81=1;
            	    	    	    	                }


            	    	    	    	                switch (alt81) {
            	    	    	    	            	case 1 :
            	    	    	    	            	    // InternalUmlModel.g:3869:10: otherlv_36= ',' ( ( ruleFQN ) ) (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' ) otherlv_41= ':' ( (lv_criteriaGrade_42_0= RULE_INT ) )
            	    	    	    	            	    {
            	    	    	    	            	    otherlv_36=(Token)match(input,16,FOLLOW_4); 

            	    	    	    	            	    										newLeafNode(otherlv_36, grammarAccess.getCtGradesAccess().getCommaKeyword_3_3_3_4_3_1_4_0());
            	    	    	    	            	    									
            	    	    	    	            	    // InternalUmlModel.g:3873:10: ( ( ruleFQN ) )
            	    	    	    	            	    // InternalUmlModel.g:3874:11: ( ruleFQN )
            	    	    	    	            	    {
            	    	    	    	            	    // InternalUmlModel.g:3874:11: ( ruleFQN )
            	    	    	    	            	    // InternalUmlModel.g:3875:12: ruleFQN
            	    	    	    	            	    {

            	    	    	    	            	    												if (current==null) {
            	    	    	    	            	    													current = createModelElement(grammarAccess.getCtGradesRule());
            	    	    	    	            	    												}
            	    	    	    	            	    											

            	    	    	    	            	    												newCompositeNode(grammarAccess.getCtGradesAccess().getRnctCritInsCtInstructorCrossReference_3_3_3_4_3_1_4_1_0());
            	    	    	    	            	    											
            	    	    	    	            	    pushFollow(FOLLOW_90);
            	    	    	    	            	    ruleFQN();

            	    	    	    	            	    state._fsp--;


            	    	    	    	            	    												afterParserOrEnumRuleCall();
            	    	    	    	            	    											

            	    	    	    	            	    }


            	    	    	    	            	    }

            	    	    	    	            	    // InternalUmlModel.g:3889:10: (otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')' )
            	    	    	    	            	    // InternalUmlModel.g:3890:11: otherlv_38= '(' ( (lv_weight_39_0= RULE_INT ) ) otherlv_40= ')'
            	    	    	    	            	    {
            	    	    	    	            	    otherlv_38=(Token)match(input,78,FOLLOW_6); 

            	    	    	    	            	    											newLeafNode(otherlv_38, grammarAccess.getCtGradesAccess().getLeftParenthesisKeyword_3_3_3_4_3_1_4_2_0());
            	    	    	    	            	    										
            	    	    	    	            	    // InternalUmlModel.g:3894:11: ( (lv_weight_39_0= RULE_INT ) )
            	    	    	    	            	    // InternalUmlModel.g:3895:12: (lv_weight_39_0= RULE_INT )
            	    	    	    	            	    {
            	    	    	    	            	    // InternalUmlModel.g:3895:12: (lv_weight_39_0= RULE_INT )
            	    	    	    	            	    // InternalUmlModel.g:3896:13: lv_weight_39_0= RULE_INT
            	    	    	    	            	    {
            	    	    	    	            	    lv_weight_39_0=(Token)match(input,RULE_INT,FOLLOW_91); 

            	    	    	    	            	    													newLeafNode(lv_weight_39_0, grammarAccess.getCtGradesAccess().getWeightINTTerminalRuleCall_3_3_3_4_3_1_4_2_1_0());
            	    	    	    	            	    												

            	    	    	    	            	    													if (current==null) {
            	    	    	    	            	    														current = createModelElement(grammarAccess.getCtGradesRule());
            	    	    	    	            	    													}
            	    	    	    	            	    													addWithLastConsumed(
            	    	    	    	            	    														current,
            	    	    	    	            	    														"weight",
            	    	    	    	            	    														lv_weight_39_0,
            	    	    	    	            	    														"org.eclipse.xtext.common.Terminals.INT");
            	    	    	    	            	    												

            	    	    	    	            	    }


            	    	    	    	            	    }

            	    	    	    	            	    otherlv_40=(Token)match(input,79,FOLLOW_16); 

            	    	    	    	            	    											newLeafNode(otherlv_40, grammarAccess.getCtGradesAccess().getRightParenthesisKeyword_3_3_3_4_3_1_4_2_2());
            	    	    	    	            	    										

            	    	    	    	            	    }

            	    	    	    	            	    otherlv_41=(Token)match(input,22,FOLLOW_6); 

            	    	    	    	            	    										newLeafNode(otherlv_41, grammarAccess.getCtGradesAccess().getColonKeyword_3_3_3_4_3_1_4_3());
            	    	    	    	            	    									
            	    	    	    	            	    // InternalUmlModel.g:3921:10: ( (lv_criteriaGrade_42_0= RULE_INT ) )
            	    	    	    	            	    // InternalUmlModel.g:3922:11: (lv_criteriaGrade_42_0= RULE_INT )
            	    	    	    	            	    {
            	    	    	    	            	    // InternalUmlModel.g:3922:11: (lv_criteriaGrade_42_0= RULE_INT )
            	    	    	    	            	    // InternalUmlModel.g:3923:12: lv_criteriaGrade_42_0= RULE_INT
            	    	    	    	            	    {
            	    	    	    	            	    lv_criteriaGrade_42_0=(Token)match(input,RULE_INT,FOLLOW_15); 

            	    	    	    	            	    												newLeafNode(lv_criteriaGrade_42_0, grammarAccess.getCtGradesAccess().getCriteriaGradeINTTerminalRuleCall_3_3_3_4_3_1_4_4_0());
            	    	    	    	            	    											

            	    	    	    	            	    												if (current==null) {
            	    	    	    	            	    													current = createModelElement(grammarAccess.getCtGradesRule());
            	    	    	    	            	    												}
            	    	    	    	            	    												addWithLastConsumed(
            	    	    	    	            	    													current,
            	    	    	    	            	    													"criteriaGrade",
            	    	    	    	            	    													lv_criteriaGrade_42_0,
            	    	    	    	            	    													"org.eclipse.xtext.common.Terminals.INT");
            	    	    	    	            	    											

            	    	    	    	            	    }


            	    	    	    	            	    }


            	    	    	    	            	    }
            	    	    	    	            	    break;

            	    	    	    	            	default :
            	    	    	    	            	    break loop81;
            	    	    	    	                }
            	    	    	    	            } while (true);


            	    	    	    	            }
            	    	    	    	            break;

            	    	    	    	    }

            	    	    	    	    otherlv_43=(Token)match(input,21,FOLLOW_104); 

            	    	    	    	    								newLeafNode(otherlv_43, grammarAccess.getCtGradesAccess().getRightCurlyBracketKeyword_3_3_3_4_3_2());
            	    	    	    	    							

            	    	    	    	    }
            	    	    	    	    break;

            	    	    	    	default :
            	    	    	    	    break loop83;
            	    	    	        }
            	    	    	    } while (true);

            	    	    	    otherlv_44=(Token)match(input,21,FOLLOW_106); 

            	    	    	    							newLeafNode(otherlv_44, grammarAccess.getCtGradesAccess().getRightCurlyBracketKeyword_3_3_3_4_4());
            	    	    	    						

            	    	    	    }
            	    	    	    break;

            	    	    	default :
            	    	    	    break loop84;
            	    	        }
            	    	    } while (true);

            	    	    otherlv_45=(Token)match(input,21,FOLLOW_101); 

            	    	    						newLeafNode(otherlv_45, grammarAccess.getCtGradesAccess().getRightCurlyBracketKeyword_3_3_3_5());
            	    	    					

            	    	    }
            	    	    break;

            	    	default :
            	    	    break loop85;
            	        }
            	    } while (true);

            	    otherlv_46=(Token)match(input,21,FOLLOW_32); 

            	    					newLeafNode(otherlv_46, grammarAccess.getCtGradesAccess().getRightCurlyBracketKeyword_3_3_4());
            	    				

            	    }
            	    break;

            	default :
            	    break loop86;
                }
            } while (true);

            otherlv_47=(Token)match(input,21,FOLLOW_2); 

            				newLeafNode(otherlv_47, grammarAccess.getCtGradesAccess().getRightCurlyBracketKeyword_3_4());
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectGrades"


    // $ANTLR start "entryRulectActor"
    // InternalUmlModel.g:3970:1: entryRulectActor returns [EObject current=null] : iv_rulectActor= rulectActor EOF ;
    public final EObject entryRulectActor() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectActor = null;


        try {
            // InternalUmlModel.g:3970:48: (iv_rulectActor= rulectActor EOF )
            // InternalUmlModel.g:3971:2: iv_rulectActor= rulectActor EOF
            {
             newCompositeNode(grammarAccess.getCtActorRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectActor=rulectActor();

            state._fsp--;

             current =iv_rulectActor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectActor"


    // $ANTLR start "rulectActor"
    // InternalUmlModel.g:3977:1: rulectActor returns [EObject current=null] : ( ( (lv_val_0_1= rulectInstructor | lv_val_0_2= rulectBoard | lv_val_0_3= rulectGroup | lv_val_0_4= rulectStudent | lv_val_0_5= rulectPromotion ) ) ) ;
    public final EObject rulectActor() throws RecognitionException {
        EObject current = null;

        EObject lv_val_0_1 = null;

        EObject lv_val_0_2 = null;

        EObject lv_val_0_3 = null;

        EObject lv_val_0_4 = null;

        EObject lv_val_0_5 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:3983:2: ( ( ( (lv_val_0_1= rulectInstructor | lv_val_0_2= rulectBoard | lv_val_0_3= rulectGroup | lv_val_0_4= rulectStudent | lv_val_0_5= rulectPromotion ) ) ) )
            // InternalUmlModel.g:3984:2: ( ( (lv_val_0_1= rulectInstructor | lv_val_0_2= rulectBoard | lv_val_0_3= rulectGroup | lv_val_0_4= rulectStudent | lv_val_0_5= rulectPromotion ) ) )
            {
            // InternalUmlModel.g:3984:2: ( ( (lv_val_0_1= rulectInstructor | lv_val_0_2= rulectBoard | lv_val_0_3= rulectGroup | lv_val_0_4= rulectStudent | lv_val_0_5= rulectPromotion ) ) )
            // InternalUmlModel.g:3985:3: ( (lv_val_0_1= rulectInstructor | lv_val_0_2= rulectBoard | lv_val_0_3= rulectGroup | lv_val_0_4= rulectStudent | lv_val_0_5= rulectPromotion ) )
            {
            // InternalUmlModel.g:3985:3: ( (lv_val_0_1= rulectInstructor | lv_val_0_2= rulectBoard | lv_val_0_3= rulectGroup | lv_val_0_4= rulectStudent | lv_val_0_5= rulectPromotion ) )
            // InternalUmlModel.g:3986:4: (lv_val_0_1= rulectInstructor | lv_val_0_2= rulectBoard | lv_val_0_3= rulectGroup | lv_val_0_4= rulectStudent | lv_val_0_5= rulectPromotion )
            {
            // InternalUmlModel.g:3986:4: (lv_val_0_1= rulectInstructor | lv_val_0_2= rulectBoard | lv_val_0_3= rulectGroup | lv_val_0_4= rulectStudent | lv_val_0_5= rulectPromotion )
            int alt87=5;
            switch ( input.LA(1) ) {
            case 95:
                {
                alt87=1;
                }
                break;
            case 90:
                {
                alt87=2;
                }
                break;
            case 94:
                {
                alt87=3;
                }
                break;
            case 98:
                {
                alt87=4;
                }
                break;
            case 97:
                {
                alt87=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 87, 0, input);

                throw nvae;
            }

            switch (alt87) {
                case 1 :
                    // InternalUmlModel.g:3987:5: lv_val_0_1= rulectInstructor
                    {

                    					newCompositeNode(grammarAccess.getCtActorAccess().getValCtInstructorParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_val_0_1=rulectInstructor();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtActorRule());
                    					}
                    					set(
                    						current,
                    						"val",
                    						lv_val_0_1,
                    						"tesma.ovanes.UmlModel.ctInstructor");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 2 :
                    // InternalUmlModel.g:4003:5: lv_val_0_2= rulectBoard
                    {

                    					newCompositeNode(grammarAccess.getCtActorAccess().getValCtBoardParserRuleCall_0_1());
                    				
                    pushFollow(FOLLOW_2);
                    lv_val_0_2=rulectBoard();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtActorRule());
                    					}
                    					set(
                    						current,
                    						"val",
                    						lv_val_0_2,
                    						"tesma.ovanes.UmlModel.ctBoard");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 3 :
                    // InternalUmlModel.g:4019:5: lv_val_0_3= rulectGroup
                    {

                    					newCompositeNode(grammarAccess.getCtActorAccess().getValCtGroupParserRuleCall_0_2());
                    				
                    pushFollow(FOLLOW_2);
                    lv_val_0_3=rulectGroup();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtActorRule());
                    					}
                    					set(
                    						current,
                    						"val",
                    						lv_val_0_3,
                    						"tesma.ovanes.UmlModel.ctGroup");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 4 :
                    // InternalUmlModel.g:4035:5: lv_val_0_4= rulectStudent
                    {

                    					newCompositeNode(grammarAccess.getCtActorAccess().getValCtStudentParserRuleCall_0_3());
                    				
                    pushFollow(FOLLOW_2);
                    lv_val_0_4=rulectStudent();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtActorRule());
                    					}
                    					set(
                    						current,
                    						"val",
                    						lv_val_0_4,
                    						"tesma.ovanes.UmlModel.ctStudent");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 5 :
                    // InternalUmlModel.g:4051:5: lv_val_0_5= rulectPromotion
                    {

                    					newCompositeNode(grammarAccess.getCtActorAccess().getValCtPromotionParserRuleCall_0_4());
                    				
                    pushFollow(FOLLOW_2);
                    lv_val_0_5=rulectPromotion();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtActorRule());
                    					}
                    					set(
                    						current,
                    						"val",
                    						lv_val_0_5,
                    						"tesma.ovanes.UmlModel.ctPromotion");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectActor"


    // $ANTLR start "entryRulectBoard"
    // InternalUmlModel.g:4072:1: entryRulectBoard returns [EObject current=null] : iv_rulectBoard= rulectBoard EOF ;
    public final EObject entryRulectBoard() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectBoard = null;


        try {
            // InternalUmlModel.g:4072:48: (iv_rulectBoard= rulectBoard EOF )
            // InternalUmlModel.g:4073:2: iv_rulectBoard= rulectBoard EOF
            {
             newCompositeNode(grammarAccess.getCtBoardRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectBoard=rulectBoard();

            state._fsp--;

             current =iv_rulectBoard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectBoard"


    // $ANTLR start "rulectBoard"
    // InternalUmlModel.g:4079:1: rulectBoard returns [EObject current=null] : (otherlv_0= 'Board' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) ) (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ':' ( (lv_totalHours_10_0= RULE_INT ) ) otherlv_11= 'h' ) otherlv_12= '(moderator)' (otherlv_13= ',' ( ( ruleFQN ) ) (otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h' ) )* )? ) ;
    public final EObject rulectBoard() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token lv_totalHours_10_0=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token lv_totalHours_16_0=null;
        Token otherlv_17=null;


        	enterRule();

        try {
            // InternalUmlModel.g:4085:2: ( (otherlv_0= 'Board' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) ) (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ':' ( (lv_totalHours_10_0= RULE_INT ) ) otherlv_11= 'h' ) otherlv_12= '(moderator)' (otherlv_13= ',' ( ( ruleFQN ) ) (otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h' ) )* )? ) )
            // InternalUmlModel.g:4086:2: (otherlv_0= 'Board' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) ) (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ':' ( (lv_totalHours_10_0= RULE_INT ) ) otherlv_11= 'h' ) otherlv_12= '(moderator)' (otherlv_13= ',' ( ( ruleFQN ) ) (otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h' ) )* )? )
            {
            // InternalUmlModel.g:4086:2: (otherlv_0= 'Board' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) ) (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ':' ( (lv_totalHours_10_0= RULE_INT ) ) otherlv_11= 'h' ) otherlv_12= '(moderator)' (otherlv_13= ',' ( ( ruleFQN ) ) (otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h' ) )* )? )
            // InternalUmlModel.g:4087:3: otherlv_0= 'Board' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) ) (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ':' ( (lv_totalHours_10_0= RULE_INT ) ) otherlv_11= 'h' ) otherlv_12= '(moderator)' (otherlv_13= ',' ( ( ruleFQN ) ) (otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h' ) )* )?
            {
            otherlv_0=(Token)match(input,90,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtBoardAccess().getBoardKeyword_0());
            		
            // InternalUmlModel.g:4091:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:4092:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:4092:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:4093:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_107); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtBoardAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtBoardRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalUmlModel.g:4109:3: (otherlv_2= 'in' ( ( ruleFQN ) ) (otherlv_4= ',' ( ( ruleFQN ) ) )* )?
            int alt89=2;
            int LA89_0 = input.LA(1);

            if ( (LA89_0==44) ) {
                alt89=1;
            }
            switch (alt89) {
                case 1 :
                    // InternalUmlModel.g:4110:4: otherlv_2= 'in' ( ( ruleFQN ) ) (otherlv_4= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_2=(Token)match(input,44,FOLLOW_4); 

                    				newLeafNode(otherlv_2, grammarAccess.getCtBoardAccess().getInKeyword_2_0());
                    			
                    // InternalUmlModel.g:4114:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:4115:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:4115:5: ( ruleFQN )
                    // InternalUmlModel.g:4116:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtBoardRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtBoardAccess().getRnctCoursesCtCourseCrossReference_2_1_0());
                    					
                    pushFollow(FOLLOW_108);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:4130:4: (otherlv_4= ',' ( ( ruleFQN ) ) )*
                    loop88:
                    do {
                        int alt88=2;
                        int LA88_0 = input.LA(1);

                        if ( (LA88_0==16) ) {
                            alt88=1;
                        }


                        switch (alt88) {
                    	case 1 :
                    	    // InternalUmlModel.g:4131:5: otherlv_4= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_4=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_4, grammarAccess.getCtBoardAccess().getCommaKeyword_2_2_0());
                    	    				
                    	    // InternalUmlModel.g:4135:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4136:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4136:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4137:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtBoardRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtBoardAccess().getRnctCourseCtCourseCrossReference_2_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_108);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop88;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_6=(Token)match(input,22,FOLLOW_109); 

            			newLeafNode(otherlv_6, grammarAccess.getCtBoardAccess().getColonKeyword_3());
            		
            // InternalUmlModel.g:4157:3: (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ':' ( (lv_totalHours_10_0= RULE_INT ) ) otherlv_11= 'h' ) otherlv_12= '(moderator)' (otherlv_13= ',' ( ( ruleFQN ) ) (otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h' ) )* )?
            int alt91=2;
            int LA91_0 = input.LA(1);

            if ( (LA91_0==91) ) {
                alt91=1;
            }
            switch (alt91) {
                case 1 :
                    // InternalUmlModel.g:4158:4: otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ':' ( (lv_totalHours_10_0= RULE_INT ) ) otherlv_11= 'h' ) otherlv_12= '(moderator)' (otherlv_13= ',' ( ( ruleFQN ) ) (otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h' ) )*
                    {
                    otherlv_7=(Token)match(input,91,FOLLOW_4); 

                    				newLeafNode(otherlv_7, grammarAccess.getCtBoardAccess().getInstructorsKeyword_4_0());
                    			
                    // InternalUmlModel.g:4162:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:4163:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:4163:5: ( ruleFQN )
                    // InternalUmlModel.g:4164:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtBoardRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtBoardAccess().getRnctInstructorsCtInstructorCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_16);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:4178:4: (otherlv_9= ':' ( (lv_totalHours_10_0= RULE_INT ) ) otherlv_11= 'h' )
                    // InternalUmlModel.g:4179:5: otherlv_9= ':' ( (lv_totalHours_10_0= RULE_INT ) ) otherlv_11= 'h'
                    {
                    otherlv_9=(Token)match(input,22,FOLLOW_6); 

                    					newLeafNode(otherlv_9, grammarAccess.getCtBoardAccess().getColonKeyword_4_2_0());
                    				
                    // InternalUmlModel.g:4183:5: ( (lv_totalHours_10_0= RULE_INT ) )
                    // InternalUmlModel.g:4184:6: (lv_totalHours_10_0= RULE_INT )
                    {
                    // InternalUmlModel.g:4184:6: (lv_totalHours_10_0= RULE_INT )
                    // InternalUmlModel.g:4185:7: lv_totalHours_10_0= RULE_INT
                    {
                    lv_totalHours_10_0=(Token)match(input,RULE_INT,FOLLOW_110); 

                    							newLeafNode(lv_totalHours_10_0, grammarAccess.getCtBoardAccess().getTotalHoursINTTerminalRuleCall_4_2_1_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getCtBoardRule());
                    							}
                    							addWithLastConsumed(
                    								current,
                    								"totalHours",
                    								lv_totalHours_10_0,
                    								"org.eclipse.xtext.common.Terminals.INT");
                    						

                    }


                    }

                    otherlv_11=(Token)match(input,92,FOLLOW_111); 

                    					newLeafNode(otherlv_11, grammarAccess.getCtBoardAccess().getHKeyword_4_2_2());
                    				

                    }

                    otherlv_12=(Token)match(input,93,FOLLOW_112); 

                    				newLeafNode(otherlv_12, grammarAccess.getCtBoardAccess().getModeratorKeyword_4_3());
                    			
                    // InternalUmlModel.g:4210:4: (otherlv_13= ',' ( ( ruleFQN ) ) (otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h' ) )*
                    loop90:
                    do {
                        int alt90=2;
                        int LA90_0 = input.LA(1);

                        if ( (LA90_0==16) ) {
                            alt90=1;
                        }


                        switch (alt90) {
                    	case 1 :
                    	    // InternalUmlModel.g:4211:5: otherlv_13= ',' ( ( ruleFQN ) ) (otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h' )
                    	    {
                    	    otherlv_13=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_13, grammarAccess.getCtBoardAccess().getCommaKeyword_4_4_0());
                    	    				
                    	    // InternalUmlModel.g:4215:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4216:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4216:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4217:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtBoardRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtBoardAccess().getRnctInstructorCtInstructorCrossReference_4_4_1_0());
                    	    						
                    	    pushFollow(FOLLOW_16);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }

                    	    // InternalUmlModel.g:4231:5: (otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h' )
                    	    // InternalUmlModel.g:4232:6: otherlv_15= ':' ( (lv_totalHours_16_0= RULE_INT ) ) otherlv_17= 'h'
                    	    {
                    	    otherlv_15=(Token)match(input,22,FOLLOW_6); 

                    	    						newLeafNode(otherlv_15, grammarAccess.getCtBoardAccess().getColonKeyword_4_4_2_0());
                    	    					
                    	    // InternalUmlModel.g:4236:6: ( (lv_totalHours_16_0= RULE_INT ) )
                    	    // InternalUmlModel.g:4237:7: (lv_totalHours_16_0= RULE_INT )
                    	    {
                    	    // InternalUmlModel.g:4237:7: (lv_totalHours_16_0= RULE_INT )
                    	    // InternalUmlModel.g:4238:8: lv_totalHours_16_0= RULE_INT
                    	    {
                    	    lv_totalHours_16_0=(Token)match(input,RULE_INT,FOLLOW_110); 

                    	    								newLeafNode(lv_totalHours_16_0, grammarAccess.getCtBoardAccess().getTotalHoursINTTerminalRuleCall_4_4_2_1_0());
                    	    							

                    	    								if (current==null) {
                    	    									current = createModelElement(grammarAccess.getCtBoardRule());
                    	    								}
                    	    								addWithLastConsumed(
                    	    									current,
                    	    									"totalHours",
                    	    									lv_totalHours_16_0,
                    	    									"org.eclipse.xtext.common.Terminals.INT");
                    	    							

                    	    }


                    	    }

                    	    otherlv_17=(Token)match(input,92,FOLLOW_112); 

                    	    						newLeafNode(otherlv_17, grammarAccess.getCtBoardAccess().getHKeyword_4_4_2_2());
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop90;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectBoard"


    // $ANTLR start "entryRulectGroup"
    // InternalUmlModel.g:4265:1: entryRulectGroup returns [EObject current=null] : iv_rulectGroup= rulectGroup EOF ;
    public final EObject entryRulectGroup() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectGroup = null;


        try {
            // InternalUmlModel.g:4265:48: (iv_rulectGroup= rulectGroup EOF )
            // InternalUmlModel.g:4266:2: iv_rulectGroup= rulectGroup EOF
            {
             newCompositeNode(grammarAccess.getCtGroupRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectGroup=rulectGroup();

            state._fsp--;

             current =iv_rulectGroup; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectGroup"


    // $ANTLR start "rulectGroup"
    // InternalUmlModel.g:4272:1: rulectGroup returns [EObject current=null] : (otherlv_0= 'Group' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )? (otherlv_11= 'students' ( ( ruleFQN ) )? (otherlv_13= ',' ( ( ruleFQN ) ) )* )? ) ;
    public final EObject rulectGroup() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;


        	enterRule();

        try {
            // InternalUmlModel.g:4278:2: ( (otherlv_0= 'Group' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )? (otherlv_11= 'students' ( ( ruleFQN ) )? (otherlv_13= ',' ( ( ruleFQN ) ) )* )? ) )
            // InternalUmlModel.g:4279:2: (otherlv_0= 'Group' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )? (otherlv_11= 'students' ( ( ruleFQN ) )? (otherlv_13= ',' ( ( ruleFQN ) ) )* )? )
            {
            // InternalUmlModel.g:4279:2: (otherlv_0= 'Group' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )? (otherlv_11= 'students' ( ( ruleFQN ) )? (otherlv_13= ',' ( ( ruleFQN ) ) )* )? )
            // InternalUmlModel.g:4280:3: otherlv_0= 'Group' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )? (otherlv_11= 'students' ( ( ruleFQN ) )? (otherlv_13= ',' ( ( ruleFQN ) ) )* )?
            {
            otherlv_0=(Token)match(input,94,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtGroupAccess().getGroupKeyword_0());
            		
            // InternalUmlModel.g:4284:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:4285:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:4285:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:4286:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_107); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtGroupAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtGroupRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalUmlModel.g:4302:3: (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )?
            int alt94=2;
            int LA94_0 = input.LA(1);

            if ( (LA94_0==44) ) {
                alt94=1;
            }
            switch (alt94) {
                case 1 :
                    // InternalUmlModel.g:4303:4: otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_2=(Token)match(input,44,FOLLOW_113); 

                    				newLeafNode(otherlv_2, grammarAccess.getCtGroupAccess().getInKeyword_2_0());
                    			
                    // InternalUmlModel.g:4307:4: ( ( ruleFQN ) )?
                    int alt92=2;
                    int LA92_0 = input.LA(1);

                    if ( (LA92_0==RULE_ID) ) {
                        alt92=1;
                    }
                    switch (alt92) {
                        case 1 :
                            // InternalUmlModel.g:4308:5: ( ruleFQN )
                            {
                            // InternalUmlModel.g:4308:5: ( ruleFQN )
                            // InternalUmlModel.g:4309:6: ruleFQN
                            {

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getCtGroupRule());
                            						}
                            					

                            						newCompositeNode(grammarAccess.getCtGroupAccess().getRnctCoursesCtCourseCrossReference_2_1_0());
                            					
                            pushFollow(FOLLOW_108);
                            ruleFQN();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					

                            }


                            }
                            break;

                    }

                    // InternalUmlModel.g:4323:4: (otherlv_4= ',' ( ( ruleFQN ) ) )*
                    loop93:
                    do {
                        int alt93=2;
                        int LA93_0 = input.LA(1);

                        if ( (LA93_0==16) ) {
                            alt93=1;
                        }


                        switch (alt93) {
                    	case 1 :
                    	    // InternalUmlModel.g:4324:5: otherlv_4= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_4=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_4, grammarAccess.getCtGroupAccess().getCommaKeyword_2_2_0());
                    	    				
                    	    // InternalUmlModel.g:4328:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4329:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4329:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4330:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtGroupRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtGroupAccess().getRnctCourseCtCourseCrossReference_2_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_108);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop93;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_6=(Token)match(input,22,FOLLOW_114); 

            			newLeafNode(otherlv_6, grammarAccess.getCtGroupAccess().getColonKeyword_3());
            		
            // InternalUmlModel.g:4350:3: (otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )?
            int alt96=2;
            int LA96_0 = input.LA(1);

            if ( (LA96_0==91) ) {
                alt96=1;
            }
            switch (alt96) {
                case 1 :
                    // InternalUmlModel.g:4351:4: otherlv_7= 'instructors' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_7=(Token)match(input,91,FOLLOW_4); 

                    				newLeafNode(otherlv_7, grammarAccess.getCtGroupAccess().getInstructorsKeyword_4_0());
                    			
                    // InternalUmlModel.g:4355:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:4356:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:4356:5: ( ruleFQN )
                    // InternalUmlModel.g:4357:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtGroupRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtGroupAccess().getRnctInstructorCtInstructorCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_115);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:4371:4: (otherlv_9= ',' ( ( ruleFQN ) ) )*
                    loop95:
                    do {
                        int alt95=2;
                        int LA95_0 = input.LA(1);

                        if ( (LA95_0==16) ) {
                            alt95=1;
                        }


                        switch (alt95) {
                    	case 1 :
                    	    // InternalUmlModel.g:4372:5: otherlv_9= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_9=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_9, grammarAccess.getCtGroupAccess().getCommaKeyword_4_2_0());
                    	    				
                    	    // InternalUmlModel.g:4376:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4377:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4377:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4378:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtGroupRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtGroupAccess().getRnctInstructorCtInstructorCrossReference_4_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_115);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop95;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:4394:3: (otherlv_11= 'students' ( ( ruleFQN ) )? (otherlv_13= ',' ( ( ruleFQN ) ) )* )?
            int alt99=2;
            int LA99_0 = input.LA(1);

            if ( (LA99_0==70) ) {
                alt99=1;
            }
            switch (alt99) {
                case 1 :
                    // InternalUmlModel.g:4395:4: otherlv_11= 'students' ( ( ruleFQN ) )? (otherlv_13= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_11=(Token)match(input,70,FOLLOW_116); 

                    				newLeafNode(otherlv_11, grammarAccess.getCtGroupAccess().getStudentsKeyword_5_0());
                    			
                    // InternalUmlModel.g:4399:4: ( ( ruleFQN ) )?
                    int alt97=2;
                    int LA97_0 = input.LA(1);

                    if ( (LA97_0==RULE_ID) ) {
                        alt97=1;
                    }
                    switch (alt97) {
                        case 1 :
                            // InternalUmlModel.g:4400:5: ( ruleFQN )
                            {
                            // InternalUmlModel.g:4400:5: ( ruleFQN )
                            // InternalUmlModel.g:4401:6: ruleFQN
                            {

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getCtGroupRule());
                            						}
                            					

                            						newCompositeNode(grammarAccess.getCtGroupAccess().getRnstStudentCtStudentCrossReference_5_1_0());
                            					
                            pushFollow(FOLLOW_112);
                            ruleFQN();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					

                            }


                            }
                            break;

                    }

                    // InternalUmlModel.g:4415:4: (otherlv_13= ',' ( ( ruleFQN ) ) )*
                    loop98:
                    do {
                        int alt98=2;
                        int LA98_0 = input.LA(1);

                        if ( (LA98_0==16) ) {
                            alt98=1;
                        }


                        switch (alt98) {
                    	case 1 :
                    	    // InternalUmlModel.g:4416:5: otherlv_13= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_13=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_13, grammarAccess.getCtGroupAccess().getCommaKeyword_5_2_0());
                    	    				
                    	    // InternalUmlModel.g:4420:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4421:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4421:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4422:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtGroupRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtGroupAccess().getRnctStudentCtStudentCrossReference_5_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_112);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop98;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectGroup"


    // $ANTLR start "entryRulectInstructor"
    // InternalUmlModel.g:4442:1: entryRulectInstructor returns [EObject current=null] : iv_rulectInstructor= rulectInstructor EOF ;
    public final EObject entryRulectInstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectInstructor = null;


        try {
            // InternalUmlModel.g:4442:53: (iv_rulectInstructor= rulectInstructor EOF )
            // InternalUmlModel.g:4443:2: iv_rulectInstructor= rulectInstructor EOF
            {
             newCompositeNode(grammarAccess.getCtInstructorRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectInstructor=rulectInstructor();

            state._fsp--;

             current =iv_rulectInstructor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectInstructor"


    // $ANTLR start "rulectInstructor"
    // InternalUmlModel.g:4449:1: rulectInstructor returns [EObject current=null] : (otherlv_0= 'Instructor' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )? (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )? (otherlv_13= 'groups' ( ( ruleFQN ) )? (otherlv_15= ',' ( ( ruleFQN ) ) )* )? (otherlv_17= 'board' ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* )? ) ;
    public final EObject rulectInstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token lv_firstname_8_0=null;
        Token otherlv_9=null;
        Token lv_lastname_10_0=null;
        Token otherlv_11=null;
        Token lv_email_12_0=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_17=null;
        Token otherlv_19=null;


        	enterRule();

        try {
            // InternalUmlModel.g:4455:2: ( (otherlv_0= 'Instructor' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )? (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )? (otherlv_13= 'groups' ( ( ruleFQN ) )? (otherlv_15= ',' ( ( ruleFQN ) ) )* )? (otherlv_17= 'board' ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* )? ) )
            // InternalUmlModel.g:4456:2: (otherlv_0= 'Instructor' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )? (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )? (otherlv_13= 'groups' ( ( ruleFQN ) )? (otherlv_15= ',' ( ( ruleFQN ) ) )* )? (otherlv_17= 'board' ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* )? )
            {
            // InternalUmlModel.g:4456:2: (otherlv_0= 'Instructor' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )? (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )? (otherlv_13= 'groups' ( ( ruleFQN ) )? (otherlv_15= ',' ( ( ruleFQN ) ) )* )? (otherlv_17= 'board' ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* )? )
            // InternalUmlModel.g:4457:3: otherlv_0= 'Instructor' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )? (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )? (otherlv_13= 'groups' ( ( ruleFQN ) )? (otherlv_15= ',' ( ( ruleFQN ) ) )* )? (otherlv_17= 'board' ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* )?
            {
            otherlv_0=(Token)match(input,95,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtInstructorAccess().getInstructorKeyword_0());
            		
            // InternalUmlModel.g:4461:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:4462:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:4462:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:4463:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_107); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtInstructorAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtInstructorRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalUmlModel.g:4479:3: (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )?
            int alt102=2;
            int LA102_0 = input.LA(1);

            if ( (LA102_0==44) ) {
                alt102=1;
            }
            switch (alt102) {
                case 1 :
                    // InternalUmlModel.g:4480:4: otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_2=(Token)match(input,44,FOLLOW_113); 

                    				newLeafNode(otherlv_2, grammarAccess.getCtInstructorAccess().getInKeyword_2_0());
                    			
                    // InternalUmlModel.g:4484:4: ( ( ruleFQN ) )?
                    int alt100=2;
                    int LA100_0 = input.LA(1);

                    if ( (LA100_0==RULE_ID) ) {
                        alt100=1;
                    }
                    switch (alt100) {
                        case 1 :
                            // InternalUmlModel.g:4485:5: ( ruleFQN )
                            {
                            // InternalUmlModel.g:4485:5: ( ruleFQN )
                            // InternalUmlModel.g:4486:6: ruleFQN
                            {

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getCtInstructorRule());
                            						}
                            					

                            						newCompositeNode(grammarAccess.getCtInstructorAccess().getRnctCoursesCtCourseCrossReference_2_1_0());
                            					
                            pushFollow(FOLLOW_108);
                            ruleFQN();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					

                            }


                            }
                            break;

                    }

                    // InternalUmlModel.g:4500:4: (otherlv_4= ',' ( ( ruleFQN ) ) )*
                    loop101:
                    do {
                        int alt101=2;
                        int LA101_0 = input.LA(1);

                        if ( (LA101_0==16) ) {
                            alt101=1;
                        }


                        switch (alt101) {
                    	case 1 :
                    	    // InternalUmlModel.g:4501:5: otherlv_4= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_4=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_4, grammarAccess.getCtInstructorAccess().getCommaKeyword_2_2_0());
                    	    				
                    	    // InternalUmlModel.g:4505:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4506:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4506:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4507:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtInstructorRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtInstructorAccess().getRnctCourseCtCourseCrossReference_2_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_108);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop101;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_6=(Token)match(input,22,FOLLOW_117); 

            			newLeafNode(otherlv_6, grammarAccess.getCtInstructorAccess().getColonKeyword_3());
            		
            // InternalUmlModel.g:4527:3: (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )?
            int alt104=2;
            int LA104_0 = input.LA(1);

            if ( (LA104_0==36) ) {
                alt104=1;
            }
            switch (alt104) {
                case 1 :
                    // InternalUmlModel.g:4528:4: otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )?
                    {
                    otherlv_7=(Token)match(input,36,FOLLOW_10); 

                    				newLeafNode(otherlv_7, grammarAccess.getCtInstructorAccess().getNameKeyword_4_0());
                    			
                    // InternalUmlModel.g:4532:4: ( (lv_firstname_8_0= RULE_STRING ) )
                    // InternalUmlModel.g:4533:5: (lv_firstname_8_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:4533:5: (lv_firstname_8_0= RULE_STRING )
                    // InternalUmlModel.g:4534:6: lv_firstname_8_0= RULE_STRING
                    {
                    lv_firstname_8_0=(Token)match(input,RULE_STRING,FOLLOW_118); 

                    						newLeafNode(lv_firstname_8_0, grammarAccess.getCtInstructorAccess().getFirstnameSTRINGTerminalRuleCall_4_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtInstructorRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"firstname",
                    							lv_firstname_8_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    // InternalUmlModel.g:4550:4: (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )?
                    int alt103=2;
                    int LA103_0 = input.LA(1);

                    if ( (LA103_0==16) ) {
                        alt103=1;
                    }
                    switch (alt103) {
                        case 1 :
                            // InternalUmlModel.g:4551:5: otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) )
                            {
                            otherlv_9=(Token)match(input,16,FOLLOW_10); 

                            					newLeafNode(otherlv_9, grammarAccess.getCtInstructorAccess().getCommaKeyword_4_2_0());
                            				
                            // InternalUmlModel.g:4555:5: ( (lv_lastname_10_0= RULE_STRING ) )
                            // InternalUmlModel.g:4556:6: (lv_lastname_10_0= RULE_STRING )
                            {
                            // InternalUmlModel.g:4556:6: (lv_lastname_10_0= RULE_STRING )
                            // InternalUmlModel.g:4557:7: lv_lastname_10_0= RULE_STRING
                            {
                            lv_lastname_10_0=(Token)match(input,RULE_STRING,FOLLOW_119); 

                            							newLeafNode(lv_lastname_10_0, grammarAccess.getCtInstructorAccess().getLastnameSTRINGTerminalRuleCall_4_2_1_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getCtInstructorRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"lastname",
                            								lv_lastname_10_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }


                            }
                            break;

                    }


                    }
                    break;

            }

            // InternalUmlModel.g:4575:3: (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )?
            int alt105=2;
            int LA105_0 = input.LA(1);

            if ( (LA105_0==51) ) {
                alt105=1;
            }
            switch (alt105) {
                case 1 :
                    // InternalUmlModel.g:4576:4: otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) )
                    {
                    otherlv_11=(Token)match(input,51,FOLLOW_10); 

                    				newLeafNode(otherlv_11, grammarAccess.getCtInstructorAccess().getEmailKeyword_5_0());
                    			
                    // InternalUmlModel.g:4580:4: ( (lv_email_12_0= RULE_STRING ) )
                    // InternalUmlModel.g:4581:5: (lv_email_12_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:4581:5: (lv_email_12_0= RULE_STRING )
                    // InternalUmlModel.g:4582:6: lv_email_12_0= RULE_STRING
                    {
                    lv_email_12_0=(Token)match(input,RULE_STRING,FOLLOW_120); 

                    						newLeafNode(lv_email_12_0, grammarAccess.getCtInstructorAccess().getEmailSTRINGTerminalRuleCall_5_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtInstructorRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"email",
                    							lv_email_12_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:4599:3: (otherlv_13= 'groups' ( ( ruleFQN ) )? (otherlv_15= ',' ( ( ruleFQN ) ) )* )?
            int alt108=2;
            int LA108_0 = input.LA(1);

            if ( (LA108_0==67) ) {
                alt108=1;
            }
            switch (alt108) {
                case 1 :
                    // InternalUmlModel.g:4600:4: otherlv_13= 'groups' ( ( ruleFQN ) )? (otherlv_15= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_13=(Token)match(input,67,FOLLOW_121); 

                    				newLeafNode(otherlv_13, grammarAccess.getCtInstructorAccess().getGroupsKeyword_6_0());
                    			
                    // InternalUmlModel.g:4604:4: ( ( ruleFQN ) )?
                    int alt106=2;
                    int LA106_0 = input.LA(1);

                    if ( (LA106_0==RULE_ID) ) {
                        alt106=1;
                    }
                    switch (alt106) {
                        case 1 :
                            // InternalUmlModel.g:4605:5: ( ruleFQN )
                            {
                            // InternalUmlModel.g:4605:5: ( ruleFQN )
                            // InternalUmlModel.g:4606:6: ruleFQN
                            {

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getCtInstructorRule());
                            						}
                            					

                            						newCompositeNode(grammarAccess.getCtInstructorAccess().getRnctGroupCtGroupCrossReference_6_1_0());
                            					
                            pushFollow(FOLLOW_122);
                            ruleFQN();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					

                            }


                            }
                            break;

                    }

                    // InternalUmlModel.g:4620:4: (otherlv_15= ',' ( ( ruleFQN ) ) )*
                    loop107:
                    do {
                        int alt107=2;
                        int LA107_0 = input.LA(1);

                        if ( (LA107_0==16) ) {
                            alt107=1;
                        }


                        switch (alt107) {
                    	case 1 :
                    	    // InternalUmlModel.g:4621:5: otherlv_15= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_15=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_15, grammarAccess.getCtInstructorAccess().getCommaKeyword_6_2_0());
                    	    				
                    	    // InternalUmlModel.g:4625:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4626:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4626:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4627:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtInstructorRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtInstructorAccess().getRnctGroupCtGroupCrossReference_6_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_122);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop107;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:4643:3: (otherlv_17= 'board' ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )* )?
            int alt110=2;
            int LA110_0 = input.LA(1);

            if ( (LA110_0==96) ) {
                alt110=1;
            }
            switch (alt110) {
                case 1 :
                    // InternalUmlModel.g:4644:4: otherlv_17= 'board' ( ( ruleFQN ) ) (otherlv_19= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_17=(Token)match(input,96,FOLLOW_4); 

                    				newLeafNode(otherlv_17, grammarAccess.getCtInstructorAccess().getBoardKeyword_7_0());
                    			
                    // InternalUmlModel.g:4648:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:4649:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:4649:5: ( ruleFQN )
                    // InternalUmlModel.g:4650:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtInstructorRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtInstructorAccess().getBoardCtBoardCrossReference_7_1_0());
                    					
                    pushFollow(FOLLOW_112);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:4664:4: (otherlv_19= ',' ( ( ruleFQN ) ) )*
                    loop109:
                    do {
                        int alt109=2;
                        int LA109_0 = input.LA(1);

                        if ( (LA109_0==16) ) {
                            alt109=1;
                        }


                        switch (alt109) {
                    	case 1 :
                    	    // InternalUmlModel.g:4665:5: otherlv_19= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_19=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_19, grammarAccess.getCtInstructorAccess().getCommaKeyword_7_2_0());
                    	    				
                    	    // InternalUmlModel.g:4669:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4670:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4670:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4671:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtInstructorRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtInstructorAccess().getBoardCtBoardCrossReference_7_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_112);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop109;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectInstructor"


    // $ANTLR start "entryRulectPromotion"
    // InternalUmlModel.g:4691:1: entryRulectPromotion returns [EObject current=null] : iv_rulectPromotion= rulectPromotion EOF ;
    public final EObject entryRulectPromotion() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectPromotion = null;


        try {
            // InternalUmlModel.g:4691:52: (iv_rulectPromotion= rulectPromotion EOF )
            // InternalUmlModel.g:4692:2: iv_rulectPromotion= rulectPromotion EOF
            {
             newCompositeNode(grammarAccess.getCtPromotionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectPromotion=rulectPromotion();

            state._fsp--;

             current =iv_rulectPromotion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectPromotion"


    // $ANTLR start "rulectPromotion"
    // InternalUmlModel.g:4698:1: rulectPromotion returns [EObject current=null] : (otherlv_0= 'Promotion' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'groups' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )? ) ;
    public final EObject rulectPromotion() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_9=null;


        	enterRule();

        try {
            // InternalUmlModel.g:4704:2: ( (otherlv_0= 'Promotion' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'groups' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )? ) )
            // InternalUmlModel.g:4705:2: (otherlv_0= 'Promotion' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'groups' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )? )
            {
            // InternalUmlModel.g:4705:2: (otherlv_0= 'Promotion' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'groups' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )? )
            // InternalUmlModel.g:4706:3: otherlv_0= 'Promotion' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'groups' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )?
            {
            otherlv_0=(Token)match(input,97,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtPromotionAccess().getPromotionKeyword_0());
            		
            // InternalUmlModel.g:4710:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:4711:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:4711:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:4712:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_107); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtPromotionAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtPromotionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalUmlModel.g:4728:3: (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )?
            int alt113=2;
            int LA113_0 = input.LA(1);

            if ( (LA113_0==44) ) {
                alt113=1;
            }
            switch (alt113) {
                case 1 :
                    // InternalUmlModel.g:4729:4: otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_2=(Token)match(input,44,FOLLOW_113); 

                    				newLeafNode(otherlv_2, grammarAccess.getCtPromotionAccess().getInKeyword_2_0());
                    			
                    // InternalUmlModel.g:4733:4: ( ( ruleFQN ) )?
                    int alt111=2;
                    int LA111_0 = input.LA(1);

                    if ( (LA111_0==RULE_ID) ) {
                        alt111=1;
                    }
                    switch (alt111) {
                        case 1 :
                            // InternalUmlModel.g:4734:5: ( ruleFQN )
                            {
                            // InternalUmlModel.g:4734:5: ( ruleFQN )
                            // InternalUmlModel.g:4735:6: ruleFQN
                            {

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getCtPromotionRule());
                            						}
                            					

                            						newCompositeNode(grammarAccess.getCtPromotionAccess().getRnctCoursesCtCourseCrossReference_2_1_0());
                            					
                            pushFollow(FOLLOW_108);
                            ruleFQN();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					

                            }


                            }
                            break;

                    }

                    // InternalUmlModel.g:4749:4: (otherlv_4= ',' ( ( ruleFQN ) ) )*
                    loop112:
                    do {
                        int alt112=2;
                        int LA112_0 = input.LA(1);

                        if ( (LA112_0==16) ) {
                            alt112=1;
                        }


                        switch (alt112) {
                    	case 1 :
                    	    // InternalUmlModel.g:4750:5: otherlv_4= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_4=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_4, grammarAccess.getCtPromotionAccess().getCommaKeyword_2_2_0());
                    	    				
                    	    // InternalUmlModel.g:4754:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4755:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4755:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4756:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtPromotionRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtPromotionAccess().getRnctCourseCtCourseCrossReference_2_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_108);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop112;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_6=(Token)match(input,22,FOLLOW_123); 

            			newLeafNode(otherlv_6, grammarAccess.getCtPromotionAccess().getColonKeyword_3());
            		
            // InternalUmlModel.g:4776:3: (otherlv_7= 'groups' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )* )?
            int alt115=2;
            int LA115_0 = input.LA(1);

            if ( (LA115_0==67) ) {
                alt115=1;
            }
            switch (alt115) {
                case 1 :
                    // InternalUmlModel.g:4777:4: otherlv_7= 'groups' ( ( ruleFQN ) ) (otherlv_9= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_7=(Token)match(input,67,FOLLOW_4); 

                    				newLeafNode(otherlv_7, grammarAccess.getCtPromotionAccess().getGroupsKeyword_4_0());
                    			
                    // InternalUmlModel.g:4781:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:4782:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:4782:5: ( ruleFQN )
                    // InternalUmlModel.g:4783:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtPromotionRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtPromotionAccess().getRnctGroupCtGroupCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_112);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:4797:4: (otherlv_9= ',' ( ( ruleFQN ) ) )*
                    loop114:
                    do {
                        int alt114=2;
                        int LA114_0 = input.LA(1);

                        if ( (LA114_0==16) ) {
                            alt114=1;
                        }


                        switch (alt114) {
                    	case 1 :
                    	    // InternalUmlModel.g:4798:5: otherlv_9= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_9=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_9, grammarAccess.getCtPromotionAccess().getCommaKeyword_4_2_0());
                    	    				
                    	    // InternalUmlModel.g:4802:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4803:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4803:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4804:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtPromotionRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtPromotionAccess().getRnctGroupCtGroupCrossReference_4_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_112);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop114;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectPromotion"


    // $ANTLR start "entryRulectStudent"
    // InternalUmlModel.g:4824:1: entryRulectStudent returns [EObject current=null] : iv_rulectStudent= rulectStudent EOF ;
    public final EObject entryRulectStudent() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectStudent = null;


        try {
            // InternalUmlModel.g:4824:50: (iv_rulectStudent= rulectStudent EOF )
            // InternalUmlModel.g:4825:2: iv_rulectStudent= rulectStudent EOF
            {
             newCompositeNode(grammarAccess.getCtStudentRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectStudent=rulectStudent();

            state._fsp--;

             current =iv_rulectStudent; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectStudent"


    // $ANTLR start "rulectStudent"
    // InternalUmlModel.g:4831:1: rulectStudent returns [EObject current=null] : (otherlv_0= 'Student' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )? (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )? (otherlv_13= 'groups' ( ( ruleFQN ) ) (otherlv_15= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctGrades_17_0= rulectGrades ) )? ) ;
    public final EObject rulectStudent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token lv_firstname_8_0=null;
        Token otherlv_9=null;
        Token lv_lastname_10_0=null;
        Token otherlv_11=null;
        Token lv_email_12_0=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        EObject lv_rnctGrades_17_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:4837:2: ( (otherlv_0= 'Student' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )? (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )? (otherlv_13= 'groups' ( ( ruleFQN ) ) (otherlv_15= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctGrades_17_0= rulectGrades ) )? ) )
            // InternalUmlModel.g:4838:2: (otherlv_0= 'Student' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )? (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )? (otherlv_13= 'groups' ( ( ruleFQN ) ) (otherlv_15= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctGrades_17_0= rulectGrades ) )? )
            {
            // InternalUmlModel.g:4838:2: (otherlv_0= 'Student' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )? (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )? (otherlv_13= 'groups' ( ( ruleFQN ) ) (otherlv_15= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctGrades_17_0= rulectGrades ) )? )
            // InternalUmlModel.g:4839:3: otherlv_0= 'Student' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )? otherlv_6= ':' (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )? (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )? (otherlv_13= 'groups' ( ( ruleFQN ) ) (otherlv_15= ',' ( ( ruleFQN ) ) )* )? ( (lv_rnctGrades_17_0= rulectGrades ) )?
            {
            otherlv_0=(Token)match(input,98,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtStudentAccess().getStudentKeyword_0());
            		
            // InternalUmlModel.g:4843:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:4844:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:4844:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:4845:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_107); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtStudentAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtStudentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalUmlModel.g:4861:3: (otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )* )?
            int alt118=2;
            int LA118_0 = input.LA(1);

            if ( (LA118_0==44) ) {
                alt118=1;
            }
            switch (alt118) {
                case 1 :
                    // InternalUmlModel.g:4862:4: otherlv_2= 'in' ( ( ruleFQN ) )? (otherlv_4= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_2=(Token)match(input,44,FOLLOW_113); 

                    				newLeafNode(otherlv_2, grammarAccess.getCtStudentAccess().getInKeyword_2_0());
                    			
                    // InternalUmlModel.g:4866:4: ( ( ruleFQN ) )?
                    int alt116=2;
                    int LA116_0 = input.LA(1);

                    if ( (LA116_0==RULE_ID) ) {
                        alt116=1;
                    }
                    switch (alt116) {
                        case 1 :
                            // InternalUmlModel.g:4867:5: ( ruleFQN )
                            {
                            // InternalUmlModel.g:4867:5: ( ruleFQN )
                            // InternalUmlModel.g:4868:6: ruleFQN
                            {

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getCtStudentRule());
                            						}
                            					

                            						newCompositeNode(grammarAccess.getCtStudentAccess().getRnctCoursesCtCourseCrossReference_2_1_0());
                            					
                            pushFollow(FOLLOW_108);
                            ruleFQN();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					

                            }


                            }
                            break;

                    }

                    // InternalUmlModel.g:4882:4: (otherlv_4= ',' ( ( ruleFQN ) ) )*
                    loop117:
                    do {
                        int alt117=2;
                        int LA117_0 = input.LA(1);

                        if ( (LA117_0==16) ) {
                            alt117=1;
                        }


                        switch (alt117) {
                    	case 1 :
                    	    // InternalUmlModel.g:4883:5: otherlv_4= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_4=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_4, grammarAccess.getCtStudentAccess().getCommaKeyword_2_2_0());
                    	    				
                    	    // InternalUmlModel.g:4887:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:4888:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:4888:6: ( ruleFQN )
                    	    // InternalUmlModel.g:4889:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtStudentRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtStudentAccess().getRnctCourseCtCourseCrossReference_2_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_108);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop117;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_6=(Token)match(input,22,FOLLOW_124); 

            			newLeafNode(otherlv_6, grammarAccess.getCtStudentAccess().getColonKeyword_3());
            		
            // InternalUmlModel.g:4909:3: (otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )? )?
            int alt120=2;
            int LA120_0 = input.LA(1);

            if ( (LA120_0==36) ) {
                alt120=1;
            }
            switch (alt120) {
                case 1 :
                    // InternalUmlModel.g:4910:4: otherlv_7= 'name' ( (lv_firstname_8_0= RULE_STRING ) ) (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )?
                    {
                    otherlv_7=(Token)match(input,36,FOLLOW_10); 

                    				newLeafNode(otherlv_7, grammarAccess.getCtStudentAccess().getNameKeyword_4_0());
                    			
                    // InternalUmlModel.g:4914:4: ( (lv_firstname_8_0= RULE_STRING ) )
                    // InternalUmlModel.g:4915:5: (lv_firstname_8_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:4915:5: (lv_firstname_8_0= RULE_STRING )
                    // InternalUmlModel.g:4916:6: lv_firstname_8_0= RULE_STRING
                    {
                    lv_firstname_8_0=(Token)match(input,RULE_STRING,FOLLOW_125); 

                    						newLeafNode(lv_firstname_8_0, grammarAccess.getCtStudentAccess().getFirstnameSTRINGTerminalRuleCall_4_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtStudentRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"firstname",
                    							lv_firstname_8_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    // InternalUmlModel.g:4932:4: (otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) ) )?
                    int alt119=2;
                    int LA119_0 = input.LA(1);

                    if ( (LA119_0==16) ) {
                        alt119=1;
                    }
                    switch (alt119) {
                        case 1 :
                            // InternalUmlModel.g:4933:5: otherlv_9= ',' ( (lv_lastname_10_0= RULE_STRING ) )
                            {
                            otherlv_9=(Token)match(input,16,FOLLOW_10); 

                            					newLeafNode(otherlv_9, grammarAccess.getCtStudentAccess().getCommaKeyword_4_2_0());
                            				
                            // InternalUmlModel.g:4937:5: ( (lv_lastname_10_0= RULE_STRING ) )
                            // InternalUmlModel.g:4938:6: (lv_lastname_10_0= RULE_STRING )
                            {
                            // InternalUmlModel.g:4938:6: (lv_lastname_10_0= RULE_STRING )
                            // InternalUmlModel.g:4939:7: lv_lastname_10_0= RULE_STRING
                            {
                            lv_lastname_10_0=(Token)match(input,RULE_STRING,FOLLOW_126); 

                            							newLeafNode(lv_lastname_10_0, grammarAccess.getCtStudentAccess().getLastnameSTRINGTerminalRuleCall_4_2_1_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getCtStudentRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"lastname",
                            								lv_lastname_10_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }


                            }
                            break;

                    }


                    }
                    break;

            }

            // InternalUmlModel.g:4957:3: (otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) ) )?
            int alt121=2;
            int LA121_0 = input.LA(1);

            if ( (LA121_0==51) ) {
                alt121=1;
            }
            switch (alt121) {
                case 1 :
                    // InternalUmlModel.g:4958:4: otherlv_11= 'email' ( (lv_email_12_0= RULE_STRING ) )
                    {
                    otherlv_11=(Token)match(input,51,FOLLOW_10); 

                    				newLeafNode(otherlv_11, grammarAccess.getCtStudentAccess().getEmailKeyword_5_0());
                    			
                    // InternalUmlModel.g:4962:4: ( (lv_email_12_0= RULE_STRING ) )
                    // InternalUmlModel.g:4963:5: (lv_email_12_0= RULE_STRING )
                    {
                    // InternalUmlModel.g:4963:5: (lv_email_12_0= RULE_STRING )
                    // InternalUmlModel.g:4964:6: lv_email_12_0= RULE_STRING
                    {
                    lv_email_12_0=(Token)match(input,RULE_STRING,FOLLOW_127); 

                    						newLeafNode(lv_email_12_0, grammarAccess.getCtStudentAccess().getEmailSTRINGTerminalRuleCall_5_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtStudentRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"email",
                    							lv_email_12_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalUmlModel.g:4981:3: (otherlv_13= 'groups' ( ( ruleFQN ) ) (otherlv_15= ',' ( ( ruleFQN ) ) )* )?
            int alt123=2;
            int LA123_0 = input.LA(1);

            if ( (LA123_0==67) ) {
                alt123=1;
            }
            switch (alt123) {
                case 1 :
                    // InternalUmlModel.g:4982:4: otherlv_13= 'groups' ( ( ruleFQN ) ) (otherlv_15= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_13=(Token)match(input,67,FOLLOW_4); 

                    				newLeafNode(otherlv_13, grammarAccess.getCtStudentAccess().getGroupsKeyword_6_0());
                    			
                    // InternalUmlModel.g:4986:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:4987:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:4987:5: ( ruleFQN )
                    // InternalUmlModel.g:4988:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtStudentRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtStudentAccess().getRnctGroupCtGroupCrossReference_6_1_0());
                    					
                    pushFollow(FOLLOW_128);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:5002:4: (otherlv_15= ',' ( ( ruleFQN ) ) )*
                    loop122:
                    do {
                        int alt122=2;
                        int LA122_0 = input.LA(1);

                        if ( (LA122_0==16) ) {
                            alt122=1;
                        }


                        switch (alt122) {
                    	case 1 :
                    	    // InternalUmlModel.g:5003:5: otherlv_15= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_15=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_15, grammarAccess.getCtStudentAccess().getCommaKeyword_6_2_0());
                    	    				
                    	    // InternalUmlModel.g:5007:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:5008:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:5008:6: ( ruleFQN )
                    	    // InternalUmlModel.g:5009:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtStudentRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtStudentAccess().getRnctGroupCtGroupCrossReference_6_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_128);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop122;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalUmlModel.g:5025:3: ( (lv_rnctGrades_17_0= rulectGrades ) )?
            int alt124=2;
            int LA124_0 = input.LA(1);

            if ( (LA124_0==86) ) {
                alt124=1;
            }
            switch (alt124) {
                case 1 :
                    // InternalUmlModel.g:5026:4: (lv_rnctGrades_17_0= rulectGrades )
                    {
                    // InternalUmlModel.g:5026:4: (lv_rnctGrades_17_0= rulectGrades )
                    // InternalUmlModel.g:5027:5: lv_rnctGrades_17_0= rulectGrades
                    {

                    					newCompositeNode(grammarAccess.getCtStudentAccess().getRnctGradesCtGradesParserRuleCall_7_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_rnctGrades_17_0=rulectGrades();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCtStudentRule());
                    					}
                    					add(
                    						current,
                    						"rnctGrades",
                    						lv_rnctGrades_17_0,
                    						"tesma.ovanes.UmlModel.ctGrades");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectStudent"


    // $ANTLR start "entryRulectFieldCoverage"
    // InternalUmlModel.g:5048:1: entryRulectFieldCoverage returns [EObject current=null] : iv_rulectFieldCoverage= rulectFieldCoverage EOF ;
    public final EObject entryRulectFieldCoverage() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectFieldCoverage = null;


        try {
            // InternalUmlModel.g:5048:56: (iv_rulectFieldCoverage= rulectFieldCoverage EOF )
            // InternalUmlModel.g:5049:2: iv_rulectFieldCoverage= rulectFieldCoverage EOF
            {
             newCompositeNode(grammarAccess.getCtFieldCoverageRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectFieldCoverage=rulectFieldCoverage();

            state._fsp--;

             current =iv_rulectFieldCoverage; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectFieldCoverage"


    // $ANTLR start "rulectFieldCoverage"
    // InternalUmlModel.g:5055:1: rulectFieldCoverage returns [EObject current=null] : (otherlv_0= 'FieldCoverage' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_focusLevel_3_0= RULE_INT ) ) otherlv_4= '/' ( (lv_inputLevel_5_0= RULE_INT ) ) otherlv_6= '/' ( (lv_outputLevel_7_0= RULE_INT ) ) otherlv_8= ')' otherlv_9= '{' ( ( ( ruleFQN ) ) otherlv_11= '(' ( (lv_relativeWeight_12_0= RULE_INT ) ) otherlv_13= '/' ( (lv_bloomInLevel_14_0= RULE_INT ) ) otherlv_15= '/' ( (lv_bloomOutLevel_16_0= RULE_INT ) ) otherlv_17= ')' (otherlv_18= ',' ( ( ruleFQN ) ) otherlv_20= '(' ( (lv_relativeWeight_21_0= RULE_INT ) ) otherlv_22= '/' ( (lv_bloomInLevel_23_0= RULE_INT ) ) otherlv_24= '/' ( (lv_bloomOutLevel_25_0= RULE_INT ) ) otherlv_26= ')' )* )? otherlv_27= '}' ) ;
    public final EObject rulectFieldCoverage() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_focusLevel_3_0=null;
        Token otherlv_4=null;
        Token lv_inputLevel_5_0=null;
        Token otherlv_6=null;
        Token lv_outputLevel_7_0=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token lv_relativeWeight_12_0=null;
        Token otherlv_13=null;
        Token lv_bloomInLevel_14_0=null;
        Token otherlv_15=null;
        Token lv_bloomOutLevel_16_0=null;
        Token otherlv_17=null;
        Token otherlv_18=null;
        Token otherlv_20=null;
        Token lv_relativeWeight_21_0=null;
        Token otherlv_22=null;
        Token lv_bloomInLevel_23_0=null;
        Token otherlv_24=null;
        Token lv_bloomOutLevel_25_0=null;
        Token otherlv_26=null;
        Token otherlv_27=null;


        	enterRule();

        try {
            // InternalUmlModel.g:5061:2: ( (otherlv_0= 'FieldCoverage' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_focusLevel_3_0= RULE_INT ) ) otherlv_4= '/' ( (lv_inputLevel_5_0= RULE_INT ) ) otherlv_6= '/' ( (lv_outputLevel_7_0= RULE_INT ) ) otherlv_8= ')' otherlv_9= '{' ( ( ( ruleFQN ) ) otherlv_11= '(' ( (lv_relativeWeight_12_0= RULE_INT ) ) otherlv_13= '/' ( (lv_bloomInLevel_14_0= RULE_INT ) ) otherlv_15= '/' ( (lv_bloomOutLevel_16_0= RULE_INT ) ) otherlv_17= ')' (otherlv_18= ',' ( ( ruleFQN ) ) otherlv_20= '(' ( (lv_relativeWeight_21_0= RULE_INT ) ) otherlv_22= '/' ( (lv_bloomInLevel_23_0= RULE_INT ) ) otherlv_24= '/' ( (lv_bloomOutLevel_25_0= RULE_INT ) ) otherlv_26= ')' )* )? otherlv_27= '}' ) )
            // InternalUmlModel.g:5062:2: (otherlv_0= 'FieldCoverage' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_focusLevel_3_0= RULE_INT ) ) otherlv_4= '/' ( (lv_inputLevel_5_0= RULE_INT ) ) otherlv_6= '/' ( (lv_outputLevel_7_0= RULE_INT ) ) otherlv_8= ')' otherlv_9= '{' ( ( ( ruleFQN ) ) otherlv_11= '(' ( (lv_relativeWeight_12_0= RULE_INT ) ) otherlv_13= '/' ( (lv_bloomInLevel_14_0= RULE_INT ) ) otherlv_15= '/' ( (lv_bloomOutLevel_16_0= RULE_INT ) ) otherlv_17= ')' (otherlv_18= ',' ( ( ruleFQN ) ) otherlv_20= '(' ( (lv_relativeWeight_21_0= RULE_INT ) ) otherlv_22= '/' ( (lv_bloomInLevel_23_0= RULE_INT ) ) otherlv_24= '/' ( (lv_bloomOutLevel_25_0= RULE_INT ) ) otherlv_26= ')' )* )? otherlv_27= '}' )
            {
            // InternalUmlModel.g:5062:2: (otherlv_0= 'FieldCoverage' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_focusLevel_3_0= RULE_INT ) ) otherlv_4= '/' ( (lv_inputLevel_5_0= RULE_INT ) ) otherlv_6= '/' ( (lv_outputLevel_7_0= RULE_INT ) ) otherlv_8= ')' otherlv_9= '{' ( ( ( ruleFQN ) ) otherlv_11= '(' ( (lv_relativeWeight_12_0= RULE_INT ) ) otherlv_13= '/' ( (lv_bloomInLevel_14_0= RULE_INT ) ) otherlv_15= '/' ( (lv_bloomOutLevel_16_0= RULE_INT ) ) otherlv_17= ')' (otherlv_18= ',' ( ( ruleFQN ) ) otherlv_20= '(' ( (lv_relativeWeight_21_0= RULE_INT ) ) otherlv_22= '/' ( (lv_bloomInLevel_23_0= RULE_INT ) ) otherlv_24= '/' ( (lv_bloomOutLevel_25_0= RULE_INT ) ) otherlv_26= ')' )* )? otherlv_27= '}' )
            // InternalUmlModel.g:5063:3: otherlv_0= 'FieldCoverage' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_focusLevel_3_0= RULE_INT ) ) otherlv_4= '/' ( (lv_inputLevel_5_0= RULE_INT ) ) otherlv_6= '/' ( (lv_outputLevel_7_0= RULE_INT ) ) otherlv_8= ')' otherlv_9= '{' ( ( ( ruleFQN ) ) otherlv_11= '(' ( (lv_relativeWeight_12_0= RULE_INT ) ) otherlv_13= '/' ( (lv_bloomInLevel_14_0= RULE_INT ) ) otherlv_15= '/' ( (lv_bloomOutLevel_16_0= RULE_INT ) ) otherlv_17= ')' (otherlv_18= ',' ( ( ruleFQN ) ) otherlv_20= '(' ( (lv_relativeWeight_21_0= RULE_INT ) ) otherlv_22= '/' ( (lv_bloomInLevel_23_0= RULE_INT ) ) otherlv_24= '/' ( (lv_bloomOutLevel_25_0= RULE_INT ) ) otherlv_26= ')' )* )? otherlv_27= '}'
            {
            otherlv_0=(Token)match(input,99,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtFieldCoverageAccess().getFieldCoverageKeyword_0());
            		
            // InternalUmlModel.g:5067:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:5068:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:5068:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:5069:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_90); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtFieldCoverageAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtFieldCoverageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,78,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getCtFieldCoverageAccess().getLeftParenthesisKeyword_2());
            		
            // InternalUmlModel.g:5089:3: ( (lv_focusLevel_3_0= RULE_INT ) )
            // InternalUmlModel.g:5090:4: (lv_focusLevel_3_0= RULE_INT )
            {
            // InternalUmlModel.g:5090:4: (lv_focusLevel_3_0= RULE_INT )
            // InternalUmlModel.g:5091:5: lv_focusLevel_3_0= RULE_INT
            {
            lv_focusLevel_3_0=(Token)match(input,RULE_INT,FOLLOW_67); 

            					newLeafNode(lv_focusLevel_3_0, grammarAccess.getCtFieldCoverageAccess().getFocusLevelINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtFieldCoverageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"focusLevel",
            						lv_focusLevel_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_4=(Token)match(input,59,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getCtFieldCoverageAccess().getSolidusKeyword_4());
            		
            // InternalUmlModel.g:5111:3: ( (lv_inputLevel_5_0= RULE_INT ) )
            // InternalUmlModel.g:5112:4: (lv_inputLevel_5_0= RULE_INT )
            {
            // InternalUmlModel.g:5112:4: (lv_inputLevel_5_0= RULE_INT )
            // InternalUmlModel.g:5113:5: lv_inputLevel_5_0= RULE_INT
            {
            lv_inputLevel_5_0=(Token)match(input,RULE_INT,FOLLOW_67); 

            					newLeafNode(lv_inputLevel_5_0, grammarAccess.getCtFieldCoverageAccess().getInputLevelINTTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtFieldCoverageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"inputLevel",
            						lv_inputLevel_5_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_6=(Token)match(input,59,FOLLOW_6); 

            			newLeafNode(otherlv_6, grammarAccess.getCtFieldCoverageAccess().getSolidusKeyword_6());
            		
            // InternalUmlModel.g:5133:3: ( (lv_outputLevel_7_0= RULE_INT ) )
            // InternalUmlModel.g:5134:4: (lv_outputLevel_7_0= RULE_INT )
            {
            // InternalUmlModel.g:5134:4: (lv_outputLevel_7_0= RULE_INT )
            // InternalUmlModel.g:5135:5: lv_outputLevel_7_0= RULE_INT
            {
            lv_outputLevel_7_0=(Token)match(input,RULE_INT,FOLLOW_91); 

            					newLeafNode(lv_outputLevel_7_0, grammarAccess.getCtFieldCoverageAccess().getOutputLevelINTTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtFieldCoverageRule());
            					}
            					setWithLastConsumed(
            						current,
            						"outputLevel",
            						lv_outputLevel_7_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_8=(Token)match(input,79,FOLLOW_47); 

            			newLeafNode(otherlv_8, grammarAccess.getCtFieldCoverageAccess().getRightParenthesisKeyword_8());
            		
            otherlv_9=(Token)match(input,20,FOLLOW_105); 

            			newLeafNode(otherlv_9, grammarAccess.getCtFieldCoverageAccess().getLeftCurlyBracketKeyword_9());
            		
            // InternalUmlModel.g:5159:3: ( ( ( ruleFQN ) ) otherlv_11= '(' ( (lv_relativeWeight_12_0= RULE_INT ) ) otherlv_13= '/' ( (lv_bloomInLevel_14_0= RULE_INT ) ) otherlv_15= '/' ( (lv_bloomOutLevel_16_0= RULE_INT ) ) otherlv_17= ')' (otherlv_18= ',' ( ( ruleFQN ) ) otherlv_20= '(' ( (lv_relativeWeight_21_0= RULE_INT ) ) otherlv_22= '/' ( (lv_bloomInLevel_23_0= RULE_INT ) ) otherlv_24= '/' ( (lv_bloomOutLevel_25_0= RULE_INT ) ) otherlv_26= ')' )* )?
            int alt126=2;
            int LA126_0 = input.LA(1);

            if ( (LA126_0==RULE_ID) ) {
                alt126=1;
            }
            switch (alt126) {
                case 1 :
                    // InternalUmlModel.g:5160:4: ( ( ruleFQN ) ) otherlv_11= '(' ( (lv_relativeWeight_12_0= RULE_INT ) ) otherlv_13= '/' ( (lv_bloomInLevel_14_0= RULE_INT ) ) otherlv_15= '/' ( (lv_bloomOutLevel_16_0= RULE_INT ) ) otherlv_17= ')' (otherlv_18= ',' ( ( ruleFQN ) ) otherlv_20= '(' ( (lv_relativeWeight_21_0= RULE_INT ) ) otherlv_22= '/' ( (lv_bloomInLevel_23_0= RULE_INT ) ) otherlv_24= '/' ( (lv_bloomOutLevel_25_0= RULE_INT ) ) otherlv_26= ')' )*
                    {
                    // InternalUmlModel.g:5160:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:5161:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:5161:5: ( ruleFQN )
                    // InternalUmlModel.g:5162:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtFieldCoverageRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtFieldCoverageAccess().getRnctFieldCtFieldCrossReference_10_0_0());
                    					
                    pushFollow(FOLLOW_90);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    otherlv_11=(Token)match(input,78,FOLLOW_6); 

                    				newLeafNode(otherlv_11, grammarAccess.getCtFieldCoverageAccess().getLeftParenthesisKeyword_10_1());
                    			
                    // InternalUmlModel.g:5180:4: ( (lv_relativeWeight_12_0= RULE_INT ) )
                    // InternalUmlModel.g:5181:5: (lv_relativeWeight_12_0= RULE_INT )
                    {
                    // InternalUmlModel.g:5181:5: (lv_relativeWeight_12_0= RULE_INT )
                    // InternalUmlModel.g:5182:6: lv_relativeWeight_12_0= RULE_INT
                    {
                    lv_relativeWeight_12_0=(Token)match(input,RULE_INT,FOLLOW_67); 

                    						newLeafNode(lv_relativeWeight_12_0, grammarAccess.getCtFieldCoverageAccess().getRelativeWeightINTTerminalRuleCall_10_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtFieldCoverageRule());
                    						}
                    						addWithLastConsumed(
                    							current,
                    							"relativeWeight",
                    							lv_relativeWeight_12_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    otherlv_13=(Token)match(input,59,FOLLOW_6); 

                    				newLeafNode(otherlv_13, grammarAccess.getCtFieldCoverageAccess().getSolidusKeyword_10_3());
                    			
                    // InternalUmlModel.g:5202:4: ( (lv_bloomInLevel_14_0= RULE_INT ) )
                    // InternalUmlModel.g:5203:5: (lv_bloomInLevel_14_0= RULE_INT )
                    {
                    // InternalUmlModel.g:5203:5: (lv_bloomInLevel_14_0= RULE_INT )
                    // InternalUmlModel.g:5204:6: lv_bloomInLevel_14_0= RULE_INT
                    {
                    lv_bloomInLevel_14_0=(Token)match(input,RULE_INT,FOLLOW_67); 

                    						newLeafNode(lv_bloomInLevel_14_0, grammarAccess.getCtFieldCoverageAccess().getBloomInLevelINTTerminalRuleCall_10_4_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtFieldCoverageRule());
                    						}
                    						addWithLastConsumed(
                    							current,
                    							"bloomInLevel",
                    							lv_bloomInLevel_14_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    otherlv_15=(Token)match(input,59,FOLLOW_6); 

                    				newLeafNode(otherlv_15, grammarAccess.getCtFieldCoverageAccess().getSolidusKeyword_10_5());
                    			
                    // InternalUmlModel.g:5224:4: ( (lv_bloomOutLevel_16_0= RULE_INT ) )
                    // InternalUmlModel.g:5225:5: (lv_bloomOutLevel_16_0= RULE_INT )
                    {
                    // InternalUmlModel.g:5225:5: (lv_bloomOutLevel_16_0= RULE_INT )
                    // InternalUmlModel.g:5226:6: lv_bloomOutLevel_16_0= RULE_INT
                    {
                    lv_bloomOutLevel_16_0=(Token)match(input,RULE_INT,FOLLOW_91); 

                    						newLeafNode(lv_bloomOutLevel_16_0, grammarAccess.getCtFieldCoverageAccess().getBloomOutLevelINTTerminalRuleCall_10_6_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtFieldCoverageRule());
                    						}
                    						addWithLastConsumed(
                    							current,
                    							"bloomOutLevel",
                    							lv_bloomOutLevel_16_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    otherlv_17=(Token)match(input,79,FOLLOW_15); 

                    				newLeafNode(otherlv_17, grammarAccess.getCtFieldCoverageAccess().getRightParenthesisKeyword_10_7());
                    			
                    // InternalUmlModel.g:5246:4: (otherlv_18= ',' ( ( ruleFQN ) ) otherlv_20= '(' ( (lv_relativeWeight_21_0= RULE_INT ) ) otherlv_22= '/' ( (lv_bloomInLevel_23_0= RULE_INT ) ) otherlv_24= '/' ( (lv_bloomOutLevel_25_0= RULE_INT ) ) otherlv_26= ')' )*
                    loop125:
                    do {
                        int alt125=2;
                        int LA125_0 = input.LA(1);

                        if ( (LA125_0==16) ) {
                            alt125=1;
                        }


                        switch (alt125) {
                    	case 1 :
                    	    // InternalUmlModel.g:5247:5: otherlv_18= ',' ( ( ruleFQN ) ) otherlv_20= '(' ( (lv_relativeWeight_21_0= RULE_INT ) ) otherlv_22= '/' ( (lv_bloomInLevel_23_0= RULE_INT ) ) otherlv_24= '/' ( (lv_bloomOutLevel_25_0= RULE_INT ) ) otherlv_26= ')'
                    	    {
                    	    otherlv_18=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_18, grammarAccess.getCtFieldCoverageAccess().getCommaKeyword_10_8_0());
                    	    				
                    	    // InternalUmlModel.g:5251:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:5252:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:5252:6: ( ruleFQN )
                    	    // InternalUmlModel.g:5253:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtFieldCoverageRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtFieldCoverageAccess().getRnctFieldCtFieldCrossReference_10_8_1_0());
                    	    						
                    	    pushFollow(FOLLOW_90);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }

                    	    otherlv_20=(Token)match(input,78,FOLLOW_6); 

                    	    					newLeafNode(otherlv_20, grammarAccess.getCtFieldCoverageAccess().getLeftParenthesisKeyword_10_8_2());
                    	    				
                    	    // InternalUmlModel.g:5271:5: ( (lv_relativeWeight_21_0= RULE_INT ) )
                    	    // InternalUmlModel.g:5272:6: (lv_relativeWeight_21_0= RULE_INT )
                    	    {
                    	    // InternalUmlModel.g:5272:6: (lv_relativeWeight_21_0= RULE_INT )
                    	    // InternalUmlModel.g:5273:7: lv_relativeWeight_21_0= RULE_INT
                    	    {
                    	    lv_relativeWeight_21_0=(Token)match(input,RULE_INT,FOLLOW_67); 

                    	    							newLeafNode(lv_relativeWeight_21_0, grammarAccess.getCtFieldCoverageAccess().getRelativeWeightINTTerminalRuleCall_10_8_3_0());
                    	    						

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtFieldCoverageRule());
                    	    							}
                    	    							addWithLastConsumed(
                    	    								current,
                    	    								"relativeWeight",
                    	    								lv_relativeWeight_21_0,
                    	    								"org.eclipse.xtext.common.Terminals.INT");
                    	    						

                    	    }


                    	    }

                    	    otherlv_22=(Token)match(input,59,FOLLOW_6); 

                    	    					newLeafNode(otherlv_22, grammarAccess.getCtFieldCoverageAccess().getSolidusKeyword_10_8_4());
                    	    				
                    	    // InternalUmlModel.g:5293:5: ( (lv_bloomInLevel_23_0= RULE_INT ) )
                    	    // InternalUmlModel.g:5294:6: (lv_bloomInLevel_23_0= RULE_INT )
                    	    {
                    	    // InternalUmlModel.g:5294:6: (lv_bloomInLevel_23_0= RULE_INT )
                    	    // InternalUmlModel.g:5295:7: lv_bloomInLevel_23_0= RULE_INT
                    	    {
                    	    lv_bloomInLevel_23_0=(Token)match(input,RULE_INT,FOLLOW_67); 

                    	    							newLeafNode(lv_bloomInLevel_23_0, grammarAccess.getCtFieldCoverageAccess().getBloomInLevelINTTerminalRuleCall_10_8_5_0());
                    	    						

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtFieldCoverageRule());
                    	    							}
                    	    							addWithLastConsumed(
                    	    								current,
                    	    								"bloomInLevel",
                    	    								lv_bloomInLevel_23_0,
                    	    								"org.eclipse.xtext.common.Terminals.INT");
                    	    						

                    	    }


                    	    }

                    	    otherlv_24=(Token)match(input,59,FOLLOW_6); 

                    	    					newLeafNode(otherlv_24, grammarAccess.getCtFieldCoverageAccess().getSolidusKeyword_10_8_6());
                    	    				
                    	    // InternalUmlModel.g:5315:5: ( (lv_bloomOutLevel_25_0= RULE_INT ) )
                    	    // InternalUmlModel.g:5316:6: (lv_bloomOutLevel_25_0= RULE_INT )
                    	    {
                    	    // InternalUmlModel.g:5316:6: (lv_bloomOutLevel_25_0= RULE_INT )
                    	    // InternalUmlModel.g:5317:7: lv_bloomOutLevel_25_0= RULE_INT
                    	    {
                    	    lv_bloomOutLevel_25_0=(Token)match(input,RULE_INT,FOLLOW_91); 

                    	    							newLeafNode(lv_bloomOutLevel_25_0, grammarAccess.getCtFieldCoverageAccess().getBloomOutLevelINTTerminalRuleCall_10_8_7_0());
                    	    						

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtFieldCoverageRule());
                    	    							}
                    	    							addWithLastConsumed(
                    	    								current,
                    	    								"bloomOutLevel",
                    	    								lv_bloomOutLevel_25_0,
                    	    								"org.eclipse.xtext.common.Terminals.INT");
                    	    						

                    	    }


                    	    }

                    	    otherlv_26=(Token)match(input,79,FOLLOW_15); 

                    	    					newLeafNode(otherlv_26, grammarAccess.getCtFieldCoverageAccess().getRightParenthesisKeyword_10_8_8());
                    	    				

                    	    }
                    	    break;

                    	default :
                    	    break loop125;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_27=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_27, grammarAccess.getCtFieldCoverageAccess().getRightCurlyBracketKeyword_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectFieldCoverage"


    // $ANTLR start "entryRulectStandard"
    // InternalUmlModel.g:5347:1: entryRulectStandard returns [EObject current=null] : iv_rulectStandard= rulectStandard EOF ;
    public final EObject entryRulectStandard() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectStandard = null;


        try {
            // InternalUmlModel.g:5347:51: (iv_rulectStandard= rulectStandard EOF )
            // InternalUmlModel.g:5348:2: iv_rulectStandard= rulectStandard EOF
            {
             newCompositeNode(grammarAccess.getCtStandardRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectStandard=rulectStandard();

            state._fsp--;

             current =iv_rulectStandard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectStandard"


    // $ANTLR start "rulectStandard"
    // InternalUmlModel.g:5354:1: rulectStandard returns [EObject current=null] : (otherlv_0= 'Standard' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_rnctFields_3_0= rulectField ) )* otherlv_4= '}' ) ;
    public final EObject rulectStandard() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_rnctFields_3_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:5360:2: ( (otherlv_0= 'Standard' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_rnctFields_3_0= rulectField ) )* otherlv_4= '}' ) )
            // InternalUmlModel.g:5361:2: (otherlv_0= 'Standard' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_rnctFields_3_0= rulectField ) )* otherlv_4= '}' )
            {
            // InternalUmlModel.g:5361:2: (otherlv_0= 'Standard' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_rnctFields_3_0= rulectField ) )* otherlv_4= '}' )
            // InternalUmlModel.g:5362:3: otherlv_0= 'Standard' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_rnctFields_3_0= rulectField ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,100,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtStandardAccess().getStandardKeyword_0());
            		
            // InternalUmlModel.g:5366:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:5367:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:5367:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:5368:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_47); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtStandardAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtStandardRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,20,FOLLOW_129); 

            			newLeafNode(otherlv_2, grammarAccess.getCtStandardAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalUmlModel.g:5388:3: ( (lv_rnctFields_3_0= rulectField ) )*
            loop127:
            do {
                int alt127=2;
                int LA127_0 = input.LA(1);

                if ( (LA127_0==101) ) {
                    alt127=1;
                }


                switch (alt127) {
            	case 1 :
            	    // InternalUmlModel.g:5389:4: (lv_rnctFields_3_0= rulectField )
            	    {
            	    // InternalUmlModel.g:5389:4: (lv_rnctFields_3_0= rulectField )
            	    // InternalUmlModel.g:5390:5: lv_rnctFields_3_0= rulectField
            	    {

            	    					newCompositeNode(grammarAccess.getCtStandardAccess().getRnctFieldsCtFieldParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_129);
            	    lv_rnctFields_3_0=rulectField();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCtStandardRule());
            	    					}
            	    					add(
            	    						current,
            	    						"rnctFields",
            	    						lv_rnctFields_3_0,
            	    						"tesma.ovanes.UmlModel.ctField");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop127;
                }
            } while (true);

            otherlv_4=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getCtStandardAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectStandard"


    // $ANTLR start "entryRulectField"
    // InternalUmlModel.g:5415:1: entryRulectField returns [EObject current=null] : iv_rulectField= rulectField EOF ;
    public final EObject entryRulectField() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectField = null;


        try {
            // InternalUmlModel.g:5415:48: (iv_rulectField= rulectField EOF )
            // InternalUmlModel.g:5416:2: iv_rulectField= rulectField EOF
            {
             newCompositeNode(grammarAccess.getCtFieldRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectField=rulectField();

            state._fsp--;

             current =iv_rulectField; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectField"


    // $ANTLR start "rulectField"
    // InternalUmlModel.g:5422:1: rulectField returns [EObject current=null] : (otherlv_0= 'Field' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_areaNumber_3_0= RULE_INT ) ) (otherlv_4= ',' ( (lv_topicNumber_5_0= RULE_INT ) ) (otherlv_6= ',' ( (lv_subtopicnumber_7_0= RULE_INT ) ) )? )? otherlv_8= ',' ( (lv_description_9_0= RULE_STRING ) ) otherlv_10= ')' ) ;
    public final EObject rulectField() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_areaNumber_3_0=null;
        Token otherlv_4=null;
        Token lv_topicNumber_5_0=null;
        Token otherlv_6=null;
        Token lv_subtopicnumber_7_0=null;
        Token otherlv_8=null;
        Token lv_description_9_0=null;
        Token otherlv_10=null;


        	enterRule();

        try {
            // InternalUmlModel.g:5428:2: ( (otherlv_0= 'Field' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_areaNumber_3_0= RULE_INT ) ) (otherlv_4= ',' ( (lv_topicNumber_5_0= RULE_INT ) ) (otherlv_6= ',' ( (lv_subtopicnumber_7_0= RULE_INT ) ) )? )? otherlv_8= ',' ( (lv_description_9_0= RULE_STRING ) ) otherlv_10= ')' ) )
            // InternalUmlModel.g:5429:2: (otherlv_0= 'Field' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_areaNumber_3_0= RULE_INT ) ) (otherlv_4= ',' ( (lv_topicNumber_5_0= RULE_INT ) ) (otherlv_6= ',' ( (lv_subtopicnumber_7_0= RULE_INT ) ) )? )? otherlv_8= ',' ( (lv_description_9_0= RULE_STRING ) ) otherlv_10= ')' )
            {
            // InternalUmlModel.g:5429:2: (otherlv_0= 'Field' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_areaNumber_3_0= RULE_INT ) ) (otherlv_4= ',' ( (lv_topicNumber_5_0= RULE_INT ) ) (otherlv_6= ',' ( (lv_subtopicnumber_7_0= RULE_INT ) ) )? )? otherlv_8= ',' ( (lv_description_9_0= RULE_STRING ) ) otherlv_10= ')' )
            // InternalUmlModel.g:5430:3: otherlv_0= 'Field' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( (lv_areaNumber_3_0= RULE_INT ) ) (otherlv_4= ',' ( (lv_topicNumber_5_0= RULE_INT ) ) (otherlv_6= ',' ( (lv_subtopicnumber_7_0= RULE_INT ) ) )? )? otherlv_8= ',' ( (lv_description_9_0= RULE_STRING ) ) otherlv_10= ')'
            {
            otherlv_0=(Token)match(input,101,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtFieldAccess().getFieldKeyword_0());
            		
            // InternalUmlModel.g:5434:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:5435:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:5435:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:5436:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_90); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtFieldAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtFieldRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,78,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getCtFieldAccess().getLeftParenthesisKeyword_2());
            		
            // InternalUmlModel.g:5456:3: ( (lv_areaNumber_3_0= RULE_INT ) )
            // InternalUmlModel.g:5457:4: (lv_areaNumber_3_0= RULE_INT )
            {
            // InternalUmlModel.g:5457:4: (lv_areaNumber_3_0= RULE_INT )
            // InternalUmlModel.g:5458:5: lv_areaNumber_3_0= RULE_INT
            {
            lv_areaNumber_3_0=(Token)match(input,RULE_INT,FOLLOW_11); 

            					newLeafNode(lv_areaNumber_3_0, grammarAccess.getCtFieldAccess().getAreaNumberINTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtFieldRule());
            					}
            					setWithLastConsumed(
            						current,
            						"areaNumber",
            						lv_areaNumber_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalUmlModel.g:5474:3: (otherlv_4= ',' ( (lv_topicNumber_5_0= RULE_INT ) ) (otherlv_6= ',' ( (lv_subtopicnumber_7_0= RULE_INT ) ) )? )?
            int alt129=2;
            int LA129_0 = input.LA(1);

            if ( (LA129_0==16) ) {
                int LA129_1 = input.LA(2);

                if ( (LA129_1==RULE_INT) ) {
                    alt129=1;
                }
            }
            switch (alt129) {
                case 1 :
                    // InternalUmlModel.g:5475:4: otherlv_4= ',' ( (lv_topicNumber_5_0= RULE_INT ) ) (otherlv_6= ',' ( (lv_subtopicnumber_7_0= RULE_INT ) ) )?
                    {
                    otherlv_4=(Token)match(input,16,FOLLOW_6); 

                    				newLeafNode(otherlv_4, grammarAccess.getCtFieldAccess().getCommaKeyword_4_0());
                    			
                    // InternalUmlModel.g:5479:4: ( (lv_topicNumber_5_0= RULE_INT ) )
                    // InternalUmlModel.g:5480:5: (lv_topicNumber_5_0= RULE_INT )
                    {
                    // InternalUmlModel.g:5480:5: (lv_topicNumber_5_0= RULE_INT )
                    // InternalUmlModel.g:5481:6: lv_topicNumber_5_0= RULE_INT
                    {
                    lv_topicNumber_5_0=(Token)match(input,RULE_INT,FOLLOW_11); 

                    						newLeafNode(lv_topicNumber_5_0, grammarAccess.getCtFieldAccess().getTopicNumberINTTerminalRuleCall_4_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtFieldRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"topicNumber",
                    							lv_topicNumber_5_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    // InternalUmlModel.g:5497:4: (otherlv_6= ',' ( (lv_subtopicnumber_7_0= RULE_INT ) ) )?
                    int alt128=2;
                    int LA128_0 = input.LA(1);

                    if ( (LA128_0==16) ) {
                        int LA128_1 = input.LA(2);

                        if ( (LA128_1==RULE_INT) ) {
                            alt128=1;
                        }
                    }
                    switch (alt128) {
                        case 1 :
                            // InternalUmlModel.g:5498:5: otherlv_6= ',' ( (lv_subtopicnumber_7_0= RULE_INT ) )
                            {
                            otherlv_6=(Token)match(input,16,FOLLOW_6); 

                            					newLeafNode(otherlv_6, grammarAccess.getCtFieldAccess().getCommaKeyword_4_2_0());
                            				
                            // InternalUmlModel.g:5502:5: ( (lv_subtopicnumber_7_0= RULE_INT ) )
                            // InternalUmlModel.g:5503:6: (lv_subtopicnumber_7_0= RULE_INT )
                            {
                            // InternalUmlModel.g:5503:6: (lv_subtopicnumber_7_0= RULE_INT )
                            // InternalUmlModel.g:5504:7: lv_subtopicnumber_7_0= RULE_INT
                            {
                            lv_subtopicnumber_7_0=(Token)match(input,RULE_INT,FOLLOW_11); 

                            							newLeafNode(lv_subtopicnumber_7_0, grammarAccess.getCtFieldAccess().getSubtopicnumberINTTerminalRuleCall_4_2_1_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getCtFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"subtopicnumber",
                            								lv_subtopicnumber_7_0,
                            								"org.eclipse.xtext.common.Terminals.INT");
                            						

                            }


                            }


                            }
                            break;

                    }


                    }
                    break;

            }

            otherlv_8=(Token)match(input,16,FOLLOW_10); 

            			newLeafNode(otherlv_8, grammarAccess.getCtFieldAccess().getCommaKeyword_5());
            		
            // InternalUmlModel.g:5526:3: ( (lv_description_9_0= RULE_STRING ) )
            // InternalUmlModel.g:5527:4: (lv_description_9_0= RULE_STRING )
            {
            // InternalUmlModel.g:5527:4: (lv_description_9_0= RULE_STRING )
            // InternalUmlModel.g:5528:5: lv_description_9_0= RULE_STRING
            {
            lv_description_9_0=(Token)match(input,RULE_STRING,FOLLOW_91); 

            					newLeafNode(lv_description_9_0, grammarAccess.getCtFieldAccess().getDescriptionSTRINGTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtFieldRule());
            					}
            					setWithLastConsumed(
            						current,
            						"description",
            						lv_description_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_10=(Token)match(input,79,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getCtFieldAccess().getRightParenthesisKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectField"


    // $ANTLR start "entryRulectDate"
    // InternalUmlModel.g:5552:1: entryRulectDate returns [EObject current=null] : iv_rulectDate= rulectDate EOF ;
    public final EObject entryRulectDate() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectDate = null;


        try {
            // InternalUmlModel.g:5552:47: (iv_rulectDate= rulectDate EOF )
            // InternalUmlModel.g:5553:2: iv_rulectDate= rulectDate EOF
            {
             newCompositeNode(grammarAccess.getCtDateRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectDate=rulectDate();

            state._fsp--;

             current =iv_rulectDate; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectDate"


    // $ANTLR start "rulectDate"
    // InternalUmlModel.g:5559:1: rulectDate returns [EObject current=null] : ( (lv_date_0_0= ruleDATE ) ) ;
    public final EObject rulectDate() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_date_0_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:5565:2: ( ( (lv_date_0_0= ruleDATE ) ) )
            // InternalUmlModel.g:5566:2: ( (lv_date_0_0= ruleDATE ) )
            {
            // InternalUmlModel.g:5566:2: ( (lv_date_0_0= ruleDATE ) )
            // InternalUmlModel.g:5567:3: (lv_date_0_0= ruleDATE )
            {
            // InternalUmlModel.g:5567:3: (lv_date_0_0= ruleDATE )
            // InternalUmlModel.g:5568:4: lv_date_0_0= ruleDATE
            {

            				newCompositeNode(grammarAccess.getCtDateAccess().getDateDATEParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_date_0_0=ruleDATE();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getCtDateRule());
            				}
            				set(
            					current,
            					"date",
            					lv_date_0_0,
            					"tesma.ovanes.UmlModel.DATE");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectDate"


    // $ANTLR start "entryRulectTime"
    // InternalUmlModel.g:5588:1: entryRulectTime returns [EObject current=null] : iv_rulectTime= rulectTime EOF ;
    public final EObject entryRulectTime() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectTime = null;


        try {
            // InternalUmlModel.g:5588:47: (iv_rulectTime= rulectTime EOF )
            // InternalUmlModel.g:5589:2: iv_rulectTime= rulectTime EOF
            {
             newCompositeNode(grammarAccess.getCtTimeRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectTime=rulectTime();

            state._fsp--;

             current =iv_rulectTime; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectTime"


    // $ANTLR start "rulectTime"
    // InternalUmlModel.g:5595:1: rulectTime returns [EObject current=null] : ( (lv_time_0_0= ruleTIME ) ) ;
    public final EObject rulectTime() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_time_0_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:5601:2: ( ( (lv_time_0_0= ruleTIME ) ) )
            // InternalUmlModel.g:5602:2: ( (lv_time_0_0= ruleTIME ) )
            {
            // InternalUmlModel.g:5602:2: ( (lv_time_0_0= ruleTIME ) )
            // InternalUmlModel.g:5603:3: (lv_time_0_0= ruleTIME )
            {
            // InternalUmlModel.g:5603:3: (lv_time_0_0= ruleTIME )
            // InternalUmlModel.g:5604:4: lv_time_0_0= ruleTIME
            {

            				newCompositeNode(grammarAccess.getCtTimeAccess().getTimeTIMEParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_time_0_0=ruleTIME();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getCtTimeRule());
            				}
            				set(
            					current,
            					"time",
            					lv_time_0_0,
            					"tesma.ovanes.UmlModel.TIME");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectTime"


    // $ANTLR start "entryRulectTerm"
    // InternalUmlModel.g:5624:1: entryRulectTerm returns [EObject current=null] : iv_rulectTerm= rulectTerm EOF ;
    public final EObject entryRulectTerm() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectTerm = null;


        try {
            // InternalUmlModel.g:5624:47: (iv_rulectTerm= rulectTerm EOF )
            // InternalUmlModel.g:5625:2: iv_rulectTerm= rulectTerm EOF
            {
             newCompositeNode(grammarAccess.getCtTermRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectTerm=rulectTerm();

            state._fsp--;

             current =iv_rulectTerm; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectTerm"


    // $ANTLR start "rulectTerm"
    // InternalUmlModel.g:5631:1: rulectTerm returns [EObject current=null] : (otherlv_0= 'Term' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'referenced' ( (lv_reference_3_0= ruleREFERENCE ) ) otherlv_4= '{' ( (lv_modules_5_0= rulectModule ) )* otherlv_6= '}' ) ;
    public final EObject rulectTerm() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_reference_3_0 = null;

        EObject lv_modules_5_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:5637:2: ( (otherlv_0= 'Term' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'referenced' ( (lv_reference_3_0= ruleREFERENCE ) ) otherlv_4= '{' ( (lv_modules_5_0= rulectModule ) )* otherlv_6= '}' ) )
            // InternalUmlModel.g:5638:2: (otherlv_0= 'Term' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'referenced' ( (lv_reference_3_0= ruleREFERENCE ) ) otherlv_4= '{' ( (lv_modules_5_0= rulectModule ) )* otherlv_6= '}' )
            {
            // InternalUmlModel.g:5638:2: (otherlv_0= 'Term' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'referenced' ( (lv_reference_3_0= ruleREFERENCE ) ) otherlv_4= '{' ( (lv_modules_5_0= rulectModule ) )* otherlv_6= '}' )
            // InternalUmlModel.g:5639:3: otherlv_0= 'Term' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'referenced' ( (lv_reference_3_0= ruleREFERENCE ) ) otherlv_4= '{' ( (lv_modules_5_0= rulectModule ) )* otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,102,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtTermAccess().getTermKeyword_0());
            		
            // InternalUmlModel.g:5643:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:5644:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:5644:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:5645:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_130); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtTermAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtTermRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,103,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getCtTermAccess().getReferencedKeyword_2());
            		
            // InternalUmlModel.g:5665:3: ( (lv_reference_3_0= ruleREFERENCE ) )
            // InternalUmlModel.g:5666:4: (lv_reference_3_0= ruleREFERENCE )
            {
            // InternalUmlModel.g:5666:4: (lv_reference_3_0= ruleREFERENCE )
            // InternalUmlModel.g:5667:5: lv_reference_3_0= ruleREFERENCE
            {

            					newCompositeNode(grammarAccess.getCtTermAccess().getReferenceREFERENCEParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_47);
            lv_reference_3_0=ruleREFERENCE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCtTermRule());
            					}
            					set(
            						current,
            						"reference",
            						lv_reference_3_0,
            						"tesma.ovanes.UmlModel.REFERENCE");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,20,FOLLOW_60); 

            			newLeafNode(otherlv_4, grammarAccess.getCtTermAccess().getLeftCurlyBracketKeyword_4());
            		
            // InternalUmlModel.g:5688:3: ( (lv_modules_5_0= rulectModule ) )*
            loop130:
            do {
                int alt130=2;
                int LA130_0 = input.LA(1);

                if ( (LA130_0==104) ) {
                    alt130=1;
                }


                switch (alt130) {
            	case 1 :
            	    // InternalUmlModel.g:5689:4: (lv_modules_5_0= rulectModule )
            	    {
            	    // InternalUmlModel.g:5689:4: (lv_modules_5_0= rulectModule )
            	    // InternalUmlModel.g:5690:5: lv_modules_5_0= rulectModule
            	    {

            	    					newCompositeNode(grammarAccess.getCtTermAccess().getModulesCtModuleParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_60);
            	    lv_modules_5_0=rulectModule();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getCtTermRule());
            	    					}
            	    					add(
            	    						current,
            	    						"modules",
            	    						lv_modules_5_0,
            	    						"tesma.ovanes.UmlModel.ctModule");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop130;
                }
            } while (true);

            otherlv_6=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getCtTermAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectTerm"


    // $ANTLR start "entryRulectModule"
    // InternalUmlModel.g:5715:1: entryRulectModule returns [EObject current=null] : iv_rulectModule= rulectModule EOF ;
    public final EObject entryRulectModule() throws RecognitionException {
        EObject current = null;

        EObject iv_rulectModule = null;


        try {
            // InternalUmlModel.g:5715:49: (iv_rulectModule= rulectModule EOF )
            // InternalUmlModel.g:5716:2: iv_rulectModule= rulectModule EOF
            {
             newCompositeNode(grammarAccess.getCtModuleRule()); 
            pushFollow(FOLLOW_1);
            iv_rulectModule=rulectModule();

            state._fsp--;

             current =iv_rulectModule; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulectModule"


    // $ANTLR start "rulectModule"
    // InternalUmlModel.g:5722:1: rulectModule returns [EObject current=null] : (otherlv_0= 'Module' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'referenced' ( (lv_reference_3_0= ruleREFERENCE ) ) (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? ) ;
    public final EObject rulectModule() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_reference_3_0 = null;



        	enterRule();

        try {
            // InternalUmlModel.g:5728:2: ( (otherlv_0= 'Module' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'referenced' ( (lv_reference_3_0= ruleREFERENCE ) ) (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? ) )
            // InternalUmlModel.g:5729:2: (otherlv_0= 'Module' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'referenced' ( (lv_reference_3_0= ruleREFERENCE ) ) (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? )
            {
            // InternalUmlModel.g:5729:2: (otherlv_0= 'Module' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'referenced' ( (lv_reference_3_0= ruleREFERENCE ) ) (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )? )
            // InternalUmlModel.g:5730:3: otherlv_0= 'Module' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'referenced' ( (lv_reference_3_0= ruleREFERENCE ) ) (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )?
            {
            otherlv_0=(Token)match(input,104,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCtModuleAccess().getModuleKeyword_0());
            		
            // InternalUmlModel.g:5734:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalUmlModel.g:5735:4: (lv_name_1_0= RULE_ID )
            {
            // InternalUmlModel.g:5735:4: (lv_name_1_0= RULE_ID )
            // InternalUmlModel.g:5736:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_130); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCtModuleAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCtModuleRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,103,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getCtModuleAccess().getReferencedKeyword_2());
            		
            // InternalUmlModel.g:5756:3: ( (lv_reference_3_0= ruleREFERENCE ) )
            // InternalUmlModel.g:5757:4: (lv_reference_3_0= ruleREFERENCE )
            {
            // InternalUmlModel.g:5757:4: (lv_reference_3_0= ruleREFERENCE )
            // InternalUmlModel.g:5758:5: lv_reference_3_0= ruleREFERENCE
            {

            					newCompositeNode(grammarAccess.getCtModuleAccess().getReferenceREFERENCEParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_131);
            lv_reference_3_0=ruleREFERENCE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCtModuleRule());
            					}
            					set(
            						current,
            						"reference",
            						lv_reference_3_0,
            						"tesma.ovanes.UmlModel.REFERENCE");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalUmlModel.g:5775:3: (otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )* )?
            int alt132=2;
            int LA132_0 = input.LA(1);

            if ( (LA132_0==25) ) {
                alt132=1;
            }
            switch (alt132) {
                case 1 :
                    // InternalUmlModel.g:5776:4: otherlv_4= 'contains' ( ( ruleFQN ) ) (otherlv_6= ',' ( ( ruleFQN ) ) )*
                    {
                    otherlv_4=(Token)match(input,25,FOLLOW_4); 

                    				newLeafNode(otherlv_4, grammarAccess.getCtModuleAccess().getContainsKeyword_4_0());
                    			
                    // InternalUmlModel.g:5780:4: ( ( ruleFQN ) )
                    // InternalUmlModel.g:5781:5: ( ruleFQN )
                    {
                    // InternalUmlModel.g:5781:5: ( ruleFQN )
                    // InternalUmlModel.g:5782:6: ruleFQN
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCtModuleRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCtModuleAccess().getCoursesCtCourseCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_112);
                    ruleFQN();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalUmlModel.g:5796:4: (otherlv_6= ',' ( ( ruleFQN ) ) )*
                    loop131:
                    do {
                        int alt131=2;
                        int LA131_0 = input.LA(1);

                        if ( (LA131_0==16) ) {
                            alt131=1;
                        }


                        switch (alt131) {
                    	case 1 :
                    	    // InternalUmlModel.g:5797:5: otherlv_6= ',' ( ( ruleFQN ) )
                    	    {
                    	    otherlv_6=(Token)match(input,16,FOLLOW_4); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getCtModuleAccess().getCommaKeyword_4_2_0());
                    	    				
                    	    // InternalUmlModel.g:5801:5: ( ( ruleFQN ) )
                    	    // InternalUmlModel.g:5802:6: ( ruleFQN )
                    	    {
                    	    // InternalUmlModel.g:5802:6: ( ruleFQN )
                    	    // InternalUmlModel.g:5803:7: ruleFQN
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCtModuleRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCtModuleAccess().getCoursesCtCourseCrossReference_4_2_1_0());
                    	    						
                    	    pushFollow(FOLLOW_112);
                    	    ruleFQN();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop131;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulectModule"


    // $ANTLR start "entryRuleLANGUAGE"
    // InternalUmlModel.g:5823:1: entryRuleLANGUAGE returns [String current=null] : iv_ruleLANGUAGE= ruleLANGUAGE EOF ;
    public final String entryRuleLANGUAGE() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleLANGUAGE = null;


        try {
            // InternalUmlModel.g:5823:48: (iv_ruleLANGUAGE= ruleLANGUAGE EOF )
            // InternalUmlModel.g:5824:2: iv_ruleLANGUAGE= ruleLANGUAGE EOF
            {
             newCompositeNode(grammarAccess.getLANGUAGERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLANGUAGE=ruleLANGUAGE();

            state._fsp--;

             current =iv_ruleLANGUAGE.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLANGUAGE"


    // $ANTLR start "ruleLANGUAGE"
    // InternalUmlModel.g:5830:1: ruleLANGUAGE returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_STRING_0= RULE_STRING ;
    public final AntlrDatatypeRuleToken ruleLANGUAGE() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;


        	enterRule();

        try {
            // InternalUmlModel.g:5836:2: (this_STRING_0= RULE_STRING )
            // InternalUmlModel.g:5837:2: this_STRING_0= RULE_STRING
            {
            this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            		current.merge(this_STRING_0);
            	

            		newLeafNode(this_STRING_0, grammarAccess.getLANGUAGEAccess().getSTRINGTerminalRuleCall());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLANGUAGE"


    // $ANTLR start "entryRuleHIDDEN"
    // InternalUmlModel.g:5847:1: entryRuleHIDDEN returns [String current=null] : iv_ruleHIDDEN= ruleHIDDEN EOF ;
    public final String entryRuleHIDDEN() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleHIDDEN = null;


        try {
            // InternalUmlModel.g:5847:46: (iv_ruleHIDDEN= ruleHIDDEN EOF )
            // InternalUmlModel.g:5848:2: iv_ruleHIDDEN= ruleHIDDEN EOF
            {
             newCompositeNode(grammarAccess.getHIDDENRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleHIDDEN=ruleHIDDEN();

            state._fsp--;

             current =iv_ruleHIDDEN.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHIDDEN"


    // $ANTLR start "ruleHIDDEN"
    // InternalUmlModel.g:5854:1: ruleHIDDEN returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'hide' ;
    public final AntlrDatatypeRuleToken ruleHIDDEN() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalUmlModel.g:5860:2: (kw= 'hide' )
            // InternalUmlModel.g:5861:2: kw= 'hide'
            {
            kw=(Token)match(input,105,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getHIDDENAccess().getHideKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHIDDEN"


    // $ANTLR start "entryRuleNATUREOFCOURSE"
    // InternalUmlModel.g:5869:1: entryRuleNATUREOFCOURSE returns [String current=null] : iv_ruleNATUREOFCOURSE= ruleNATUREOFCOURSE EOF ;
    public final String entryRuleNATUREOFCOURSE() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleNATUREOFCOURSE = null;


        try {
            // InternalUmlModel.g:5869:54: (iv_ruleNATUREOFCOURSE= ruleNATUREOFCOURSE EOF )
            // InternalUmlModel.g:5870:2: iv_ruleNATUREOFCOURSE= ruleNATUREOFCOURSE EOF
            {
             newCompositeNode(grammarAccess.getNATUREOFCOURSERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNATUREOFCOURSE=ruleNATUREOFCOURSE();

            state._fsp--;

             current =iv_ruleNATUREOFCOURSE.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNATUREOFCOURSE"


    // $ANTLR start "ruleNATUREOFCOURSE"
    // InternalUmlModel.g:5876:1: ruleNATUREOFCOURSE returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'required' | kw= 'elective' ) ;
    public final AntlrDatatypeRuleToken ruleNATUREOFCOURSE() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalUmlModel.g:5882:2: ( (kw= 'required' | kw= 'elective' ) )
            // InternalUmlModel.g:5883:2: (kw= 'required' | kw= 'elective' )
            {
            // InternalUmlModel.g:5883:2: (kw= 'required' | kw= 'elective' )
            int alt133=2;
            int LA133_0 = input.LA(1);

            if ( (LA133_0==106) ) {
                alt133=1;
            }
            else if ( (LA133_0==107) ) {
                alt133=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 133, 0, input);

                throw nvae;
            }
            switch (alt133) {
                case 1 :
                    // InternalUmlModel.g:5884:3: kw= 'required'
                    {
                    kw=(Token)match(input,106,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getNATUREOFCOURSEAccess().getRequiredKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalUmlModel.g:5890:3: kw= 'elective'
                    {
                    kw=(Token)match(input,107,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getNATUREOFCOURSEAccess().getElectiveKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNATUREOFCOURSE"


    // $ANTLR start "entryRuleTASKTYPE"
    // InternalUmlModel.g:5899:1: entryRuleTASKTYPE returns [String current=null] : iv_ruleTASKTYPE= ruleTASKTYPE EOF ;
    public final String entryRuleTASKTYPE() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTASKTYPE = null;


        try {
            // InternalUmlModel.g:5899:48: (iv_ruleTASKTYPE= ruleTASKTYPE EOF )
            // InternalUmlModel.g:5900:2: iv_ruleTASKTYPE= ruleTASKTYPE EOF
            {
             newCompositeNode(grammarAccess.getTASKTYPERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTASKTYPE=ruleTASKTYPE();

            state._fsp--;

             current =iv_ruleTASKTYPE.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTASKTYPE"


    // $ANTLR start "ruleTASKTYPE"
    // InternalUmlModel.g:5906:1: ruleTASKTYPE returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'lecture' | kw= 'directed_work' | kw= 'written_exam' | kw= 'mid-term_exam' | kw= 'oral_exam' | kw= 'seminar_paper' | kw= 'project' | kw= 'presentation' | kw= 'exercises' | kw= 'other' | kw= 'no_assessment' ) ;
    public final AntlrDatatypeRuleToken ruleTASKTYPE() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalUmlModel.g:5912:2: ( (kw= 'lecture' | kw= 'directed_work' | kw= 'written_exam' | kw= 'mid-term_exam' | kw= 'oral_exam' | kw= 'seminar_paper' | kw= 'project' | kw= 'presentation' | kw= 'exercises' | kw= 'other' | kw= 'no_assessment' ) )
            // InternalUmlModel.g:5913:2: (kw= 'lecture' | kw= 'directed_work' | kw= 'written_exam' | kw= 'mid-term_exam' | kw= 'oral_exam' | kw= 'seminar_paper' | kw= 'project' | kw= 'presentation' | kw= 'exercises' | kw= 'other' | kw= 'no_assessment' )
            {
            // InternalUmlModel.g:5913:2: (kw= 'lecture' | kw= 'directed_work' | kw= 'written_exam' | kw= 'mid-term_exam' | kw= 'oral_exam' | kw= 'seminar_paper' | kw= 'project' | kw= 'presentation' | kw= 'exercises' | kw= 'other' | kw= 'no_assessment' )
            int alt134=11;
            switch ( input.LA(1) ) {
            case 108:
                {
                alt134=1;
                }
                break;
            case 109:
                {
                alt134=2;
                }
                break;
            case 110:
                {
                alt134=3;
                }
                break;
            case 111:
                {
                alt134=4;
                }
                break;
            case 112:
                {
                alt134=5;
                }
                break;
            case 113:
                {
                alt134=6;
                }
                break;
            case 114:
                {
                alt134=7;
                }
                break;
            case 115:
                {
                alt134=8;
                }
                break;
            case 116:
                {
                alt134=9;
                }
                break;
            case 117:
                {
                alt134=10;
                }
                break;
            case 118:
                {
                alt134=11;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 134, 0, input);

                throw nvae;
            }

            switch (alt134) {
                case 1 :
                    // InternalUmlModel.g:5914:3: kw= 'lecture'
                    {
                    kw=(Token)match(input,108,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getLectureKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalUmlModel.g:5920:3: kw= 'directed_work'
                    {
                    kw=(Token)match(input,109,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getDirected_workKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalUmlModel.g:5926:3: kw= 'written_exam'
                    {
                    kw=(Token)match(input,110,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getWritten_examKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalUmlModel.g:5932:3: kw= 'mid-term_exam'
                    {
                    kw=(Token)match(input,111,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getMidTerm_examKeyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalUmlModel.g:5938:3: kw= 'oral_exam'
                    {
                    kw=(Token)match(input,112,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getOral_examKeyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalUmlModel.g:5944:3: kw= 'seminar_paper'
                    {
                    kw=(Token)match(input,113,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getSeminar_paperKeyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalUmlModel.g:5950:3: kw= 'project'
                    {
                    kw=(Token)match(input,114,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getProjectKeyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalUmlModel.g:5956:3: kw= 'presentation'
                    {
                    kw=(Token)match(input,115,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getPresentationKeyword_7());
                    		

                    }
                    break;
                case 9 :
                    // InternalUmlModel.g:5962:3: kw= 'exercises'
                    {
                    kw=(Token)match(input,116,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getExercisesKeyword_8());
                    		

                    }
                    break;
                case 10 :
                    // InternalUmlModel.g:5968:3: kw= 'other'
                    {
                    kw=(Token)match(input,117,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getOtherKeyword_9());
                    		

                    }
                    break;
                case 11 :
                    // InternalUmlModel.g:5974:3: kw= 'no_assessment'
                    {
                    kw=(Token)match(input,118,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKTYPEAccess().getNo_assessmentKeyword_10());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTASKTYPE"


    // $ANTLR start "entryRuleSUBCOURSETYPE"
    // InternalUmlModel.g:5983:1: entryRuleSUBCOURSETYPE returns [String current=null] : iv_ruleSUBCOURSETYPE= ruleSUBCOURSETYPE EOF ;
    public final String entryRuleSUBCOURSETYPE() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleSUBCOURSETYPE = null;


        try {
            // InternalUmlModel.g:5983:53: (iv_ruleSUBCOURSETYPE= ruleSUBCOURSETYPE EOF )
            // InternalUmlModel.g:5984:2: iv_ruleSUBCOURSETYPE= ruleSUBCOURSETYPE EOF
            {
             newCompositeNode(grammarAccess.getSUBCOURSETYPERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSUBCOURSETYPE=ruleSUBCOURSETYPE();

            state._fsp--;

             current =iv_ruleSUBCOURSETYPE.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSUBCOURSETYPE"


    // $ANTLR start "ruleSUBCOURSETYPE"
    // InternalUmlModel.g:5990:1: ruleSUBCOURSETYPE returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'lecture' | kw= 'practical' | kw= 'tutorial' | kw= 'other' ) ;
    public final AntlrDatatypeRuleToken ruleSUBCOURSETYPE() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalUmlModel.g:5996:2: ( (kw= 'lecture' | kw= 'practical' | kw= 'tutorial' | kw= 'other' ) )
            // InternalUmlModel.g:5997:2: (kw= 'lecture' | kw= 'practical' | kw= 'tutorial' | kw= 'other' )
            {
            // InternalUmlModel.g:5997:2: (kw= 'lecture' | kw= 'practical' | kw= 'tutorial' | kw= 'other' )
            int alt135=4;
            switch ( input.LA(1) ) {
            case 108:
                {
                alt135=1;
                }
                break;
            case 119:
                {
                alt135=2;
                }
                break;
            case 120:
                {
                alt135=3;
                }
                break;
            case 117:
                {
                alt135=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 135, 0, input);

                throw nvae;
            }

            switch (alt135) {
                case 1 :
                    // InternalUmlModel.g:5998:3: kw= 'lecture'
                    {
                    kw=(Token)match(input,108,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getSUBCOURSETYPEAccess().getLectureKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalUmlModel.g:6004:3: kw= 'practical'
                    {
                    kw=(Token)match(input,119,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getSUBCOURSETYPEAccess().getPracticalKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalUmlModel.g:6010:3: kw= 'tutorial'
                    {
                    kw=(Token)match(input,120,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getSUBCOURSETYPEAccess().getTutorialKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalUmlModel.g:6016:3: kw= 'other'
                    {
                    kw=(Token)match(input,117,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getSUBCOURSETYPEAccess().getOtherKeyword_3());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSUBCOURSETYPE"


    // $ANTLR start "entryRuleARTEFACTTYPE"
    // InternalUmlModel.g:6025:1: entryRuleARTEFACTTYPE returns [String current=null] : iv_ruleARTEFACTTYPE= ruleARTEFACTTYPE EOF ;
    public final String entryRuleARTEFACTTYPE() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleARTEFACTTYPE = null;


        try {
            // InternalUmlModel.g:6025:52: (iv_ruleARTEFACTTYPE= ruleARTEFACTTYPE EOF )
            // InternalUmlModel.g:6026:2: iv_ruleARTEFACTTYPE= ruleARTEFACTTYPE EOF
            {
             newCompositeNode(grammarAccess.getARTEFACTTYPERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleARTEFACTTYPE=ruleARTEFACTTYPE();

            state._fsp--;

             current =iv_ruleARTEFACTTYPE.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleARTEFACTTYPE"


    // $ANTLR start "ruleARTEFACTTYPE"
    // InternalUmlModel.g:6032:1: ruleARTEFACTTYPE returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'output' | kw= 'input' ) ;
    public final AntlrDatatypeRuleToken ruleARTEFACTTYPE() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalUmlModel.g:6038:2: ( (kw= 'output' | kw= 'input' ) )
            // InternalUmlModel.g:6039:2: (kw= 'output' | kw= 'input' )
            {
            // InternalUmlModel.g:6039:2: (kw= 'output' | kw= 'input' )
            int alt136=2;
            int LA136_0 = input.LA(1);

            if ( (LA136_0==121) ) {
                alt136=1;
            }
            else if ( (LA136_0==122) ) {
                alt136=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 136, 0, input);

                throw nvae;
            }
            switch (alt136) {
                case 1 :
                    // InternalUmlModel.g:6040:3: kw= 'output'
                    {
                    kw=(Token)match(input,121,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getARTEFACTTYPEAccess().getOutputKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalUmlModel.g:6046:3: kw= 'input'
                    {
                    kw=(Token)match(input,122,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getARTEFACTTYPEAccess().getInputKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleARTEFACTTYPE"


    // $ANTLR start "entryRuleTASKCONCERNED"
    // InternalUmlModel.g:6055:1: entryRuleTASKCONCERNED returns [String current=null] : iv_ruleTASKCONCERNED= ruleTASKCONCERNED EOF ;
    public final String entryRuleTASKCONCERNED() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTASKCONCERNED = null;


        try {
            // InternalUmlModel.g:6055:53: (iv_ruleTASKCONCERNED= ruleTASKCONCERNED EOF )
            // InternalUmlModel.g:6056:2: iv_ruleTASKCONCERNED= ruleTASKCONCERNED EOF
            {
             newCompositeNode(grammarAccess.getTASKCONCERNEDRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTASKCONCERNED=ruleTASKCONCERNED();

            state._fsp--;

             current =iv_ruleTASKCONCERNED.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTASKCONCERNED"


    // $ANTLR start "ruleTASKCONCERNED"
    // InternalUmlModel.g:6062:1: ruleTASKCONCERNED returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'instructor' | kw= 'student' ) ;
    public final AntlrDatatypeRuleToken ruleTASKCONCERNED() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalUmlModel.g:6068:2: ( (kw= 'instructor' | kw= 'student' ) )
            // InternalUmlModel.g:6069:2: (kw= 'instructor' | kw= 'student' )
            {
            // InternalUmlModel.g:6069:2: (kw= 'instructor' | kw= 'student' )
            int alt137=2;
            int LA137_0 = input.LA(1);

            if ( (LA137_0==75) ) {
                alt137=1;
            }
            else if ( (LA137_0==123) ) {
                alt137=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 137, 0, input);

                throw nvae;
            }
            switch (alt137) {
                case 1 :
                    // InternalUmlModel.g:6070:3: kw= 'instructor'
                    {
                    kw=(Token)match(input,75,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKCONCERNEDAccess().getInstructorKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalUmlModel.g:6076:3: kw= 'student'
                    {
                    kw=(Token)match(input,123,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTASKCONCERNEDAccess().getStudentKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTASKCONCERNED"


    // $ANTLR start "entryRuleTIME"
    // InternalUmlModel.g:6085:1: entryRuleTIME returns [String current=null] : iv_ruleTIME= ruleTIME EOF ;
    public final String entryRuleTIME() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTIME = null;


        try {
            // InternalUmlModel.g:6085:44: (iv_ruleTIME= ruleTIME EOF )
            // InternalUmlModel.g:6086:2: iv_ruleTIME= ruleTIME EOF
            {
             newCompositeNode(grammarAccess.getTIMERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTIME=ruleTIME();

            state._fsp--;

             current =iv_ruleTIME.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTIME"


    // $ANTLR start "ruleTIME"
    // InternalUmlModel.g:6092:1: ruleTIME returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_INT_0= RULE_INT kw= ':' this_INT_2= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleTIME() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;
        Token kw=null;
        Token this_INT_2=null;


        	enterRule();

        try {
            // InternalUmlModel.g:6098:2: ( (this_INT_0= RULE_INT kw= ':' this_INT_2= RULE_INT ) )
            // InternalUmlModel.g:6099:2: (this_INT_0= RULE_INT kw= ':' this_INT_2= RULE_INT )
            {
            // InternalUmlModel.g:6099:2: (this_INT_0= RULE_INT kw= ':' this_INT_2= RULE_INT )
            // InternalUmlModel.g:6100:3: this_INT_0= RULE_INT kw= ':' this_INT_2= RULE_INT
            {
            this_INT_0=(Token)match(input,RULE_INT,FOLLOW_16); 

            			current.merge(this_INT_0);
            		

            			newLeafNode(this_INT_0, grammarAccess.getTIMEAccess().getINTTerminalRuleCall_0());
            		
            kw=(Token)match(input,22,FOLLOW_6); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getTIMEAccess().getColonKeyword_1());
            		
            this_INT_2=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_2);
            		

            			newLeafNode(this_INT_2, grammarAccess.getTIMEAccess().getINTTerminalRuleCall_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTIME"


    // $ANTLR start "entryRuleDATE"
    // InternalUmlModel.g:6123:1: entryRuleDATE returns [String current=null] : iv_ruleDATE= ruleDATE EOF ;
    public final String entryRuleDATE() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleDATE = null;


        try {
            // InternalUmlModel.g:6123:44: (iv_ruleDATE= ruleDATE EOF )
            // InternalUmlModel.g:6124:2: iv_ruleDATE= ruleDATE EOF
            {
             newCompositeNode(grammarAccess.getDATERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDATE=ruleDATE();

            state._fsp--;

             current =iv_ruleDATE.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDATE"


    // $ANTLR start "ruleDATE"
    // InternalUmlModel.g:6130:1: ruleDATE returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_INT_0= RULE_INT (kw= '.' this_INT_2= RULE_INT ) (kw= '.' this_INT_4= RULE_INT ) ) ;
    public final AntlrDatatypeRuleToken ruleDATE() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;
        Token kw=null;
        Token this_INT_2=null;
        Token this_INT_4=null;


        	enterRule();

        try {
            // InternalUmlModel.g:6136:2: ( (this_INT_0= RULE_INT (kw= '.' this_INT_2= RULE_INT ) (kw= '.' this_INT_4= RULE_INT ) ) )
            // InternalUmlModel.g:6137:2: (this_INT_0= RULE_INT (kw= '.' this_INT_2= RULE_INT ) (kw= '.' this_INT_4= RULE_INT ) )
            {
            // InternalUmlModel.g:6137:2: (this_INT_0= RULE_INT (kw= '.' this_INT_2= RULE_INT ) (kw= '.' this_INT_4= RULE_INT ) )
            // InternalUmlModel.g:6138:3: this_INT_0= RULE_INT (kw= '.' this_INT_2= RULE_INT ) (kw= '.' this_INT_4= RULE_INT )
            {
            this_INT_0=(Token)match(input,RULE_INT,FOLLOW_132); 

            			current.merge(this_INT_0);
            		

            			newLeafNode(this_INT_0, grammarAccess.getDATEAccess().getINTTerminalRuleCall_0());
            		
            // InternalUmlModel.g:6145:3: (kw= '.' this_INT_2= RULE_INT )
            // InternalUmlModel.g:6146:4: kw= '.' this_INT_2= RULE_INT
            {
            kw=(Token)match(input,124,FOLLOW_6); 

            				current.merge(kw);
            				newLeafNode(kw, grammarAccess.getDATEAccess().getFullStopKeyword_1_0());
            			
            this_INT_2=(Token)match(input,RULE_INT,FOLLOW_132); 

            				current.merge(this_INT_2);
            			

            				newLeafNode(this_INT_2, grammarAccess.getDATEAccess().getINTTerminalRuleCall_1_1());
            			

            }

            // InternalUmlModel.g:6159:3: (kw= '.' this_INT_4= RULE_INT )
            // InternalUmlModel.g:6160:4: kw= '.' this_INT_4= RULE_INT
            {
            kw=(Token)match(input,124,FOLLOW_6); 

            				current.merge(kw);
            				newLeafNode(kw, grammarAccess.getDATEAccess().getFullStopKeyword_2_0());
            			
            this_INT_4=(Token)match(input,RULE_INT,FOLLOW_2); 

            				current.merge(this_INT_4);
            			

            				newLeafNode(this_INT_4, grammarAccess.getDATEAccess().getINTTerminalRuleCall_2_1());
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDATE"


    // $ANTLR start "entryRuleREFERENCE"
    // InternalUmlModel.g:6177:1: entryRuleREFERENCE returns [String current=null] : iv_ruleREFERENCE= ruleREFERENCE EOF ;
    public final String entryRuleREFERENCE() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleREFERENCE = null;


        try {
            // InternalUmlModel.g:6177:49: (iv_ruleREFERENCE= ruleREFERENCE EOF )
            // InternalUmlModel.g:6178:2: iv_ruleREFERENCE= ruleREFERENCE EOF
            {
             newCompositeNode(grammarAccess.getREFERENCERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleREFERENCE=ruleREFERENCE();

            state._fsp--;

             current =iv_ruleREFERENCE.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleREFERENCE"


    // $ANTLR start "ruleREFERENCE"
    // InternalUmlModel.g:6184:1: ruleREFERENCE returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_INT_0= RULE_INT (kw= '.' this_INT_2= RULE_INT )* ) ;
    public final AntlrDatatypeRuleToken ruleREFERENCE() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;
        Token kw=null;
        Token this_INT_2=null;


        	enterRule();

        try {
            // InternalUmlModel.g:6190:2: ( (this_INT_0= RULE_INT (kw= '.' this_INT_2= RULE_INT )* ) )
            // InternalUmlModel.g:6191:2: (this_INT_0= RULE_INT (kw= '.' this_INT_2= RULE_INT )* )
            {
            // InternalUmlModel.g:6191:2: (this_INT_0= RULE_INT (kw= '.' this_INT_2= RULE_INT )* )
            // InternalUmlModel.g:6192:3: this_INT_0= RULE_INT (kw= '.' this_INT_2= RULE_INT )*
            {
            this_INT_0=(Token)match(input,RULE_INT,FOLLOW_133); 

            			current.merge(this_INT_0);
            		

            			newLeafNode(this_INT_0, grammarAccess.getREFERENCEAccess().getINTTerminalRuleCall_0());
            		
            // InternalUmlModel.g:6199:3: (kw= '.' this_INT_2= RULE_INT )*
            loop138:
            do {
                int alt138=2;
                int LA138_0 = input.LA(1);

                if ( (LA138_0==124) ) {
                    alt138=1;
                }


                switch (alt138) {
            	case 1 :
            	    // InternalUmlModel.g:6200:4: kw= '.' this_INT_2= RULE_INT
            	    {
            	    kw=(Token)match(input,124,FOLLOW_6); 

            	    				current.merge(kw);
            	    				newLeafNode(kw, grammarAccess.getREFERENCEAccess().getFullStopKeyword_1_0());
            	    			
            	    this_INT_2=(Token)match(input,RULE_INT,FOLLOW_133); 

            	    				current.merge(this_INT_2);
            	    			

            	    				newLeafNode(this_INT_2, grammarAccess.getREFERENCEAccess().getINTTerminalRuleCall_1_1());
            	    			

            	    }
            	    break;

            	default :
            	    break loop138;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleREFERENCE"


    // $ANTLR start "entryRuleFQN"
    // InternalUmlModel.g:6217:1: entryRuleFQN returns [String current=null] : iv_ruleFQN= ruleFQN EOF ;
    public final String entryRuleFQN() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleFQN = null;


        try {
            // InternalUmlModel.g:6217:43: (iv_ruleFQN= ruleFQN EOF )
            // InternalUmlModel.g:6218:2: iv_ruleFQN= ruleFQN EOF
            {
             newCompositeNode(grammarAccess.getFQNRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFQN=ruleFQN();

            state._fsp--;

             current =iv_ruleFQN.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFQN"


    // $ANTLR start "ruleFQN"
    // InternalUmlModel.g:6224:1: ruleFQN returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleFQN() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_2=null;


        	enterRule();

        try {
            // InternalUmlModel.g:6230:2: ( (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) )
            // InternalUmlModel.g:6231:2: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            {
            // InternalUmlModel.g:6231:2: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            // InternalUmlModel.g:6232:3: this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_133); 

            			current.merge(this_ID_0);
            		

            			newLeafNode(this_ID_0, grammarAccess.getFQNAccess().getIDTerminalRuleCall_0());
            		
            // InternalUmlModel.g:6239:3: (kw= '.' this_ID_2= RULE_ID )*
            loop139:
            do {
                int alt139=2;
                int LA139_0 = input.LA(1);

                if ( (LA139_0==124) ) {
                    alt139=1;
                }


                switch (alt139) {
            	case 1 :
            	    // InternalUmlModel.g:6240:4: kw= '.' this_ID_2= RULE_ID
            	    {
            	    kw=(Token)match(input,124,FOLLOW_4); 

            	    				current.merge(kw);
            	    				newLeafNode(kw, grammarAccess.getFQNAccess().getFullStopKeyword_1_0());
            	    			
            	    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_133); 

            	    				current.merge(this_ID_2);
            	    			

            	    				newLeafNode(this_ID_2, grammarAccess.getFQNAccess().getIDTerminalRuleCall_1_1());
            	    			

            	    }
            	    break;

            	default :
            	    break loop139;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFQN"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0040080409000802L,0x00000216C4000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000006000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000108000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000210000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000020040L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000002006002L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000016002L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000010100000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000110000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000368204000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000368200000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000348200000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000308210000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000208610000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000208210000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000008200000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000802100000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000002100000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000078000204000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000070000214000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000070000200000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000060000200000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000040000200000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000100802100000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000100002100000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000100000110000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000014000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0007800000000000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0007000000000000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0006000000000000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0008000000010000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0020000000200000L,0x0000014000000000L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000210000L,0x0000014000000000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0000000000200000L,0x0000014000000000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000200000L,0x0000010000000000L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000000000L,0x00000C0000000000L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0080100000100000L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0600000000000000L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x1000000000000000L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x6000000000000000L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x8000000000000000L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0010000000200000L,0x00000008000021FEL});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0010000000210000L,0x00000008000021FCL});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0000000000200000L,0x00000008000021FCL});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0000000000200000L,0x00000008000021F8L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000000000210000L,0x00000008000021F0L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000000000210000L,0x00000008000021E0L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x0000000000210000L,0x00000008000021C0L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0x0000000000210000L,0x0000000800002180L});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x0000000000200000L,0x0000000800002180L});
    public static final BitSet FOLLOW_82 = new BitSet(new long[]{0x0000000000200000L,0x0000000800002080L});
    public static final BitSet FOLLOW_83 = new BitSet(new long[]{0x0000000000210000L,0x0000000800000000L});
    public static final BitSet FOLLOW_84 = new BitSet(new long[]{0x0000000000200000L,0x0000000800000000L});
    public static final BitSet FOLLOW_85 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_86 = new BitSet(new long[]{0x0000000000000000L,0x01A0100000000000L});
    public static final BitSet FOLLOW_87 = new BitSet(new long[]{0x0000000000100000L,0x0000000000000400L});
    public static final BitSet FOLLOW_88 = new BitSet(new long[]{0x0000000000200000L,0x0000000000000800L});
    public static final BitSet FOLLOW_89 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_90 = new BitSet(new long[]{0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_91 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_92 = new BitSet(new long[]{0x0000000000100000L,0x0000000000010000L});
    public static final BitSet FOLLOW_93 = new BitSet(new long[]{0x0000000000100000L,0x0000000000060000L});
    public static final BitSet FOLLOW_94 = new BitSet(new long[]{0x0000000000100000L,0x0000000000040000L});
    public static final BitSet FOLLOW_95 = new BitSet(new long[]{0x0000000000100000L,0x0000000000080000L});
    public static final BitSet FOLLOW_96 = new BitSet(new long[]{0x0000000000200000L,0x0000000000102080L});
    public static final BitSet FOLLOW_97 = new BitSet(new long[]{0x0000000000210000L,0x0000000000102000L});
    public static final BitSet FOLLOW_98 = new BitSet(new long[]{0x0000000000210000L,0x0000000000002000L});
    public static final BitSet FOLLOW_99 = new BitSet(new long[]{0x0000000000200000L,0x0000000000002000L});
    public static final BitSet FOLLOW_100 = new BitSet(new long[]{0x0000000000000000L,0x0600000000000000L});
    public static final BitSet FOLLOW_101 = new BitSet(new long[]{0x0000000000200000L,0x0000000000800000L});
    public static final BitSet FOLLOW_102 = new BitSet(new long[]{0x0000000000200000L,0x0000000003000000L});
    public static final BitSet FOLLOW_103 = new BitSet(new long[]{0x0000000000210000L,0x0000000002000000L});
    public static final BitSet FOLLOW_104 = new BitSet(new long[]{0x0000000000200000L,0x0000000001000000L});
    public static final BitSet FOLLOW_105 = new BitSet(new long[]{0x0000000000200010L});
    public static final BitSet FOLLOW_106 = new BitSet(new long[]{0x0000000000200000L,0x0000000002000000L});
    public static final BitSet FOLLOW_107 = new BitSet(new long[]{0x0000100000400000L});
    public static final BitSet FOLLOW_108 = new BitSet(new long[]{0x0000000000410000L});
    public static final BitSet FOLLOW_109 = new BitSet(new long[]{0x0000000000000002L,0x0000000008000000L});
    public static final BitSet FOLLOW_110 = new BitSet(new long[]{0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_111 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_112 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_113 = new BitSet(new long[]{0x0000000000410010L});
    public static final BitSet FOLLOW_114 = new BitSet(new long[]{0x0000000000000002L,0x0000000008000040L});
    public static final BitSet FOLLOW_115 = new BitSet(new long[]{0x0000000000010002L,0x0000000000000040L});
    public static final BitSet FOLLOW_116 = new BitSet(new long[]{0x0000000000010012L});
    public static final BitSet FOLLOW_117 = new BitSet(new long[]{0x0008001000000002L,0x0000000100000008L});
    public static final BitSet FOLLOW_118 = new BitSet(new long[]{0x0008000000010002L,0x0000000100000008L});
    public static final BitSet FOLLOW_119 = new BitSet(new long[]{0x0008000000000002L,0x0000000100000008L});
    public static final BitSet FOLLOW_120 = new BitSet(new long[]{0x0000000000000002L,0x0000000100000008L});
    public static final BitSet FOLLOW_121 = new BitSet(new long[]{0x0000000000010012L,0x0000000100000000L});
    public static final BitSet FOLLOW_122 = new BitSet(new long[]{0x0000000000010002L,0x0000000100000000L});
    public static final BitSet FOLLOW_123 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L});
    public static final BitSet FOLLOW_124 = new BitSet(new long[]{0x0008001000000002L,0x0000000000400008L});
    public static final BitSet FOLLOW_125 = new BitSet(new long[]{0x0008000000010002L,0x0000000000400008L});
    public static final BitSet FOLLOW_126 = new BitSet(new long[]{0x0008000000000002L,0x0000000000400008L});
    public static final BitSet FOLLOW_127 = new BitSet(new long[]{0x0000000000000002L,0x0000000000400008L});
    public static final BitSet FOLLOW_128 = new BitSet(new long[]{0x0000000000010002L,0x0000000000400000L});
    public static final BitSet FOLLOW_129 = new BitSet(new long[]{0x0000000000200000L,0x0000002000000000L});
    public static final BitSet FOLLOW_130 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
    public static final BitSet FOLLOW_131 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_132 = new BitSet(new long[]{0x0000000000000000L,0x1000000000000000L});
    public static final BitSet FOLLOW_133 = new BitSet(new long[]{0x0000000000000002L,0x1000000000000000L});

}