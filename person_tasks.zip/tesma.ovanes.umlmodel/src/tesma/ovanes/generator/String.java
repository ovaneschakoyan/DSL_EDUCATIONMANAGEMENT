package tesma.ovanes.generator;

public class String {

}
