package tesma.ovanes.generator;

public interface IUmlModelGenerator {

}
