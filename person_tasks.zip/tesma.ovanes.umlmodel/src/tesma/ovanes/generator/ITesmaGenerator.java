package tesma.ovanes.generator;

public interface ITesmaGenerator {

}
